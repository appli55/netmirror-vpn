import {
    b as Pe
} from "../browser-polyfill-c2a30efe.js";
import {
    g as ef,
    c as xr
} from "../_commonjsHelpers-187a63f9.js";
import {
    aP as Qa,
    aQ as tf,
    t as Lv,
    v as Ur,
    q as Mv,
    aH as nf,
    a7 as Bv,
    aR as Nv,
    s as Fv,
    c as kv,
    aS as Uv,
    aT as Kv,
    aO as Wv,
    aU as Ir,
    aV as Gv,
    aW as Ua,
    aX as Hv,
    aY as wn,
    aZ as qv,
    a_ as Ec,
    a$ as Sc,
    a5 as $v,
    b0 as Ka,
    aN as Yv,
    b1 as jv,
    b2 as tt,
    b3 as Tc,
    b4 as zv,
    aK as Vv,
    A as Xv,
    z as Qv,
    i as Zv,
    a6 as rf,
    o as Jv,
    b5 as e0,
    aa as t0,
    b6 as n0
} from "../profile-hook-a0ada4bd.js";
import "../isObjectLike-7962ce13.js";
import {
    g as Nt,
    a as r0,
    i as i0,
    C as Ac,
    r as s0,
    t as xc,
    b as Ic,
    u as Rc,
    c as a0,
    d as o0,
    e as sf,
    f as af,
    h as Za,
    s as u0,
    p as l0
} from "../dayjs.min-db7fc211.js";
const Rr = {
    TOGGLE_PAUSE: "toggle_pause",
    SWITCH_TO_PROFILE_1: "switch_to_profile_1",
    SWITCH_TO_PROFILE_2: "switch_to_profile_2",
    SWITCH_TO_PROFILE_3: "switch_to_profile_3",
    SWITCH_TO_PROFILE_4: "switch_to_profile_4"
};
async function Hi(r, n) {
    n < r.profiles.length && await tf(n)
}
async function c0(r, n) {
    switch (n) {
        case Rr.TOGGLE_PAUSE:
            await Qa(!r.isPaused);
            break;
        case Rr.SWITCH_TO_PROFILE_1:
            await Hi(r, 0);
            break;
        case Rr.SWITCH_TO_PROFILE_2:
            await Hi(r, 1);
            break;
        case Rr.SWITCH_TO_PROFILE_3:
            await Hi(r, 2);
            break;
        case Rr.SWITCH_TO_PROFILE_4:
            await Hi(r, 3);
            break
    }
}
async function f0(r) {
    if (chrome.contextMenus) return new Promise(n => chrome.contextMenus.create(r, n))
}
async function h0(r, n) {
    if (chrome.contextMenus) return new Promise(i => chrome.contextMenus.update(r, n, i))
}
async function d0() {
    if (chrome.contextMenus) return new Promise(r => chrome.contextMenus.removeAll(r))
}
const Ja = "pause",
    of = [chrome.runtime.getManifest().manifest_version === 3 ? "action" : "browser_action"],
    Oc = {};
async function p0() {
    await d0(), await f0({
        id: Ja,
        title: "Pause",
        contexts: of
    })
}
async function Pc(r, {
    title: n,
    onclick: i
}) {
    Oc[r] !== n && (Oc[r] = n, await h0(r, {
        title: n,
        contexts: of,
        onclick: i
    }))
}
async function g0(r) {
    r.isPaused ? await Pc(Ja, {
        title: "Unpause ModHeader",
        onclick: () => Qa(!1)
    }) : await Pc(Ja, {
        title: "Pause ModHeader",
        onclick: () => Qa(!0)
    })
}
async function _0() {
    let r = await Mv(),
        n;
    if (!r.profiles) {
        const i = await nf(),
            a = i ? Object.keys(i) : [];
        a.sort(), a.length > 0 && (r = {
            profiles: i[a[a.length - 1]],
            selectedProfile: 0,
            savedToCloud: !0
        }, n = !0)
    }
    return Bv(r.profiles) && (r.profiles = []), Ur(r.profiles) && (n = !0), (Nv(r.selectedProfile) || r.selectedProfile < 0 || r.selectedProfile >= r.profiles.length) && (r.selectedProfile = r.profiles.length - 1, n = !0), n && await Fv(r), r
}
async function m0() {
    const [r, n] = await Promise.all([_0(), Lv()]);
    return n.length > 0 && Ur(n), r.managedProfiles = n, r
}
var y0 = kv;

function v0(r, n) {
    return y0(r, n)
}
var w0 = v0;
const uf = ef(w0);
async function b0(r) {
    return chrome.action ? chrome.action.setIcon(r) : new Promise(n => chrome.browserAction.setIcon(r, n))
}
async function E0(r) {
    return chrome.action ? chrome.action.setBadgeText(r) : new Promise(n => chrome.browserAction.setBadgeText(r, n))
}
async function S0(r) {
    return chrome.action ? chrome.action.setBadgeBackgroundColor(r) : new Promise(n => chrome.browserAction.setBadgeBackgroundColor(r, n))
}
async function T0({
    icon: r,
    text: n,
    color: i
}) {
    await Promise.all([b0({
        path: r
    }), E0({
        text: n
    }), S0({
        color: i
    })])
}
const Cc = "images/icon_bw.png",
    A0 = "images/icon.png",
    x0 = "❚❚";
let Wa;
async function Ga(r) {
    uf(Wa, r) || (Wa = r, await T0(Wa))
}
async function I0({
    chromeLocal: r,
    activeProfiles: n,
    selectedActiveProfile: i
}) {
    if (r.isPaused) await Ga({
        icon: Cc,
        text: x0,
        color: "#666"
    });
    else {
        let a = 0;
        for (const u of n) a += u.headers.length + u.respHeaders.length + u.cookieHeaders.length + u.setCookieHeaders.length + u.cspHeaders.length + u.urlReplacements.length;
        a === 0 ? await Ga({
            icon: Cc,
            text: "",
            color: "#fff"
        }) : await Ga({
            icon: A0,
            text: a.toString(),
            color: i.backgroundColor
        })
    }
}

function R0(r) {
    return r === void 0
}
var O0 = R0;
const Dc = ef(O0),
    Lc = 20;
async function P0(r) {
    let n = await m0(),
        i = Bc(n);
    await r(i), Uv(async a => {
        const u = !Dc(a.profiles);
        if (u) {
            let l = a.profiles.newValue;
            if (Dc(l) && (l = []), Ur(l)) {
                await Kv(l);
                return
            }
        }
        for (const [l, f] of Object.entries(a)) n[l] = f.newValue;
        if ((u || a.selectedProfile) && (i = Bc(n)), await r(i), u) try {
            await C0(n)
        } catch (l) {}
    })
}

function Mc(r) {
    const n = Wv(r);
    return n.headers = Ir(n.headers), n.respHeaders = Ir(n.respHeaders), n.cookieHeaders = Ir(n.cookieHeaders), n.setCookieHeaders = Ir(n.setCookieHeaders), n.cspHeaders = Ir(n.cspHeaders), n.urlReplacements = Gv(n.urlReplacements), n.urlFilters = Ua(n.urlFilters), n.initiatorDomainFilters = Ua(n.initiatorDomainFilters), n.excludeUrlFilters = Ua(n.excludeUrlFilters), n.resourceFilters = Hv(n.resourceFilters), n.tabFilters = wn(n.tabFilters), n.tabGroupFilters = wn(n.tabGroupFilters), n.windowFilters = wn(n.windowFilters), n.timeFilters = wn(n.timeFilters), qv() && (n.excludeRequestDomainFilters = wn(n.excludeRequestDomainFilters), n.requestMethodFilters = wn(n.requestMethodFilters), n.reqCookieAppend = wn(n.reqCookieAppend)), n
}

function Bc(r) {
    const n = [];
    let i;
    if (r.managedProfiles.length > 0)
        for (const a of r.managedProfiles) {
            const u = Mc(a);
            n.push(u)
        }
    if (r.profiles) {
        const a = r.profiles;
        for (const [u, l] of a.entries()) {
            if (u !== r.selectedProfile && !l.alwaysOn) continue;
            const f = Mc(l);
            u === r.selectedProfile && (i = f), n.push(f)
        }
    }
    return {
        chromeLocal: r,
        activeProfiles: n,
        selectedActiveProfile: i
    }
}
async function C0(r) {
    const n = await nf(),
        i = n ? Object.keys(n) : [];
    if (i.sort(), i.length >= Lc && await Ec(i.slice(0, i.length - Lc)), i.length === 0 || !uf(n[i[i.length - 1]], r.profiles)) {
        const a = {};
        if (a[Date.now()] = r.profiles, i.length > 0)
            for (let u of i) try {
                await Sc(a);
                break
            } catch (l) {
                (l == null ? void 0 : l.message) === "QUOTA_BYTES quota exceeded" && await Ec([u])
            } else await Sc(a)
    }
}
const ge = typeof globalThis != "undefined" ? globalThis : typeof self != "undefined" ? self : typeof window != "undefined" ? window : global,
    Te = Object.keys,
    Ue = Array.isArray;

function qe(r, n) {
    return typeof n != "object" || Te(n).forEach(function(i) {
        r[i] = n[i]
    }), r
}
typeof Promise == "undefined" || ge.Promise || (ge.Promise = Promise);
const Kr = Object.getPrototypeOf,
    D0 = {}.hasOwnProperty;

function rt(r, n) {
    return D0.call(r, n)
}

function Zn(r, n) {
    typeof n == "function" && (n = n(Kr(r))), (typeof Reflect == "undefined" ? Te : Reflect.ownKeys)(n).forEach(i => {
        Wt(r, i, n[i])
    })
}
const lf = Object.defineProperty;

function Wt(r, n, i, a) {
    lf(r, n, qe(i && rt(i, "get") && typeof i.get == "function" ? {
        get: i.get,
        set: i.set,
        configurable: !0
    } : {
        value: i,
        configurable: !0,
        writable: !0
    }, a))
}

function Vn(r) {
    return {
        from: function(n) {
            return r.prototype = Object.create(n.prototype), Wt(r.prototype, "constructor", r), {
                extend: Zn.bind(null, r.prototype)
            }
        }
    }
}
const L0 = Object.getOwnPropertyDescriptor;

function Oo(r, n) {
    let i;
    return L0(r, n) || (i = Kr(r)) && Oo(i, n)
}
const M0 = [].slice;

function ss(r, n, i) {
    return M0.call(r, n, i)
}

function cf(r, n) {
    return n(r)
}

function Pr(r) {
    if (!r) throw new Error("Assertion Failed")
}

function ff(r) {
    ge.setImmediate ? setImmediate(r) : setTimeout(r, 0)
}

function hf(r, n) {
    return r.reduce((i, a, u) => {
        var l = n(a, u);
        return l && (i[l[0]] = l[1]), i
    }, {})
}

function Gt(r, n) {
    if (rt(r, n)) return r[n];
    if (!n) return r;
    if (typeof n != "string") {
        for (var i = [], a = 0, u = n.length; a < u; ++a) {
            var l = Gt(r, n[a]);
            i.push(l)
        }
        return i
    }
    var f = n.indexOf(".");
    if (f !== -1) {
        var p = r[n.substr(0, f)];
        return p === void 0 ? void 0 : Gt(p, n.substr(f + 1))
    }
}

function yt(r, n, i) {
    if (r && n !== void 0 && (!("isFrozen" in Object) || !Object.isFrozen(r)))
        if (typeof n != "string" && "length" in n) {
            Pr(typeof i != "string" && "length" in i);
            for (var a = 0, u = n.length; a < u; ++a) yt(r, n[a], i[a])
        } else {
            var l = n.indexOf(".");
            if (l !== -1) {
                var f = n.substr(0, l),
                    p = n.substr(l + 1);
                if (p === "") i === void 0 ? Ue(r) && !isNaN(parseInt(f)) ? r.splice(f, 1) : delete r[f] : r[f] = i;
                else {
                    var g = r[f];
                    g && rt(r, f) || (g = r[f] = {}), yt(g, p, i)
                }
            } else i === void 0 ? Ue(r) && !isNaN(parseInt(n)) ? r.splice(n, 1) : delete r[n] : r[n] = i
        }
}

function df(r) {
    var n = {};
    for (var i in r) rt(r, i) && (n[i] = r[i]);
    return n
}
const B0 = [].concat;

function pf(r) {
    return B0.apply([], r)
}
const gf = "Boolean,String,Date,RegExp,Blob,File,FileList,FileSystemFileHandle,ArrayBuffer,DataView,Uint8ClampedArray,ImageBitmap,ImageData,Map,Set,CryptoKey".split(",").concat(pf([8, 16, 32, 64].map(r => ["Int", "Uint", "Float"].map(n => n + r + "Array")))).filter(r => ge[r]),
    N0 = gf.map(r => ge[r]);
hf(gf, r => [r, !0]);
let sn = null;

function zr(r) {
    sn = typeof WeakMap != "undefined" && new WeakMap;
    const n = eo(r);
    return sn = null, n
}

function eo(r) {
    if (!r || typeof r != "object") return r;
    let n = sn && sn.get(r);
    if (n) return n;
    if (Ue(r)) {
        n = [], sn && sn.set(r, n);
        for (var i = 0, a = r.length; i < a; ++i) n.push(eo(r[i]))
    } else if (N0.indexOf(r.constructor) >= 0) n = r;
    else {
        const l = Kr(r);
        for (var u in n = l === Object.prototype ? {} : Object.create(l), sn && sn.set(r, n), r) rt(r, u) && (n[u] = eo(r[u]))
    }
    return n
}
const {
    toString: F0
} = {};

function to(r) {
    return F0.call(r).slice(8, -1)
}
const no = typeof Symbol != "undefined" ? Symbol.iterator : "@@iterator",
    k0 = typeof no == "symbol" ? function(r) {
        var n;
        return r != null && (n = r[no]) && n.apply(r)
    } : function() {
        return null
    },
    zn = {};

function Ut(r) {
    var n, i, a, u;
    if (arguments.length === 1) {
        if (Ue(r)) return r.slice();
        if (this === zn && typeof r == "string") return [r];
        if (u = k0(r)) {
            for (i = []; !(a = u.next()).done;) i.push(a.value);
            return i
        }
        if (r == null) return [r];
        if (typeof(n = r.length) == "number") {
            for (i = new Array(n); n--;) i[n] = r[n];
            return i
        }
        return [r]
    }
    for (n = arguments.length, i = new Array(n); n--;) i[n] = arguments[n];
    return i
}
const Po = typeof Symbol != "undefined" ? r => r[Symbol.toStringTag] === "AsyncFunction" : () => !1;
var At = typeof location != "undefined" && /^(http|https):\/\/(localhost|127\.0\.0\.1)/.test(location.href);

function _f(r, n) {
    At = r, mf = n
}
var mf = () => !0;
const U0 = !new Error("").stack;

function Rn() {
    if (U0) try {
        throw Rn.arguments, new Error
    } catch (r) {
        return r
    }
    return new Error
}

function ro(r, n) {
    var i = r.stack;
    return i ? (n = n || 0, i.indexOf(r.name) === 0 && (n += (r.name + r.message).split(`
`).length), i.split(`
`).slice(n).filter(mf).map(a => `
` + a).join("")) : ""
}
var yf = ["Unknown", "Constraint", "Data", "TransactionInactive", "ReadOnly", "Version", "NotFound", "InvalidState", "InvalidAccess", "Abort", "Timeout", "QuotaExceeded", "Syntax", "DataClone"],
    Co = ["Modify", "Bulk", "OpenFailed", "VersionChange", "Schema", "Upgrade", "InvalidTable", "MissingAPI", "NoSuchDatabase", "InvalidArgument", "SubTransaction", "Unsupported", "Internal", "DatabaseClosed", "PrematureCommit", "ForeignAwait"].concat(yf),
    K0 = {
        VersionChanged: "Database version changed by other database connection",
        DatabaseClosed: "Database has been closed",
        Abort: "Transaction aborted",
        TransactionInactive: "Transaction has already completed or failed",
        MissingAPI: "IndexedDB API missing. Please visit https://tinyurl.com/y2uuvskb"
    };

function Xn(r, n) {
    this._e = Rn(), this.name = r, this.message = n
}

function vf(r, n) {
    return r + ". Errors: " + Object.keys(n).map(i => n[i].toString()).filter((i, a, u) => u.indexOf(i) === a).join(`
`)
}

function as(r, n, i, a) {
    this._e = Rn(), this.failures = n, this.failedKeys = a, this.successCount = i, this.message = vf(r, n)
}

function Lr(r, n) {
    this._e = Rn(), this.name = "BulkError", this.failures = Object.keys(n).map(i => n[i]), this.failuresByPos = n, this.message = vf(r, n)
}
Vn(Xn).from(Error).extend({
    stack: {
        get: function() {
            return this._stack || (this._stack = this.name + ": " + this.message + ro(this._e, 2))
        }
    },
    toString: function() {
        return this.name + ": " + this.message
    }
}), Vn(as).from(Xn), Vn(Lr).from(Xn);
var Do = Co.reduce((r, n) => (r[n] = n + "Error", r), {});
const W0 = Xn;
var V = Co.reduce((r, n) => {
    var i = n + "Error";

    function a(u, l) {
        this._e = Rn(), this.name = i, u ? typeof u == "string" ? (this.message = `${u}${l?`
 `+l:""}`, this.inner = l || null) : typeof u == "object" && (this.message = `${u.name} ${u.message}`, this.inner = u) : (this.message = K0[n] || i, this.inner = null)
    }
    return Vn(a).from(W0), r[n] = a, r
}, {});
V.Syntax = SyntaxError, V.Type = TypeError, V.Range = RangeError;
var Nc = yf.reduce((r, n) => (r[n + "Error"] = V[n], r), {}),
    Zi = Co.reduce((r, n) => (["Syntax", "Type", "Range"].indexOf(n) === -1 && (r[n + "Error"] = V[n]), r), {});

function ce() {}

function Wr(r) {
    return r
}

function G0(r, n) {
    return r == null || r === Wr ? n : function(i) {
        return n(r(i))
    }
}

function xn(r, n) {
    return function() {
        r.apply(this, arguments), n.apply(this, arguments)
    }
}

function H0(r, n) {
    return r === ce ? n : function() {
        var i = r.apply(this, arguments);
        i !== void 0 && (arguments[0] = i);
        var a = this.onsuccess,
            u = this.onerror;
        this.onsuccess = null, this.onerror = null;
        var l = n.apply(this, arguments);
        return a && (this.onsuccess = this.onsuccess ? xn(a, this.onsuccess) : a), u && (this.onerror = this.onerror ? xn(u, this.onerror) : u), l !== void 0 ? l : i
    }
}

function q0(r, n) {
    return r === ce ? n : function() {
        r.apply(this, arguments);
        var i = this.onsuccess,
            a = this.onerror;
        this.onsuccess = this.onerror = null, n.apply(this, arguments), i && (this.onsuccess = this.onsuccess ? xn(i, this.onsuccess) : i), a && (this.onerror = this.onerror ? xn(a, this.onerror) : a)
    }
}

function $0(r, n) {
    return r === ce ? n : function(i) {
        var a = r.apply(this, arguments);
        qe(i, a);
        var u = this.onsuccess,
            l = this.onerror;
        this.onsuccess = null, this.onerror = null;
        var f = n.apply(this, arguments);
        return u && (this.onsuccess = this.onsuccess ? xn(u, this.onsuccess) : u), l && (this.onerror = this.onerror ? xn(l, this.onerror) : l), a === void 0 ? f === void 0 ? void 0 : f : qe(a, f)
    }
}

function Y0(r, n) {
    return r === ce ? n : function() {
        return n.apply(this, arguments) !== !1 && r.apply(this, arguments)
    }
}

function Lo(r, n) {
    return r === ce ? n : function() {
        var i = r.apply(this, arguments);
        if (i && typeof i.then == "function") {
            for (var a = this, u = arguments.length, l = new Array(u); u--;) l[u] = arguments[u];
            return i.then(function() {
                return n.apply(a, l)
            })
        }
        return n.apply(this, arguments)
    }
}
Zi.ModifyError = as, Zi.DexieError = Xn, Zi.BulkError = Lr;
var Gr = {};
const wf = 100,
    [io, os, so] = typeof Promise == "undefined" ? [] : (() => {
        let r = Promise.resolve();
        if (typeof crypto == "undefined" || !crypto.subtle) return [r, Kr(r), r];
        const n = crypto.subtle.digest("SHA-512", new Uint8Array([0]));
        return [n, Kr(n), r]
    })(),
    bf = os && os.then,
    Ji = io && io.constructor,
    Mo = !!so;
var ao = !1,
    j0 = so ? () => {
        so.then(qi)
    } : ge.setImmediate ? setImmediate.bind(null, qi) : ge.MutationObserver ? () => {
        var r = document.createElement("div");
        new MutationObserver(() => {
            qi(), r = null
        }).observe(r, {
            attributes: !0
        }), r.setAttribute("i", "1")
    } : () => {
        setTimeout(qi, 0)
    },
    Mr = function(r, n) {
        Cr.push([r, n]), us && (j0(), us = !1)
    },
    oo = !0,
    us = !0,
    Sn = [],
    es = [],
    uo = null,
    lo = Wr,
    Qn = {
        id: "global",
        global: !0,
        ref: 0,
        unhandleds: [],
        onunhandled: Uc,
        pgp: !1,
        env: {},
        finalize: function() {
            this.unhandleds.forEach(r => {
                try {
                    Uc(r[0], r[1])
                } catch (n) {}
            })
        }
    },
    $ = Qn,
    Cr = [],
    Tn = 0,
    ts = [];

function H(r) {
    if (typeof this != "object") throw new TypeError("Promises must be constructed via new");
    this._listeners = [], this.onuncatched = ce, this._lib = !1;
    var n = this._PSD = $;
    if (At && (this._stackHolder = Rn(), this._prev = null, this._numPrev = 0), typeof r != "function") {
        if (r !== Gr) throw new TypeError("Not a function");
        return this._state = arguments[1], this._value = arguments[2], void(this._state === !1 && fo(this, this._value))
    }
    this._state = null, this._value = null, ++n.ref, Sf(this, r)
}
const co = {
    get: function() {
        var r = $,
            n = ls;

        function i(a, u) {
            var l = !r.global && (r !== $ || n !== ls);
            const f = l && !Ht();
            var p = new H((g, E) => {
                Bo(this, new Ef(cs(a, r, l, f), cs(u, r, l, f), g, E, r))
            });
            return At && xf(p, this), p
        }
        return i.prototype = Gr, i
    },
    set: function(r) {
        Wt(this, "then", r && r.prototype === Gr ? co : {
            get: function() {
                return r
            },
            set: co.set
        })
    }
};

function Ef(r, n, i, a, u) {
    this.onFulfilled = typeof r == "function" ? r : null, this.onRejected = typeof n == "function" ? n : null, this.resolve = i, this.reject = a, this.psd = u
}

function Sf(r, n) {
    try {
        n(i => {
            if (r._state === null) {
                if (i === r) throw new TypeError("A promise cannot be resolved with itself.");
                var a = r._lib && Vr();
                i && typeof i.then == "function" ? Sf(r, (u, l) => {
                    i instanceof H ? i._then(u, l) : i.then(u, l)
                }) : (r._state = !0, r._value = i, Tf(r)), a && Xr()
            }
        }, fo.bind(null, r))
    } catch (i) {
        fo(r, i)
    }
}

function fo(r, n) {
    if (es.push(n), r._state === null) {
        var i = r._lib && Vr();
        n = lo(n), r._state = !1, r._value = n, At && n !== null && typeof n == "object" && !n._promise && function(a, u, l) {
                try {
                    a.apply(null, l)
                } catch (f) {
                    u && u(f)
                }
            }(() => {
                var a = Oo(n, "stack");
                n._promise = r, Wt(n, "stack", {
                    get: () => ao ? a && (a.get ? a.get.apply(n) : a.value) : r.stack
                })
            }),
            function(a) {
                Sn.some(u => u._value === a._value) || Sn.push(a)
            }(r), Tf(r), i && Xr()
    }
}

function Tf(r) {
    var n = r._listeners;
    r._listeners = [];
    for (var i = 0, a = n.length; i < a; ++i) Bo(r, n[i]);
    var u = r._PSD;
    --u.ref || u.finalize(), Tn === 0 && (++Tn, Mr(() => {
        --Tn == 0 && No()
    }, []))
}

function Bo(r, n) {
    if (r._state !== null) {
        var i = r._state ? n.onFulfilled : n.onRejected;
        if (i === null) return (r._state ? n.resolve : n.reject)(r._value);
        ++n.psd.ref, ++Tn, Mr(z0, [i, r, n])
    } else r._listeners.push(n)
}

function z0(r, n, i) {
    try {
        uo = n;
        var a, u = n._value;
        n._state ? a = r(u) : (es.length && (es = []), a = r(u), es.indexOf(u) === -1 && function(l) {
            for (var f = Sn.length; f;)
                if (Sn[--f]._value === l._value) return void Sn.splice(f, 1)
        }(n)), i.resolve(a)
    } catch (l) {
        i.reject(l)
    } finally {
        uo = null, --Tn == 0 && No(), --i.psd.ref || i.psd.finalize()
    }
}

function Af(r, n, i) {
    if (n.length === i) return n;
    var a = "";
    if (r._state === !1) {
        var u, l, f = r._value;
        f != null ? (u = f.name || "Error", l = f.message || f, a = ro(f, 0)) : (u = f, l = ""), n.push(u + (l ? ": " + l : "") + a)
    }
    return At && ((a = ro(r._stackHolder, 2)) && n.indexOf(a) === -1 && n.push(a), r._prev && Af(r._prev, n, i)), n
}

function xf(r, n) {
    var i = n ? n._numPrev + 1 : 0;
    i < 100 && (r._prev = n, r._numPrev = i)
}

function qi() {
    Vr() && Xr()
}

function Vr() {
    var r = oo;
    return oo = !1, us = !1, r
}

function Xr() {
    var r, n, i;
    do
        for (; Cr.length > 0;)
            for (r = Cr, Cr = [], i = r.length, n = 0; n < i; ++n) {
                var a = r[n];
                a[0].apply(null, a[1])
            }
    while (Cr.length > 0);
    oo = !0, us = !0
}

function No() {
    var r = Sn;
    Sn = [], r.forEach(a => {
        a._PSD.onunhandled.call(null, a._value, a)
    });
    for (var n = ts.slice(0), i = n.length; i;) n[--i]()
}

function $i(r) {
    return new H(Gr, !1, r)
}

function ye(r, n) {
    var i = $;
    return function() {
        var a = Vr(),
            u = $;
        try {
            return un(i, !0), r.apply(this, arguments)
        } catch (l) {
            n && n(l)
        } finally {
            un(u, !1), a && Xr()
        }
    }
}
Zn(H.prototype, {
    then: co,
    _then: function(r, n) {
        Bo(this, new Ef(null, null, r, n, $))
    },
    catch: function(r) {
        if (arguments.length === 1) return this.then(null, r);
        var n = arguments[0],
            i = arguments[1];
        return typeof n == "function" ? this.then(null, a => a instanceof n ? i(a) : $i(a)) : this.then(null, a => a && a.name === n ? i(a) : $i(a))
    },
    finally: function(r) {
        return this.then(n => (r(), n), n => (r(), $i(n)))
    },
    stack: {
        get: function() {
            if (this._stack) return this._stack;
            try {
                ao = !0;
                var r = Af(this, [], 20).join(`
From previous: `);
                return this._state !== null && (this._stack = r), r
            } finally {
                ao = !1
            }
        }
    },
    timeout: function(r, n) {
        return r < 1 / 0 ? new H((i, a) => {
            var u = setTimeout(() => a(new V.Timeout(n)), r);
            this.then(i, a).finally(clearTimeout.bind(null, u))
        }) : this
    }
}), typeof Symbol != "undefined" && Symbol.toStringTag && Wt(H.prototype, Symbol.toStringTag, "Dexie.Promise"), Qn.env = If(), Zn(H, {
    all: function() {
        var r = Ut.apply(null, arguments).map(Yi);
        return new H(function(n, i) {
            r.length === 0 && n([]);
            var a = r.length;
            r.forEach((u, l) => H.resolve(u).then(f => {
                r[l] = f, --a || n(r)
            }, i))
        })
    },
    resolve: r => {
        if (r instanceof H) return r;
        if (r && typeof r.then == "function") return new H((i, a) => {
            r.then(i, a)
        });
        var n = new H(Gr, !0, r);
        return xf(n, uo), n
    },
    reject: $i,
    race: function() {
        var r = Ut.apply(null, arguments).map(Yi);
        return new H((n, i) => {
            r.map(a => H.resolve(a).then(n, i))
        })
    },
    PSD: {
        get: () => $,
        set: r => $ = r
    },
    totalEchoes: {
        get: () => ls
    },
    newPSD: on,
    usePSD: nr,
    scheduler: {
        get: () => Mr,
        set: r => {
            Mr = r
        }
    },
    rejectionMapper: {
        get: () => lo,
        set: r => {
            lo = r
        }
    },
    follow: (r, n) => new H((i, a) => on((u, l) => {
        var f = $;
        f.unhandleds = [], f.onunhandled = l, f.finalize = xn(function() {
            (function(p) {
                function g() {
                    p(), ts.splice(ts.indexOf(g), 1)
                }
                ts.push(g), ++Tn, Mr(() => {
                    --Tn == 0 && No()
                }, [])
            })(() => {
                this.unhandleds.length === 0 ? u() : l(this.unhandleds[0])
            })
        }, f.finalize), r()
    }, n, i, a))
}), Ji && (Ji.allSettled && Wt(H, "allSettled", function() {
    const r = Ut.apply(null, arguments).map(Yi);
    return new H(n => {
        r.length === 0 && n([]);
        let i = r.length;
        const a = new Array(i);
        r.forEach((u, l) => H.resolve(u).then(f => a[l] = {
            status: "fulfilled",
            value: f
        }, f => a[l] = {
            status: "rejected",
            reason: f
        }).then(() => --i || n(a)))
    })
}), Ji.any && typeof AggregateError != "undefined" && Wt(H, "any", function() {
    const r = Ut.apply(null, arguments).map(Yi);
    return new H((n, i) => {
        r.length === 0 && i(new AggregateError([]));
        let a = r.length;
        const u = new Array(a);
        r.forEach((l, f) => H.resolve(l).then(p => n(p), p => {
            u[f] = p, --a || i(new AggregateError(u))
        }))
    })
}));
const ke = {
    awaits: 0,
    echoes: 0,
    id: 0
};
var V0 = 0,
    ns = [],
    Ha = 0,
    ls = 0,
    X0 = 0;

function on(r, n, i, a) {
    var u = $,
        l = Object.create(u);
    l.parent = u, l.ref = 0, l.global = !1, l.id = ++X0;
    var f = Qn.env;
    l.env = Mo ? {
        Promise: H,
        PromiseProp: {
            value: H,
            configurable: !0,
            writable: !0
        },
        all: H.all,
        race: H.race,
        allSettled: H.allSettled,
        any: H.any,
        resolve: H.resolve,
        reject: H.reject,
        nthen: Fc(f.nthen, l),
        gthen: Fc(f.gthen, l)
    } : {}, n && qe(l, n), ++u.ref, l.finalize = function() {
        --this.parent.ref || this.parent.finalize()
    };
    var p = nr(l, r, i, a);
    return l.ref === 0 && l.finalize(), p
}

function tr() {
    return ke.id || (ke.id = ++V0), ++ke.awaits, ke.echoes += wf, ke.id
}

function Ht() {
    return !!ke.awaits && (--ke.awaits == 0 && (ke.id = 0), ke.echoes = ke.awaits * wf, !0)
}

function Yi(r) {
    return ke.echoes && r && r.constructor === Ji ? (tr(), r.then(n => (Ht(), n), n => (Ht(), Ie(n)))) : r
}

function Q0(r) {
    ++ls, ke.echoes && --ke.echoes != 0 || (ke.echoes = ke.id = 0), ns.push($), un(r, !0)
}

function Z0() {
    var r = ns[ns.length - 1];
    ns.pop(), un(r, !1)
}

function un(r, n) {
    var i = $;
    if ((n ? !ke.echoes || Ha++ && r === $ : !Ha || --Ha && r === $) || Rf(n ? Q0.bind(null, r) : Z0), r !== $ && ($ = r, i === Qn && (Qn.env = If()), Mo)) {
        var a = Qn.env.Promise,
            u = r.env;
        os.then = u.nthen, a.prototype.then = u.gthen, (i.global || r.global) && (Object.defineProperty(ge, "Promise", u.PromiseProp), a.all = u.all, a.race = u.race, a.resolve = u.resolve, a.reject = u.reject, u.allSettled && (a.allSettled = u.allSettled), u.any && (a.any = u.any))
    }
}

function If() {
    var r = ge.Promise;
    return Mo ? {
        Promise: r,
        PromiseProp: Object.getOwnPropertyDescriptor(ge, "Promise"),
        all: r.all,
        race: r.race,
        allSettled: r.allSettled,
        any: r.any,
        resolve: r.resolve,
        reject: r.reject,
        nthen: os.then,
        gthen: r.prototype.then
    } : {}
}

function nr(r, n, i, a, u) {
    var l = $;
    try {
        return un(r, !0), n(i, a, u)
    } finally {
        un(l, !1)
    }
}

function Rf(r) {
    bf.call(io, r)
}

function cs(r, n, i, a) {
    return typeof r != "function" ? r : function() {
        var u = $;
        i && tr(), un(n, !0);
        try {
            return r.apply(this, arguments)
        } finally {
            un(u, !1), a && Rf(Ht)
        }
    }
}

function Fc(r, n) {
    return function(i, a) {
        return r.call(this, cs(i, n), cs(a, n))
    }
}("" + bf).indexOf("[native code]") === -1 && (tr = Ht = ce);
const kc = "unhandledrejection";

function Uc(r, n) {
    var i;
    try {
        i = n.onuncatched(r)
    } catch (l) {}
    if (i !== !1) try {
        var a, u = {
            promise: n,
            reason: r
        };
        if (ge.document && document.createEvent ? ((a = document.createEvent("Event")).initEvent(kc, !0, !0), qe(a, u)) : ge.CustomEvent && qe(a = new CustomEvent(kc, {
                detail: u
            }), u), a && ge.dispatchEvent && (dispatchEvent(a), !ge.PromiseRejectionEvent && ge.onunhandledrejection)) try {
            ge.onunhandledrejection(a)
        } catch (l) {}
        At && a && a.defaultPrevented
    } catch (l) {}
}
var Ie = H.reject;

function ho(r, n, i, a) {
    if (r.idbdb && (r._state.openComplete || $.letThrough || r._vip)) {
        var u = r._createTransaction(n, i, r._dbSchema);
        try {
            u.create(), r._state.PR1398_maxLoop = 3
        } catch (l) {
            return l.name === Do.InvalidState && r.isOpen() && --r._state.PR1398_maxLoop > 0 ? (r._close(), r.open().then(() => ho(r, n, i, a))) : Ie(l)
        }
        return u._promise(n, (l, f) => on(() => ($.trans = u, a(l, f, u)))).then(l => u._completion.then(() => l))
    }
    if (r._state.openComplete) return Ie(new V.DatabaseClosed(r._state.dbOpenError));
    if (!r._state.isBeingOpened) {
        if (!r._options.autoOpen) return Ie(new V.DatabaseClosed);
        r.open().catch(ce)
    }
    return r._state.dbReadyPromise.then(() => ho(r, n, i, a))
}
const Kc = "3.2.4",
    En = String.fromCharCode(65535),
    po = -1 / 0,
    Ft = "Invalid key provided. Keys must be of type string, number, Date or Array<string | number | Date>.",
    Of = "String expected.",
    Br = [],
    gs = typeof navigator != "undefined" && /(MSIE|Trident|Edge)/.test(navigator.userAgent),
    J0 = gs,
    ew = gs,
    Pf = r => !/(dexie\.js|dexie\.min\.js)/.test(r),
    _s = "__dbnames",
    qa = "readonly",
    $a = "readwrite";

function In(r, n) {
    return r ? n ? function() {
        return r.apply(this, arguments) && n.apply(this, arguments)
    } : r : n
}
const Cf = {
    type: 3,
    lower: -1 / 0,
    lowerOpen: !1,
    upper: [
        []
    ],
    upperOpen: !1
};

function ji(r) {
    return typeof r != "string" || /\./.test(r) ? n => n : n => (n[r] === void 0 && r in n && delete(n = zr(n))[r], n)
}
class tw {
    _trans(n, i, a) {
        const u = this._tx || $.trans,
            l = this.name;

        function f(g, E, v) {
            if (!v.schema[l]) throw new V.NotFound("Table " + l + " not part of transaction");
            return i(v.idbtrans, v)
        }
        const p = Vr();
        try {
            return u && u.db === this.db ? u === $.trans ? u._promise(n, f, a) : on(() => u._promise(n, f, a), {
                trans: u,
                transless: $.transless || $
            }) : ho(this.db, n, [this.name], f)
        } finally {
            p && Xr()
        }
    }
    get(n, i) {
        return n && n.constructor === Object ? this.where(n).first(i) : this._trans("readonly", a => this.core.get({
            trans: a,
            key: n
        }).then(u => this.hook.reading.fire(u))).then(i)
    }
    where(n) {
        if (typeof n == "string") return new this.db.WhereClause(this, n);
        if (Ue(n)) return new this.db.WhereClause(this, `[${n.join("+")}]`);
        const i = Te(n);
        if (i.length === 1) return this.where(i[0]).equals(n[i[0]]);
        const a = this.schema.indexes.concat(this.schema.primKey).filter(E => E.compound && i.every(v => E.keyPath.indexOf(v) >= 0) && E.keyPath.every(v => i.indexOf(v) >= 0))[0];
        if (a && this.db._maxKey !== En) return this.where(a.name).equals(a.keyPath.map(E => n[E]));
        const {
            idxByName: u
        } = this.schema, l = this.db._deps.indexedDB;

        function f(E, v) {
            try {
                return l.cmp(E, v) === 0
            } catch (S) {
                return !1
            }
        }
        const [p, g] = i.reduce(([E, v], S) => {
            const b = u[S],
                A = n[S];
            return [E || b, E || !b ? In(v, b && b.multi ? M => {
                const I = Gt(M, S);
                return Ue(I) && I.some(L => f(A, L))
            } : M => f(A, Gt(M, S))) : v]
        }, [null, null]);
        return p ? this.where(p.name).equals(n[p.keyPath]).filter(g) : a ? this.filter(g) : this.where(i).equals("")
    }
    filter(n) {
        return this.toCollection().and(n)
    }
    count(n) {
        return this.toCollection().count(n)
    }
    offset(n) {
        return this.toCollection().offset(n)
    }
    limit(n) {
        return this.toCollection().limit(n)
    }
    each(n) {
        return this.toCollection().each(n)
    }
    toArray(n) {
        return this.toCollection().toArray(n)
    }
    toCollection() {
        return new this.db.Collection(new this.db.WhereClause(this))
    }
    orderBy(n) {
        return new this.db.Collection(new this.db.WhereClause(this, Ue(n) ? `[${n.join("+")}]` : n))
    }
    reverse() {
        return this.toCollection().reverse()
    }
    mapToClass(n) {
        this.schema.mappedClass = n;
        const i = a => {
            if (!a) return a;
            const u = Object.create(n.prototype);
            for (var l in a)
                if (rt(a, l)) try {
                    u[l] = a[l]
                } catch (f) {}
            return u
        };
        return this.schema.readHook && this.hook.reading.unsubscribe(this.schema.readHook), this.schema.readHook = i, this.hook("reading", i), n
    }
    defineClass() {
        return this.mapToClass(function(n) {
            qe(this, n)
        })
    }
    add(n, i) {
        const {
            auto: a,
            keyPath: u
        } = this.schema.primKey;
        let l = n;
        return u && a && (l = ji(u)(n)), this._trans("readwrite", f => this.core.mutate({
            trans: f,
            type: "add",
            keys: i != null ? [i] : null,
            values: [l]
        })).then(f => f.numFailures ? H.reject(f.failures[0]) : f.lastResult).then(f => {
            if (u) try {
                yt(n, u, f)
            } catch (p) {}
            return f
        })
    }
    update(n, i) {
        if (typeof n != "object" || Ue(n)) return this.where(":id").equals(n).modify(i);
        {
            const a = Gt(n, this.schema.primKey.keyPath);
            if (a === void 0) return Ie(new V.InvalidArgument("Given object does not contain its primary key"));
            try {
                typeof i != "function" ? Te(i).forEach(u => {
                    yt(n, u, i[u])
                }) : i(n, {
                    value: n,
                    primKey: a
                })
            } catch (u) {}
            return this.where(":id").equals(a).modify(i)
        }
    }
    put(n, i) {
        const {
            auto: a,
            keyPath: u
        } = this.schema.primKey;
        let l = n;
        return u && a && (l = ji(u)(n)), this._trans("readwrite", f => this.core.mutate({
            trans: f,
            type: "put",
            values: [l],
            keys: i != null ? [i] : null
        })).then(f => f.numFailures ? H.reject(f.failures[0]) : f.lastResult).then(f => {
            if (u) try {
                yt(n, u, f)
            } catch (p) {}
            return f
        })
    }
    delete(n) {
        return this._trans("readwrite", i => this.core.mutate({
            trans: i,
            type: "delete",
            keys: [n]
        })).then(i => i.numFailures ? H.reject(i.failures[0]) : void 0)
    }
    clear() {
        return this._trans("readwrite", n => this.core.mutate({
            trans: n,
            type: "deleteRange",
            range: Cf
        })).then(n => n.numFailures ? H.reject(n.failures[0]) : void 0)
    }
    bulkGet(n) {
        return this._trans("readonly", i => this.core.getMany({
            keys: n,
            trans: i
        }).then(a => a.map(u => this.hook.reading.fire(u))))
    }
    bulkAdd(n, i, a) {
        const u = Array.isArray(i) ? i : void 0,
            l = (a = a || (u ? void 0 : i)) ? a.allKeys : void 0;
        return this._trans("readwrite", f => {
            const {
                auto: p,
                keyPath: g
            } = this.schema.primKey;
            if (g && u) throw new V.InvalidArgument("bulkAdd(): keys argument invalid on tables with inbound keys");
            if (u && u.length !== n.length) throw new V.InvalidArgument("Arguments objects and keys must have the same length");
            const E = n.length;
            let v = g && p ? n.map(ji(g)) : n;
            return this.core.mutate({
                trans: f,
                type: "add",
                keys: u,
                values: v,
                wantResults: l
            }).then(({
                numFailures: S,
                results: b,
                lastResult: A,
                failures: M
            }) => {
                if (S === 0) return l ? b : A;
                throw new Lr(`${this.name}.bulkAdd(): ${S} of ${E} operations failed`, M)
            })
        })
    }
    bulkPut(n, i, a) {
        const u = Array.isArray(i) ? i : void 0,
            l = (a = a || (u ? void 0 : i)) ? a.allKeys : void 0;
        return this._trans("readwrite", f => {
            const {
                auto: p,
                keyPath: g
            } = this.schema.primKey;
            if (g && u) throw new V.InvalidArgument("bulkPut(): keys argument invalid on tables with inbound keys");
            if (u && u.length !== n.length) throw new V.InvalidArgument("Arguments objects and keys must have the same length");
            const E = n.length;
            let v = g && p ? n.map(ji(g)) : n;
            return this.core.mutate({
                trans: f,
                type: "put",
                keys: u,
                values: v,
                wantResults: l
            }).then(({
                numFailures: S,
                results: b,
                lastResult: A,
                failures: M
            }) => {
                if (S === 0) return l ? b : A;
                throw new Lr(`${this.name}.bulkPut(): ${S} of ${E} operations failed`, M)
            })
        })
    }
    bulkDelete(n) {
        const i = n.length;
        return this._trans("readwrite", a => this.core.mutate({
            trans: a,
            type: "delete",
            keys: n
        })).then(({
            numFailures: a,
            lastResult: u,
            failures: l
        }) => {
            if (a === 0) return u;
            throw new Lr(`${this.name}.bulkDelete(): ${a} of ${i} operations failed`, l)
        })
    }
}

function Nr(r) {
    var n = {},
        i = function(f, p) {
            if (p) {
                for (var g = arguments.length, E = new Array(g - 1); --g;) E[g - 1] = arguments[g];
                return n[f].subscribe.apply(null, E), r
            }
            if (typeof f == "string") return n[f]
        };
    i.addEventType = l;
    for (var a = 1, u = arguments.length; a < u; ++a) l(arguments[a]);
    return i;

    function l(f, p, g) {
        if (typeof f != "object") {
            var E;
            p || (p = Y0), g || (g = ce);
            var v = {
                subscribers: [],
                fire: g,
                subscribe: function(S) {
                    v.subscribers.indexOf(S) === -1 && (v.subscribers.push(S), v.fire = p(v.fire, S))
                },
                unsubscribe: function(S) {
                    v.subscribers = v.subscribers.filter(function(b) {
                        return b !== S
                    }), v.fire = v.subscribers.reduce(p, g)
                }
            };
            return n[f] = i[f] = v, v
        }
        Te(E = f).forEach(function(S) {
            var b = E[S];
            if (Ue(b)) l(S, E[S][0], E[S][1]);
            else {
                if (b !== "asap") throw new V.InvalidArgument("Invalid event config");
                var A = l(S, Wr, function() {
                    for (var M = arguments.length, I = new Array(M); M--;) I[M] = arguments[M];
                    A.subscribers.forEach(function(L) {
                        ff(function() {
                            L.apply(null, I)
                        })
                    })
                })
            }
        })
    }
}

function Or(r, n) {
    return Vn(n).from({
        prototype: r
    }), n
}

function $n(r, n) {
    return !(r.filter || r.algorithm || r.or) && (n ? r.justLimit : !r.replayFilter)
}

function Ya(r, n) {
    r.filter = In(r.filter, n)
}

function ja(r, n, i) {
    var a = r.replayFilter;
    r.replayFilter = a ? () => In(a(), n()) : n, r.justLimit = i && !a
}

function rs(r, n) {
    if (r.isPrimKey) return n.primaryKey;
    const i = n.getIndexByKeyPath(r.index);
    if (!i) throw new V.Schema("KeyPath " + r.index + " on object store " + n.name + " is not indexed");
    return i
}

function Wc(r, n, i) {
    const a = rs(r, n.schema);
    return n.openCursor({
        trans: i,
        values: !r.keysOnly,
        reverse: r.dir === "prev",
        unique: !!r.unique,
        query: {
            index: a,
            range: r.range
        }
    })
}

function zi(r, n, i, a) {
    const u = r.replayFilter ? In(r.filter, r.replayFilter()) : r.filter;
    if (r.or) {
        const l = {},
            f = (p, g, E) => {
                if (!u || u(g, E, b => g.stop(b), b => g.fail(b))) {
                    var v = g.primaryKey,
                        S = "" + v;
                    S === "[object ArrayBuffer]" && (S = "" + new Uint8Array(v)), rt(l, S) || (l[S] = !0, n(p, g, E))
                }
            };
        return Promise.all([r.or._iterate(f, i), Gc(Wc(r, a, i), r.algorithm, f, !r.keysOnly && r.valueMapper)])
    }
    return Gc(Wc(r, a, i), In(r.algorithm, u), n, !r.keysOnly && r.valueMapper)
}

function Gc(r, n, i, a) {
    var u = ye(a ? (l, f, p) => i(a(l), f, p) : i);
    return r.then(l => {
        if (l) return l.start(() => {
            var f = () => l.continue();
            n && !n(l, p => f = p, p => {
                l.stop(p), f = ce
            }, p => {
                l.fail(p), f = ce
            }) || u(l.value, l, p => f = p), f()
        })
    })
}

function He(r, n) {
    try {
        const i = Hc(r),
            a = Hc(n);
        if (i !== a) return i === "Array" ? 1 : a === "Array" ? -1 : i === "binary" ? 1 : a === "binary" ? -1 : i === "string" ? 1 : a === "string" ? -1 : i === "Date" ? 1 : a !== "Date" ? NaN : -1;
        switch (i) {
            case "number":
            case "Date":
            case "string":
                return r > n ? 1 : r < n ? -1 : 0;
            case "binary":
                return function(u, l) {
                    const f = u.length,
                        p = l.length,
                        g = f < p ? f : p;
                    for (let E = 0; E < g; ++E)
                        if (u[E] !== l[E]) return u[E] < l[E] ? -1 : 1;
                    return f === p ? 0 : f < p ? -1 : 1
                }(qc(r), qc(n));
            case "Array":
                return function(u, l) {
                    const f = u.length,
                        p = l.length,
                        g = f < p ? f : p;
                    for (let E = 0; E < g; ++E) {
                        const v = He(u[E], l[E]);
                        if (v !== 0) return v
                    }
                    return f === p ? 0 : f < p ? -1 : 1
                }(r, n)
        }
    } catch (i) {}
    return NaN
}

function Hc(r) {
    const n = typeof r;
    if (n !== "object") return n;
    if (ArrayBuffer.isView(r)) return "binary";
    const i = to(r);
    return i === "ArrayBuffer" ? "binary" : i
}

function qc(r) {
    return r instanceof Uint8Array ? r : ArrayBuffer.isView(r) ? new Uint8Array(r.buffer, r.byteOffset, r.byteLength) : new Uint8Array(r)
}
class nw {
    _read(n, i) {
        var a = this._ctx;
        return a.error ? a.table._trans(null, Ie.bind(null, a.error)) : a.table._trans("readonly", n).then(i)
    }
    _write(n) {
        var i = this._ctx;
        return i.error ? i.table._trans(null, Ie.bind(null, i.error)) : i.table._trans("readwrite", n, "locked")
    }
    _addAlgorithm(n) {
        var i = this._ctx;
        i.algorithm = In(i.algorithm, n)
    }
    _iterate(n, i) {
        return zi(this._ctx, n, i, this._ctx.table.core)
    }
    clone(n) {
        var i = Object.create(this.constructor.prototype),
            a = Object.create(this._ctx);
        return n && qe(a, n), i._ctx = a, i
    }
    raw() {
        return this._ctx.valueMapper = null, this
    }
    each(n) {
        var i = this._ctx;
        return this._read(a => zi(i, n, a, i.table.core))
    }
    count(n) {
        return this._read(i => {
            const a = this._ctx,
                u = a.table.core;
            if ($n(a, !0)) return u.count({
                trans: i,
                query: {
                    index: rs(a, u.schema),
                    range: a.range
                }
            }).then(f => Math.min(f, a.limit));
            var l = 0;
            return zi(a, () => (++l, !1), i, u).then(() => l)
        }).then(n)
    }
    sortBy(n, i) {
        const a = n.split(".").reverse(),
            u = a[0],
            l = a.length - 1;

        function f(E, v) {
            return v ? f(E[a[v]], v - 1) : E[u]
        }
        var p = this._ctx.dir === "next" ? 1 : -1;

        function g(E, v) {
            var S = f(E, l),
                b = f(v, l);
            return S < b ? -p : S > b ? p : 0
        }
        return this.toArray(function(E) {
            return E.sort(g)
        }).then(i)
    }
    toArray(n) {
        return this._read(i => {
            var a = this._ctx;
            if (a.dir === "next" && $n(a, !0) && a.limit > 0) {
                const {
                    valueMapper: u
                } = a, l = rs(a, a.table.core.schema);
                return a.table.core.query({
                    trans: i,
                    limit: a.limit,
                    values: !0,
                    query: {
                        index: l,
                        range: a.range
                    }
                }).then(({
                    result: f
                }) => u ? f.map(u) : f)
            } {
                const u = [];
                return zi(a, l => u.push(l), i, a.table.core).then(() => u)
            }
        }, n)
    }
    offset(n) {
        var i = this._ctx;
        return n <= 0 || (i.offset += n, $n(i) ? ja(i, () => {
            var a = n;
            return (u, l) => a === 0 || (a === 1 ? (--a, !1) : (l(() => {
                u.advance(a), a = 0
            }), !1))
        }) : ja(i, () => {
            var a = n;
            return () => --a < 0
        })), this
    }
    limit(n) {
        return this._ctx.limit = Math.min(this._ctx.limit, n), ja(this._ctx, () => {
            var i = n;
            return function(a, u, l) {
                return --i <= 0 && u(l), i >= 0
            }
        }, !0), this
    }
    until(n, i) {
        return Ya(this._ctx, function(a, u, l) {
            return !n(a.value) || (u(l), i)
        }), this
    }
    first(n) {
        return this.limit(1).toArray(function(i) {
            return i[0]
        }).then(n)
    }
    last(n) {
        return this.reverse().first(n)
    }
    filter(n) {
        var i, a;
        return Ya(this._ctx, function(u) {
            return n(u.value)
        }), i = this._ctx, a = n, i.isMatch = In(i.isMatch, a), this
    }
    and(n) {
        return this.filter(n)
    }
    or(n) {
        return new this.db.WhereClause(this._ctx.table, n, this)
    }
    reverse() {
        return this._ctx.dir = this._ctx.dir === "prev" ? "next" : "prev", this._ondirectionchange && this._ondirectionchange(this._ctx.dir), this
    }
    desc() {
        return this.reverse()
    }
    eachKey(n) {
        var i = this._ctx;
        return i.keysOnly = !i.isMatch, this.each(function(a, u) {
            n(u.key, u)
        })
    }
    eachUniqueKey(n) {
        return this._ctx.unique = "unique", this.eachKey(n)
    }
    eachPrimaryKey(n) {
        var i = this._ctx;
        return i.keysOnly = !i.isMatch, this.each(function(a, u) {
            n(u.primaryKey, u)
        })
    }
    keys(n) {
        var i = this._ctx;
        i.keysOnly = !i.isMatch;
        var a = [];
        return this.each(function(u, l) {
            a.push(l.key)
        }).then(function() {
            return a
        }).then(n)
    }
    primaryKeys(n) {
        var i = this._ctx;
        if (i.dir === "next" && $n(i, !0) && i.limit > 0) return this._read(u => {
            var l = rs(i, i.table.core.schema);
            return i.table.core.query({
                trans: u,
                values: !1,
                limit: i.limit,
                query: {
                    index: l,
                    range: i.range
                }
            })
        }).then(({
            result: u
        }) => u).then(n);
        i.keysOnly = !i.isMatch;
        var a = [];
        return this.each(function(u, l) {
            a.push(l.primaryKey)
        }).then(function() {
            return a
        }).then(n)
    }
    uniqueKeys(n) {
        return this._ctx.unique = "unique", this.keys(n)
    }
    firstKey(n) {
        return this.limit(1).keys(function(i) {
            return i[0]
        }).then(n)
    }
    lastKey(n) {
        return this.reverse().firstKey(n)
    }
    distinct() {
        var n = this._ctx,
            i = n.index && n.table.schema.idxByName[n.index];
        if (!i || !i.multi) return this;
        var a = {};
        return Ya(this._ctx, function(u) {
            var l = u.primaryKey.toString(),
                f = rt(a, l);
            return a[l] = !0, !f
        }), this
    }
    modify(n) {
        var i = this._ctx;
        return this._write(a => {
            var u;
            if (typeof n == "function") u = n;
            else {
                var l = Te(n),
                    f = l.length;
                u = function(I) {
                    for (var L = !1, O = 0; O < f; ++O) {
                        var R = l[O],
                            N = n[R];
                        Gt(I, R) !== N && (yt(I, R, N), L = !0)
                    }
                    return L
                }
            }
            const p = i.table.core,
                {
                    outbound: g,
                    extractKey: E
                } = p.schema.primaryKey,
                v = this.db._options.modifyChunkSize || 200,
                S = [];
            let b = 0;
            const A = [],
                M = (I, L) => {
                    const {
                        failures: O,
                        numFailures: R
                    } = L;
                    b += I - R;
                    for (let N of Te(O)) S.push(O[N])
                };
            return this.clone().primaryKeys().then(I => {
                const L = O => {
                    const R = Math.min(v, I.length - O);
                    return p.getMany({
                        trans: a,
                        keys: I.slice(O, O + R),
                        cache: "immutable"
                    }).then(N => {
                        const W = [],
                            F = [],
                            k = g ? [] : null,
                            B = [];
                        for (let U = 0; U < R; ++U) {
                            const _e = N[U],
                                se = {
                                    value: zr(_e),
                                    primKey: I[O + U]
                                };
                            u.call(se, se.value, se) !== !1 && (se.value == null ? B.push(I[O + U]) : g || He(E(_e), E(se.value)) === 0 ? (F.push(se.value), g && k.push(I[O + U])) : (B.push(I[O + U]), W.push(se.value)))
                        }
                        const Z = $n(i) && i.limit === 1 / 0 && (typeof n != "function" || n === za) && {
                            index: i.index,
                            range: i.range
                        };
                        return Promise.resolve(W.length > 0 && p.mutate({
                            trans: a,
                            type: "add",
                            values: W
                        }).then(U => {
                            for (let _e in U.failures) B.splice(parseInt(_e), 1);
                            M(W.length, U)
                        })).then(() => (F.length > 0 || Z && typeof n == "object") && p.mutate({
                            trans: a,
                            type: "put",
                            keys: k,
                            values: F,
                            criteria: Z,
                            changeSpec: typeof n != "function" && n
                        }).then(U => M(F.length, U))).then(() => (B.length > 0 || Z && n === za) && p.mutate({
                            trans: a,
                            type: "delete",
                            keys: B,
                            criteria: Z
                        }).then(U => M(B.length, U))).then(() => I.length > O + R && L(O + v))
                    })
                };
                return L(0).then(() => {
                    if (S.length > 0) throw new as("Error modifying one or more objects", S, b, A);
                    return I.length
                })
            })
        })
    }
    delete() {
        var n = this._ctx,
            i = n.range;
        return $n(n) && (n.isPrimKey && !ew || i.type === 3) ? this._write(a => {
            const {
                primaryKey: u
            } = n.table.core.schema, l = i;
            return n.table.core.count({
                trans: a,
                query: {
                    index: u,
                    range: l
                }
            }).then(f => n.table.core.mutate({
                trans: a,
                type: "deleteRange",
                range: l
            }).then(({
                failures: p,
                lastResult: g,
                results: E,
                numFailures: v
            }) => {
                if (v) throw new as("Could not delete some values", Object.keys(p).map(S => p[S]), f - v);
                return f - v
            }))
        }) : this.modify(za)
    }
}
const za = (r, n) => n.value = null;

function rw(r, n) {
    return r < n ? -1 : r === n ? 0 : 1
}

function iw(r, n) {
    return r > n ? -1 : r === n ? 0 : 1
}

function nt(r, n, i) {
    var a = r instanceof Lf ? new r.Collection(r) : r;
    return a._ctx.error = i ? new i(n) : new TypeError(n), a
}

function Yn(r) {
    return new r.Collection(r, () => Df("")).limit(0)
}

function sw(r, n, i, a, u, l) {
    for (var f = Math.min(r.length, a.length), p = -1, g = 0; g < f; ++g) {
        var E = n[g];
        if (E !== a[g]) return u(r[g], i[g]) < 0 ? r.substr(0, g) + i[g] + i.substr(g + 1) : u(r[g], a[g]) < 0 ? r.substr(0, g) + a[g] + i.substr(g + 1) : p >= 0 ? r.substr(0, p) + n[p] + i.substr(p + 1) : null;
        u(r[g], E) < 0 && (p = g)
    }
    return f < a.length && l === "next" ? r + i.substr(r.length) : f < r.length && l === "prev" ? r.substr(0, i.length) : p < 0 ? null : r.substr(0, p) + a[p] + i.substr(p + 1)
}

function Vi(r, n, i, a) {
    var u, l, f, p, g, E, v, S = i.length;
    if (!i.every(I => typeof I == "string")) return nt(r, Of);

    function b(I) {
        u = function(O) {
            return O === "next" ? R => R.toUpperCase() : R => R.toLowerCase()
        }(I), l = function(O) {
            return O === "next" ? R => R.toLowerCase() : R => R.toUpperCase()
        }(I), f = I === "next" ? rw : iw;
        var L = i.map(function(O) {
            return {
                lower: l(O),
                upper: u(O)
            }
        }).sort(function(O, R) {
            return f(O.lower, R.lower)
        });
        p = L.map(function(O) {
            return O.upper
        }), g = L.map(function(O) {
            return O.lower
        }), E = I, v = I === "next" ? "" : a
    }
    b("next");
    var A = new r.Collection(r, () => rn(p[0], g[S - 1] + a));
    A._ondirectionchange = function(I) {
        b(I)
    };
    var M = 0;
    return A._addAlgorithm(function(I, L, O) {
        var R = I.key;
        if (typeof R != "string") return !1;
        var N = l(R);
        if (n(N, g, M)) return !0;
        for (var W = null, F = M; F < S; ++F) {
            var k = sw(R, N, p[F], g[F], f, E);
            k === null && W === null ? M = F + 1 : (W === null || f(W, k) > 0) && (W = k)
        }
        return L(W !== null ? function() {
            I.continue(W + v)
        } : O), !1
    }), A
}

function rn(r, n, i, a) {
    return {
        type: 2,
        lower: r,
        upper: n,
        lowerOpen: i,
        upperOpen: a
    }
}

function Df(r) {
    return {
        type: 1,
        lower: r,
        upper: r
    }
}
class Lf {
    get Collection() {
        return this._ctx.table.db.Collection
    }
    between(n, i, a, u) {
        a = a !== !1, u = u === !0;
        try {
            return this._cmp(n, i) > 0 || this._cmp(n, i) === 0 && (a || u) && (!a || !u) ? Yn(this) : new this.Collection(this, () => rn(n, i, !a, !u))
        } catch (l) {
            return nt(this, Ft)
        }
    }
    equals(n) {
        return n == null ? nt(this, Ft) : new this.Collection(this, () => Df(n))
    }
    above(n) {
        return n == null ? nt(this, Ft) : new this.Collection(this, () => rn(n, void 0, !0))
    }
    aboveOrEqual(n) {
        return n == null ? nt(this, Ft) : new this.Collection(this, () => rn(n, void 0, !1))
    }
    below(n) {
        return n == null ? nt(this, Ft) : new this.Collection(this, () => rn(void 0, n, !1, !0))
    }
    belowOrEqual(n) {
        return n == null ? nt(this, Ft) : new this.Collection(this, () => rn(void 0, n))
    }
    startsWith(n) {
        return typeof n != "string" ? nt(this, Of) : this.between(n, n + En, !0, !0)
    }
    startsWithIgnoreCase(n) {
        return n === "" ? this.startsWith(n) : Vi(this, (i, a) => i.indexOf(a[0]) === 0, [n], En)
    }
    equalsIgnoreCase(n) {
        return Vi(this, (i, a) => i === a[0], [n], "")
    }
    anyOfIgnoreCase() {
        var n = Ut.apply(zn, arguments);
        return n.length === 0 ? Yn(this) : Vi(this, (i, a) => a.indexOf(i) !== -1, n, "")
    }
    startsWithAnyOfIgnoreCase() {
        var n = Ut.apply(zn, arguments);
        return n.length === 0 ? Yn(this) : Vi(this, (i, a) => a.some(u => i.indexOf(u) === 0), n, En)
    }
    anyOf() {
        const n = Ut.apply(zn, arguments);
        let i = this._cmp;
        try {
            n.sort(i)
        } catch (l) {
            return nt(this, Ft)
        }
        if (n.length === 0) return Yn(this);
        const a = new this.Collection(this, () => rn(n[0], n[n.length - 1]));
        a._ondirectionchange = l => {
            i = l === "next" ? this._ascending : this._descending, n.sort(i)
        };
        let u = 0;
        return a._addAlgorithm((l, f, p) => {
            const g = l.key;
            for (; i(g, n[u]) > 0;)
                if (++u, u === n.length) return f(p), !1;
            return i(g, n[u]) === 0 || (f(() => {
                l.continue(n[u])
            }), !1)
        }), a
    }
    notEqual(n) {
        return this.inAnyRange([
            [po, n],
            [n, this.db._maxKey]
        ], {
            includeLowers: !1,
            includeUppers: !1
        })
    }
    noneOf() {
        const n = Ut.apply(zn, arguments);
        if (n.length === 0) return new this.Collection(this);
        try {
            n.sort(this._ascending)
        } catch (a) {
            return nt(this, Ft)
        }
        const i = n.reduce((a, u) => a ? a.concat([
            [a[a.length - 1][1], u]
        ]) : [
            [po, u]
        ], null);
        return i.push([n[n.length - 1], this.db._maxKey]), this.inAnyRange(i, {
            includeLowers: !1,
            includeUppers: !1
        })
    }
    inAnyRange(n, i) {
        const a = this._cmp,
            u = this._ascending,
            l = this._descending,
            f = this._min,
            p = this._max;
        if (n.length === 0) return Yn(this);
        if (!n.every(R => R[0] !== void 0 && R[1] !== void 0 && u(R[0], R[1]) <= 0)) return nt(this, "First argument to inAnyRange() must be an Array of two-value Arrays [lower,upper] where upper must not be lower than lower", V.InvalidArgument);
        const g = !i || i.includeLowers !== !1,
            E = i && i.includeUppers === !0;
        let v, S = u;

        function b(R, N) {
            return S(R[0], N[0])
        }
        try {
            v = n.reduce(function(R, N) {
                let W = 0,
                    F = R.length;
                for (; W < F; ++W) {
                    const k = R[W];
                    if (a(N[0], k[1]) < 0 && a(N[1], k[0]) > 0) {
                        k[0] = f(k[0], N[0]), k[1] = p(k[1], N[1]);
                        break
                    }
                }
                return W === F && R.push(N), R
            }, []), v.sort(b)
        } catch (R) {
            return nt(this, Ft)
        }
        let A = 0;
        const M = E ? R => u(R, v[A][1]) > 0 : R => u(R, v[A][1]) >= 0,
            I = g ? R => l(R, v[A][0]) > 0 : R => l(R, v[A][0]) >= 0;
        let L = M;
        const O = new this.Collection(this, () => rn(v[0][0], v[v.length - 1][1], !g, !E));
        return O._ondirectionchange = R => {
            R === "next" ? (L = M, S = u) : (L = I, S = l), v.sort(b)
        }, O._addAlgorithm((R, N, W) => {
            for (var F = R.key; L(F);)
                if (++A, A === v.length) return N(W), !1;
            return !! function(k) {
                return !M(k) && !I(k)
            }(F) || (this._cmp(F, v[A][1]) === 0 || this._cmp(F, v[A][0]) === 0 || N(() => {
                S === u ? R.continue(v[A][0]) : R.continue(v[A][1])
            }), !1)
        }), O
    }
    startsWithAnyOf() {
        const n = Ut.apply(zn, arguments);
        return n.every(i => typeof i == "string") ? n.length === 0 ? Yn(this) : this.inAnyRange(n.map(i => [i, i + En])) : nt(this, "startsWithAnyOf() only works with strings")
    }
}

function Tt(r) {
    return ye(function(n) {
        return Hr(n), r(n.target.error), !1
    })
}

function Hr(r) {
    r.stopPropagation && r.stopPropagation(), r.preventDefault && r.preventDefault()
}
const qr = "storagemutated",
    an = "x-storagemutated-1",
    ln = Nr(null, qr);
class aw {
    _lock() {
        return Pr(!$.global), ++this._reculock, this._reculock !== 1 || $.global || ($.lockOwnerFor = this), this
    }
    _unlock() {
        if (Pr(!$.global), --this._reculock == 0)
            for ($.global || ($.lockOwnerFor = null); this._blockedFuncs.length > 0 && !this._locked();) {
                var n = this._blockedFuncs.shift();
                try {
                    nr(n[1], n[0])
                } catch (i) {}
            }
        return this
    }
    _locked() {
        return this._reculock && $.lockOwnerFor !== this
    }
    create(n) {
        if (!this.mode) return this;
        const i = this.db.idbdb,
            a = this.db._state.dbOpenError;
        if (Pr(!this.idbtrans), !n && !i) switch (a && a.name) {
            case "DatabaseClosedError":
                throw new V.DatabaseClosed(a);
            case "MissingAPIError":
                throw new V.MissingAPI(a.message, a);
            default:
                throw new V.OpenFailed(a)
        }
        if (!this.active) throw new V.TransactionInactive;
        return Pr(this._completion._state === null), (n = this.idbtrans = n || (this.db.core ? this.db.core.transaction(this.storeNames, this.mode, {
            durability: this.chromeTransactionDurability
        }) : i.transaction(this.storeNames, this.mode, {
            durability: this.chromeTransactionDurability
        }))).onerror = ye(u => {
            Hr(u), this._reject(n.error)
        }), n.onabort = ye(u => {
            Hr(u), this.active && this._reject(new V.Abort(n.error)), this.active = !1, this.on("abort").fire(u)
        }), n.oncomplete = ye(() => {
            this.active = !1, this._resolve(), "mutatedParts" in n && ln.storagemutated.fire(n.mutatedParts)
        }), this
    }
    _promise(n, i, a) {
        if (n === "readwrite" && this.mode !== "readwrite") return Ie(new V.ReadOnly("Transaction is readonly"));
        if (!this.active) return Ie(new V.TransactionInactive);
        if (this._locked()) return new H((l, f) => {
            this._blockedFuncs.push([() => {
                this._promise(n, i, a).then(l, f)
            }, $])
        });
        if (a) return on(() => {
            var l = new H((f, p) => {
                this._lock();
                const g = i(f, p, this);
                g && g.then && g.then(f, p)
            });
            return l.finally(() => this._unlock()), l._lib = !0, l
        });
        var u = new H((l, f) => {
            var p = i(l, f, this);
            p && p.then && p.then(l, f)
        });
        return u._lib = !0, u
    }
    _root() {
        return this.parent ? this.parent._root() : this
    }
    waitFor(n) {
        var i = this._root();
        const a = H.resolve(n);
        if (i._waitingFor) i._waitingFor = i._waitingFor.then(() => a);
        else {
            i._waitingFor = a, i._waitingQueue = [];
            var u = i.idbtrans.objectStore(i.storeNames[0]);
            (function f() {
                for (++i._spinCount; i._waitingQueue.length;) i._waitingQueue.shift()();
                i._waitingFor && (u.get(-1 / 0).onsuccess = f)
            })()
        }
        var l = i._waitingFor;
        return new H((f, p) => {
            a.then(g => i._waitingQueue.push(ye(f.bind(null, g))), g => i._waitingQueue.push(ye(p.bind(null, g)))).finally(() => {
                i._waitingFor === l && (i._waitingFor = null)
            })
        })
    }
    abort() {
        this.active && (this.active = !1, this.idbtrans && this.idbtrans.abort(), this._reject(new V.Abort))
    }
    table(n) {
        const i = this._memoizedTables || (this._memoizedTables = {});
        if (rt(i, n)) return i[n];
        const a = this.schema[n];
        if (!a) throw new V.NotFound("Table " + n + " not part of transaction");
        const u = new this.db.Table(n, a, this);
        return u.core = this.db.core.table(n), i[n] = u, u
    }
}

function go(r, n, i, a, u, l, f) {
    return {
        name: r,
        keyPath: n,
        unique: i,
        multi: a,
        auto: u,
        compound: l,
        src: (i && !f ? "&" : "") + (a ? "*" : "") + (u ? "++" : "") + Mf(n)
    }
}

function Mf(r) {
    return typeof r == "string" ? r : r ? "[" + [].join.call(r, "+") + "]" : ""
}

function Bf(r, n, i) {
    return {
        name: r,
        primKey: n,
        indexes: i,
        mappedClass: null,
        idxByName: hf(i, a => [a.name, a])
    }
}
let $r = r => {
    try {
        return r.only([
            []
        ]), $r = () => [
            []
        ], [
            []
        ]
    } catch (n) {
        return $r = () => En, En
    }
};

function _o(r) {
    return r == null ? () => {} : typeof r == "string" ? function(n) {
        return n.split(".").length === 1 ? a => a[n] : a => Gt(a, n)
    }(r) : n => Gt(n, r)
}

function $c(r) {
    return [].slice.call(r)
}
let ow = 0;

function Fr(r) {
    return r == null ? ":id" : typeof r == "string" ? r : `[${r.join("+")}]`
}

function uw(r, n, i) {
    function a(g) {
        if (g.type === 3) return null;
        if (g.type === 4) throw new Error("Cannot convert never type to IDBKeyRange");
        const {
            lower: E,
            upper: v,
            lowerOpen: S,
            upperOpen: b
        } = g;
        return E === void 0 ? v === void 0 ? null : n.upperBound(v, !!b) : v === void 0 ? n.lowerBound(E, !!S) : n.bound(E, v, !!S, !!b)
    }
    const {
        schema: u,
        hasGetAll: l
    } = function(g, E) {
        const v = $c(g.objectStoreNames);
        return {
            schema: {
                name: g.name,
                tables: v.map(S => E.objectStore(S)).map(S => {
                    const {
                        keyPath: b,
                        autoIncrement: A
                    } = S, M = Ue(b), I = b == null, L = {}, O = {
                        name: S.name,
                        primaryKey: {
                            name: null,
                            isPrimaryKey: !0,
                            outbound: I,
                            compound: M,
                            keyPath: b,
                            autoIncrement: A,
                            unique: !0,
                            extractKey: _o(b)
                        },
                        indexes: $c(S.indexNames).map(R => S.index(R)).map(R => {
                            const {
                                name: N,
                                unique: W,
                                multiEntry: F,
                                keyPath: k
                            } = R, B = {
                                name: N,
                                compound: Ue(k),
                                keyPath: k,
                                unique: W,
                                multiEntry: F,
                                extractKey: _o(k)
                            };
                            return L[Fr(k)] = B, B
                        }),
                        getIndexByKeyPath: R => L[Fr(R)]
                    };
                    return L[":id"] = O.primaryKey, b != null && (L[Fr(b)] = O.primaryKey), O
                })
            },
            hasGetAll: v.length > 0 && "getAll" in E.objectStore(v[0]) && !(typeof navigator != "undefined" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604)
        }
    }(r, i), f = u.tables.map(g => function(E) {
        const v = E.name;
        return {
            name: v,
            schema: E,
            mutate: function({
                trans: S,
                type: b,
                keys: A,
                values: M,
                range: I
            }) {
                return new Promise((L, O) => {
                    L = ye(L);
                    const R = S.objectStore(v),
                        N = R.keyPath == null,
                        W = b === "put" || b === "add";
                    if (!W && b !== "delete" && b !== "deleteRange") throw new Error("Invalid operation type: " + b);
                    const {
                        length: F
                    } = A || M || {
                        length: 1
                    };
                    if (A && M && A.length !== M.length) throw new Error("Given keys array must have same length as given values array.");
                    if (F === 0) return L({
                        numFailures: 0,
                        failures: {},
                        results: [],
                        lastResult: void 0
                    });
                    let k;
                    const B = [],
                        Z = [];
                    let U = 0;
                    const _e = Ce => {
                        ++U, Hr(Ce)
                    };
                    if (b === "deleteRange") {
                        if (I.type === 4) return L({
                            numFailures: U,
                            failures: Z,
                            results: [],
                            lastResult: void 0
                        });
                        I.type === 3 ? B.push(k = R.clear()) : B.push(k = R.delete(a(I)))
                    } else {
                        const [Ce, Re] = W ? N ? [M, A] : [M, null] : [A, null];
                        if (W)
                            for (let de = 0; de < F; ++de) B.push(k = Re && Re[de] !== void 0 ? R[b](Ce[de], Re[de]) : R[b](Ce[de])), k.onerror = _e;
                        else
                            for (let de = 0; de < F; ++de) B.push(k = R[b](Ce[de])), k.onerror = _e
                    }
                    const se = Ce => {
                        const Re = Ce.target.result;
                        B.forEach((de, qt) => de.error != null && (Z[qt] = de.error)), L({
                            numFailures: U,
                            failures: Z,
                            results: b === "delete" ? A : B.map(de => de.result),
                            lastResult: Re
                        })
                    };
                    k.onerror = Ce => {
                        _e(Ce), se(Ce)
                    }, k.onsuccess = se
                })
            },
            getMany: ({
                trans: S,
                keys: b
            }) => new Promise((A, M) => {
                A = ye(A);
                const I = S.objectStore(v),
                    L = b.length,
                    O = new Array(L);
                let R, N = 0,
                    W = 0;
                const F = B => {
                        const Z = B.target;
                        O[Z._pos] = Z.result, ++W === N && A(O)
                    },
                    k = Tt(M);
                for (let B = 0; B < L; ++B) b[B] != null && (R = I.get(b[B]), R._pos = B, R.onsuccess = F, R.onerror = k, ++N);
                N === 0 && A(O)
            }),
            get: ({
                trans: S,
                key: b
            }) => new Promise((A, M) => {
                A = ye(A);
                const I = S.objectStore(v).get(b);
                I.onsuccess = L => A(L.target.result), I.onerror = Tt(M)
            }),
            query: function(S) {
                return b => new Promise((A, M) => {
                    A = ye(A);
                    const {
                        trans: I,
                        values: L,
                        limit: O,
                        query: R
                    } = b, N = O === 1 / 0 ? void 0 : O, {
                        index: W,
                        range: F
                    } = R, k = I.objectStore(v), B = W.isPrimaryKey ? k : k.index(W.name), Z = a(F);
                    if (O === 0) return A({
                        result: []
                    });
                    if (S) {
                        const U = L ? B.getAll(Z, N) : B.getAllKeys(Z, N);
                        U.onsuccess = _e => A({
                            result: _e.target.result
                        }), U.onerror = Tt(M)
                    } else {
                        let U = 0;
                        const _e = L || !("openKeyCursor" in B) ? B.openCursor(Z) : B.openKeyCursor(Z),
                            se = [];
                        _e.onsuccess = Ce => {
                            const Re = _e.result;
                            return Re ? (se.push(L ? Re.value : Re.primaryKey), ++U === O ? A({
                                result: se
                            }) : void Re.continue()) : A({
                                result: se
                            })
                        }, _e.onerror = Tt(M)
                    }
                })
            }(l),
            openCursor: function({
                trans: S,
                values: b,
                query: A,
                reverse: M,
                unique: I
            }) {
                return new Promise((L, O) => {
                    L = ye(L);
                    const {
                        index: R,
                        range: N
                    } = A, W = S.objectStore(v), F = R.isPrimaryKey ? W : W.index(R.name), k = M ? I ? "prevunique" : "prev" : I ? "nextunique" : "next", B = b || !("openKeyCursor" in F) ? F.openCursor(a(N), k) : F.openKeyCursor(a(N), k);
                    B.onerror = Tt(O), B.onsuccess = ye(Z => {
                        const U = B.result;
                        if (!U) return void L(null);
                        U.___id = ++ow, U.done = !1;
                        const _e = U.continue.bind(U);
                        let se = U.continuePrimaryKey;
                        se && (se = se.bind(U));
                        const Ce = U.advance.bind(U),
                            Re = () => {
                                throw new Error("Cursor not stopped")
                            };
                        U.trans = S, U.stop = U.continue = U.continuePrimaryKey = U.advance = () => {
                            throw new Error("Cursor not started")
                        }, U.fail = ye(O), U.next = function() {
                            let de = 1;
                            return this.start(() => de-- ? this.continue() : this.stop()).then(() => this)
                        }, U.start = de => {
                            const qt = new Promise((we, Be) => {
                                    we = ye(we), B.onerror = Tt(Be), U.fail = Be, U.stop = cn => {
                                        U.stop = U.continue = U.continuePrimaryKey = U.advance = Re, we(cn)
                                    }
                                }),
                                $t = () => {
                                    if (B.result) try {
                                        de()
                                    } catch (we) {
                                        U.fail(we)
                                    } else U.done = !0, U.start = () => {
                                        throw new Error("Cursor behind last entry")
                                    }, U.stop()
                                };
                            return B.onsuccess = ye(we => {
                                B.onsuccess = $t, $t()
                            }), U.continue = _e, U.continuePrimaryKey = se, U.advance = Ce, $t(), qt
                        }, L(U)
                    }, O)
                })
            },
            count({
                query: S,
                trans: b
            }) {
                const {
                    index: A,
                    range: M
                } = S;
                return new Promise((I, L) => {
                    const O = b.objectStore(v),
                        R = A.isPrimaryKey ? O : O.index(A.name),
                        N = a(M),
                        W = N ? R.count(N) : R.count();
                    W.onsuccess = ye(F => I(F.target.result)), W.onerror = Tt(L)
                })
            }
        }
    }(g)), p = {};
    return f.forEach(g => p[g.name] = g), {
        stack: "dbcore",
        transaction: r.transaction.bind(r),
        table(g) {
            if (!p[g]) throw new Error(`Table '${g}' not found`);
            return p[g]
        },
        MIN_KEY: -1 / 0,
        MAX_KEY: $r(n),
        schema: u
    }
}

function mo({
    _novip: r
}, n) {
    const i = n.db,
        a = function(u, l, {
            IDBKeyRange: f,
            indexedDB: p
        }, g) {
            return {
                dbcore: function(v, S) {
                    return S.reduce((b, {
                        create: A
                    }) => ({
                        ...b,
                        ...A(b)
                    }), v)
                }(uw(l, f, g), u.dbcore)
            }
        }(r._middlewares, i, r._deps, n);
    r.core = a.dbcore, r.tables.forEach(u => {
        const l = u.name;
        r.core.schema.tables.some(f => f.name === l) && (u.core = r.core.table(l), r[l] instanceof r.Table && (r[l].core = u.core))
    })
}

function fs({
    _novip: r
}, n, i, a) {
    i.forEach(u => {
        const l = a[u];
        n.forEach(f => {
            const p = Oo(f, u);
            (!p || "value" in p && p.value === void 0) && (f === r.Transaction.prototype || f instanceof r.Transaction ? Wt(f, u, {
                get() {
                    return this.table(u)
                },
                set(g) {
                    lf(this, u, {
                        value: g,
                        writable: !0,
                        configurable: !0,
                        enumerable: !0
                    })
                }
            }) : f[u] = new r.Table(u, l))
        })
    })
}

function yo({
    _novip: r
}, n) {
    n.forEach(i => {
        for (let a in i) i[a] instanceof r.Table && delete i[a]
    })
}

function lw(r, n) {
    return r._cfg.version - n._cfg.version
}

function cw(r, n, i, a) {
    const u = r._dbSchema,
        l = r._createTransaction("readwrite", r._storeNames, u);
    l.create(i), l._completion.catch(a);
    const f = l._reject.bind(l),
        p = $.transless || $;
    on(() => {
        $.trans = l, $.transless = p, n === 0 ? (Te(u).forEach(g => {
            Va(i, g, u[g].primKey, u[g].indexes)
        }), mo(r, i), H.follow(() => r.on.populate.fire(l)).catch(f)) : function({
            _novip: g
        }, E, v, S) {
            const b = [],
                A = g._versions;
            let M = g._dbSchema = wo(g, g.idbdb, S),
                I = !1;
            const L = A.filter(R => R._cfg.version >= E);

            function O() {
                return b.length ? H.resolve(b.shift()(v.idbtrans)).then(O) : H.resolve()
            }
            return L.forEach(R => {
                b.push(() => {
                    const N = M,
                        W = R._cfg.dbschema;
                    bo(g, N, S), bo(g, W, S), M = g._dbSchema = W;
                    const F = Nf(N, W);
                    F.add.forEach(B => {
                        Va(S, B[0], B[1].primKey, B[1].indexes)
                    }), F.change.forEach(B => {
                        if (B.recreate) throw new V.Upgrade("Not yet support for changing primary key");
                        {
                            const Z = S.objectStore(B.name);
                            B.add.forEach(U => vo(Z, U)), B.change.forEach(U => {
                                Z.deleteIndex(U.name), vo(Z, U)
                            }), B.del.forEach(U => Z.deleteIndex(U))
                        }
                    });
                    const k = R._cfg.contentUpgrade;
                    if (k && R._cfg.version > E) {
                        mo(g, S), v._memoizedTables = {}, I = !0;
                        let B = df(W);
                        F.del.forEach(se => {
                            B[se] = N[se]
                        }), yo(g, [g.Transaction.prototype]), fs(g, [g.Transaction.prototype], Te(B), B), v.schema = B;
                        const Z = Po(k);
                        let U;
                        Z && tr();
                        const _e = H.follow(() => {
                            if (U = k(v), U && Z) {
                                var se = Ht.bind(null, null);
                                U.then(se, se)
                            }
                        });
                        return U && typeof U.then == "function" ? H.resolve(U) : _e.then(() => U)
                    }
                }), b.push(N => {
                    (!I || !J0) && function(W, F) {
                        [].slice.call(F.db.objectStoreNames).forEach(k => W[k] == null && F.db.deleteObjectStore(k))
                    }(R._cfg.dbschema, N), yo(g, [g.Transaction.prototype]), fs(g, [g.Transaction.prototype], g._storeNames, g._dbSchema), v.schema = g._dbSchema
                })
            }), O().then(() => {
                var R, N;
                N = S, Te(R = M).forEach(W => {
                    N.db.objectStoreNames.contains(W) || Va(N, W, R[W].primKey, R[W].indexes)
                })
            })
        }(r, n, l, i).catch(f)
    })
}

function Nf(r, n) {
    const i = {
        del: [],
        add: [],
        change: []
    };
    let a;
    for (a in r) n[a] || i.del.push(a);
    for (a in n) {
        const u = r[a],
            l = n[a];
        if (u) {
            const f = {
                name: a,
                def: l,
                recreate: !1,
                del: [],
                add: [],
                change: []
            };
            if ("" + (u.primKey.keyPath || "") != "" + (l.primKey.keyPath || "") || u.primKey.auto !== l.primKey.auto && !gs) f.recreate = !0, i.change.push(f);
            else {
                const p = u.idxByName,
                    g = l.idxByName;
                let E;
                for (E in p) g[E] || f.del.push(E);
                for (E in g) {
                    const v = p[E],
                        S = g[E];
                    v ? v.src !== S.src && f.change.push(S) : f.add.push(S)
                }(f.del.length > 0 || f.add.length > 0 || f.change.length > 0) && i.change.push(f)
            }
        } else i.add.push([a, l])
    }
    return i
}

function Va(r, n, i, a) {
    const u = r.db.createObjectStore(n, i.keyPath ? {
        keyPath: i.keyPath,
        autoIncrement: i.auto
    } : {
        autoIncrement: i.auto
    });
    return a.forEach(l => vo(u, l)), u
}

function vo(r, n) {
    r.createIndex(n.name, n.keyPath, {
        unique: n.unique,
        multiEntry: n.multi
    })
}

function wo(r, n, i) {
    const a = {};
    return ss(n.objectStoreNames, 0).forEach(u => {
        const l = i.objectStore(u);
        let f = l.keyPath;
        const p = go(Mf(f), f || "", !1, !1, !!l.autoIncrement, f && typeof f != "string", !0),
            g = [];
        for (let v = 0; v < l.indexNames.length; ++v) {
            const S = l.index(l.indexNames[v]);
            f = S.keyPath;
            var E = go(S.name, f, !!S.unique, !!S.multiEntry, !1, f && typeof f != "string", !1);
            g.push(E)
        }
        a[u] = Bf(u, p, g)
    }), a
}

function bo({
    _novip: r
}, n, i) {
    const a = i.db.objectStoreNames;
    for (let u = 0; u < a.length; ++u) {
        const l = a[u],
            f = i.objectStore(l);
        r._hasGetAll = "getAll" in f;
        for (let p = 0; p < f.indexNames.length; ++p) {
            const g = f.indexNames[p],
                E = f.index(g).keyPath,
                v = typeof E == "string" ? E : "[" + ss(E).join("+") + "]";
            if (n[l]) {
                const S = n[l].idxByName[v];
                S && (S.name = g, delete n[l].idxByName[v], n[l].idxByName[g] = S)
            }
        }
    }
    typeof navigator != "undefined" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && ge.WorkerGlobalScope && ge instanceof ge.WorkerGlobalScope && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604 && (r._hasGetAll = !1)
}
class fw {
    _parseStoresSpec(n, i) {
        Te(n).forEach(a => {
            if (n[a] !== null) {
                var u = n[a].split(",").map((f, p) => {
                        const g = (f = f.trim()).replace(/([&*]|\+\+)/g, ""),
                            E = /^\[/.test(g) ? g.match(/^\[(.*)\]$/)[1].split("+") : g;
                        return go(g, E || null, /\&/.test(f), /\*/.test(f), /\+\+/.test(f), Ue(E), p === 0)
                    }),
                    l = u.shift();
                if (l.multi) throw new V.Schema("Primary key cannot be multi-valued");
                u.forEach(f => {
                    if (f.auto) throw new V.Schema("Only primary key can be marked as autoIncrement (++)");
                    if (!f.keyPath) throw new V.Schema("Index must have a name and cannot be an empty string")
                }), i[a] = Bf(a, l, u)
            }
        })
    }
    stores(n) {
        const i = this.db;
        this._cfg.storesSource = this._cfg.storesSource ? qe(this._cfg.storesSource, n) : n;
        const a = i._versions,
            u = {};
        let l = {};
        return a.forEach(f => {
            qe(u, f._cfg.storesSource), l = f._cfg.dbschema = {}, f._parseStoresSpec(u, l)
        }), i._dbSchema = l, yo(i, [i._allTables, i, i.Transaction.prototype]), fs(i, [i._allTables, i, i.Transaction.prototype, this._cfg.tables], Te(l), l), i._storeNames = Te(l), this
    }
    upgrade(n) {
        return this._cfg.contentUpgrade = Lo(this._cfg.contentUpgrade || ce, n), this
    }
}

function Fo(r, n) {
    let i = r._dbNamesDB;
    return i || (i = r._dbNamesDB = new An(_s, {
        addons: [],
        indexedDB: r,
        IDBKeyRange: n
    }), i.version(1).stores({
        dbnames: "name"
    })), i.table("dbnames")
}

function ko(r) {
    return r && typeof r.databases == "function"
}

function Eo(r) {
    return on(function() {
        return $.letThrough = !0, r()
    })
}

function hw() {
    var r;
    return !navigator.userAgentData && /Safari\//.test(navigator.userAgent) && !/Chrom(e|ium)\//.test(navigator.userAgent) && indexedDB.databases ? new Promise(function(n) {
        var i = function() {
            return indexedDB.databases().finally(n)
        };
        r = setInterval(i, 100), i()
    }).finally(function() {
        return clearInterval(r)
    }) : Promise.resolve()
}

function dw(r) {
    const n = r._state,
        {
            indexedDB: i
        } = r._deps;
    if (n.isBeingOpened || r.idbdb) return n.dbReadyPromise.then(() => n.dbOpenError ? Ie(n.dbOpenError) : r);
    At && (n.openCanceller._stackHolder = Rn()), n.isBeingOpened = !0, n.dbOpenError = null, n.openComplete = !1;
    const a = n.openCanceller;

    function u() {
        if (n.openCanceller !== a) throw new V.DatabaseClosed("db.open() was cancelled")
    }
    let l = n.dbReadyResolve,
        f = null,
        p = !1;
    return H.race([a, (typeof navigator == "undefined" ? H.resolve() : hw()).then(() => new H((g, E) => {
        if (u(), !i) throw new V.MissingAPI;
        const v = r.name,
            S = n.autoSchema ? i.open(v) : i.open(v, Math.round(10 * r.verno));
        if (!S) throw new V.MissingAPI;
        S.onerror = Tt(E), S.onblocked = ye(r._fireOnBlocked), S.onupgradeneeded = ye(b => {
            if (f = S.transaction, n.autoSchema && !r._options.allowEmptyDB) {
                S.onerror = Hr, f.abort(), S.result.close();
                const M = i.deleteDatabase(v);
                M.onsuccess = M.onerror = ye(() => {
                    E(new V.NoSuchDatabase(`Database ${v} doesnt exist`))
                })
            } else {
                f.onerror = Tt(E);
                var A = b.oldVersion > Math.pow(2, 62) ? 0 : b.oldVersion;
                p = A < 1, r._novip.idbdb = S.result, cw(r, A / 10, f, E)
            }
        }, E), S.onsuccess = ye(() => {
            f = null;
            const b = r._novip.idbdb = S.result,
                A = ss(b.objectStoreNames);
            if (A.length > 0) try {
                const I = b.transaction((M = A).length === 1 ? M[0] : M, "readonly");
                n.autoSchema ? function({
                    _novip: L
                }, O, R) {
                    L.verno = O.version / 10;
                    const N = L._dbSchema = wo(0, O, R);
                    L._storeNames = ss(O.objectStoreNames, 0), fs(L, [L._allTables], Te(N), N)
                }(r, b, I) : (bo(r, r._dbSchema, I), function(L, O) {
                    const R = Nf(wo(0, L.idbdb, O), L._dbSchema);
                    return !(R.add.length || R.change.some(N => N.add.length || N.change.length))
                }(r, I)), mo(r, I)
            } catch (I) {}
            var M;
            Br.push(r), b.onversionchange = ye(I => {
                n.vcFired = !0, r.on("versionchange").fire(I)
            }), b.onclose = ye(I => {
                r.on("close").fire(I)
            }), p && function({
                indexedDB: I,
                IDBKeyRange: L
            }, O) {
                !ko(I) && O !== _s && Fo(I, L).put({
                    name: O
                }).catch(ce)
            }(r._deps, v), g()
        }, E)
    }))]).then(() => (u(), n.onReadyBeingFired = [], H.resolve(Eo(() => r.on.ready.fire(r.vip))).then(function g() {
        if (n.onReadyBeingFired.length > 0) {
            let E = n.onReadyBeingFired.reduce(Lo, ce);
            return n.onReadyBeingFired = [], H.resolve(Eo(() => E(r.vip))).then(g)
        }
    }))).finally(() => {
        n.onReadyBeingFired = null, n.isBeingOpened = !1
    }).then(() => r).catch(g => {
        n.dbOpenError = g;
        try {
            f && f.abort()
        } catch (E) {}
        return a === n.openCanceller && r._close(), Ie(g)
    }).finally(() => {
        n.openComplete = !0, l()
    })
}

function So(r) {
    var n = l => r.next(l),
        i = u(n),
        a = u(l => r.throw(l));

    function u(l) {
        return f => {
            var p = l(f),
                g = p.value;
            return p.done ? g : g && typeof g.then == "function" ? g.then(i, a) : Ue(g) ? Promise.all(g).then(i, a) : i(g)
        }
    }
    return u(n)()
}

function pw(r, n, i) {
    var a = arguments.length;
    if (a < 2) throw new V.InvalidArgument("Too few arguments");
    for (var u = new Array(a - 1); --a;) u[a - 1] = arguments[a];
    return i = u.pop(), [r, pf(u), i]
}

function Ff(r, n, i, a, u) {
    return H.resolve().then(() => {
        const l = $.transless || $,
            f = r._createTransaction(n, i, r._dbSchema, a),
            p = {
                trans: f,
                transless: l
            };
        if (a) f.idbtrans = a.idbtrans;
        else try {
            f.create(), r._state.PR1398_maxLoop = 3
        } catch (S) {
            return S.name === Do.InvalidState && r.isOpen() && --r._state.PR1398_maxLoop > 0 ? (r._close(), r.open().then(() => Ff(r, n, i, null, u))) : Ie(S)
        }
        const g = Po(u);
        let E;
        g && tr();
        const v = H.follow(() => {
            if (E = u.call(f, f), E)
                if (g) {
                    var S = Ht.bind(null, null);
                    E.then(S, S)
                } else typeof E.next == "function" && typeof E.throw == "function" && (E = So(E))
        }, p);
        return (E && typeof E.then == "function" ? H.resolve(E).then(S => f.active ? S : Ie(new V.PrematureCommit("Transaction committed too early. See http://bit.ly/2kdckMn"))) : v.then(() => E)).then(S => (a && f._resolve(), f._completion.then(() => S))).catch(S => (f._reject(S), Ie(S)))
    })
}

function Xi(r, n, i) {
    const a = Ue(r) ? r.slice() : [r];
    for (let u = 0; u < i; ++u) a.push(n);
    return a
}
const gw = {
    stack: "dbcore",
    name: "VirtualIndexMiddleware",
    level: 1,
    create: function(r) {
        return {
            ...r,
            table(n) {
                const i = r.table(n),
                    {
                        schema: a
                    } = i,
                    u = {},
                    l = [];

                function f(v, S, b) {
                    const A = Fr(v),
                        M = u[A] = u[A] || [],
                        I = v == null ? 0 : typeof v == "string" ? 1 : v.length,
                        L = S > 0,
                        O = {
                            ...b,
                            isVirtual: L,
                            keyTail: S,
                            keyLength: I,
                            extractKey: _o(v),
                            unique: !L && b.unique
                        };
                    return M.push(O), O.isPrimaryKey || l.push(O), I > 1 && f(I === 2 ? v[0] : v.slice(0, I - 1), S + 1, b), M.sort((R, N) => R.keyTail - N.keyTail), O
                }
                const p = f(a.primaryKey.keyPath, 0, a.primaryKey);
                u[":id"] = [p];
                for (const v of a.indexes) f(v.keyPath, 0, v);

                function g(v) {
                    const S = v.query.index;
                    return S.isVirtual ? {
                        ...v,
                        query: {
                            index: S,
                            range: (b = v.query.range, A = S.keyTail, {
                                type: b.type === 1 ? 2 : b.type,
                                lower: Xi(b.lower, b.lowerOpen ? r.MAX_KEY : r.MIN_KEY, A),
                                lowerOpen: !0,
                                upper: Xi(b.upper, b.upperOpen ? r.MIN_KEY : r.MAX_KEY, A),
                                upperOpen: !0
                            })
                        }
                    } : v;
                    var b, A
                }
                return {
                    ...i,
                    schema: {
                        ...a,
                        primaryKey: p,
                        indexes: l,
                        getIndexByKeyPath: function(v) {
                            const S = u[Fr(v)];
                            return S && S[0]
                        }
                    },
                    count: v => i.count(g(v)),
                    query: v => i.query(g(v)),
                    openCursor(v) {
                        const {
                            keyTail: S,
                            isVirtual: b,
                            keyLength: A
                        } = v.query.index;
                        return b ? i.openCursor(g(v)).then(M => M && function(I) {
                            return Object.create(I, {
                                continue: {
                                    value: function(O) {
                                        O != null ? I.continue(Xi(O, v.reverse ? r.MAX_KEY : r.MIN_KEY, S)) : v.unique ? I.continue(I.key.slice(0, A).concat(v.reverse ? r.MIN_KEY : r.MAX_KEY, S)) : I.continue()
                                    }
                                },
                                continuePrimaryKey: {
                                    value(O, R) {
                                        I.continuePrimaryKey(Xi(O, r.MAX_KEY, S), R)
                                    }
                                },
                                primaryKey: {
                                    get: () => I.primaryKey
                                },
                                key: {
                                    get() {
                                        const O = I.key;
                                        return A === 1 ? O[0] : O.slice(0, A)
                                    }
                                },
                                value: {
                                    get: () => I.value
                                }
                            })
                        }(M)) : i.openCursor(v)
                    }
                }
            }
        }
    }
};

function Uo(r, n, i, a) {
    return i = i || {}, a = a || "", Te(r).forEach(u => {
        if (rt(n, u)) {
            var l = r[u],
                f = n[u];
            if (typeof l == "object" && typeof f == "object" && l && f) {
                const p = to(l);
                p !== to(f) ? i[a + u] = n[u] : p === "Object" ? Uo(l, f, i, a + u + ".") : l !== f && (i[a + u] = n[u])
            } else l !== f && (i[a + u] = n[u])
        } else i[a + u] = void 0
    }), Te(n).forEach(u => {
        rt(r, u) || (i[a + u] = n[u])
    }), i
}
const _w = {
    stack: "dbcore",
    name: "HooksMiddleware",
    level: 2,
    create: r => ({
        ...r,
        table(n) {
            const i = r.table(n),
                {
                    primaryKey: a
                } = i.schema;
            return {
                ...i,
                mutate(l) {
                    const f = $.trans,
                        {
                            deleting: p,
                            creating: g,
                            updating: E
                        } = f.table(n).hook;
                    switch (l.type) {
                        case "add":
                            if (g.fire === ce) break;
                            return f._promise("readwrite", () => v(l), !0);
                        case "put":
                            if (g.fire === ce && E.fire === ce) break;
                            return f._promise("readwrite", () => v(l), !0);
                        case "delete":
                            if (p.fire === ce) break;
                            return f._promise("readwrite", () => v(l), !0);
                        case "deleteRange":
                            if (p.fire === ce) break;
                            return f._promise("readwrite", () => function(b) {
                                return S(b.trans, b.range, 1e4)
                            }(l), !0)
                    }
                    return i.mutate(l);

                    function v(b) {
                        const A = $.trans,
                            M = b.keys || function(I, L) {
                                return L.type === "delete" ? L.keys : L.keys || L.values.map(I.extractKey)
                            }(a, b);
                        if (!M) throw new Error("Keys missing");
                        return (b = b.type === "add" || b.type === "put" ? {
                                ...b,
                                keys: M
                            } : {
                                ...b
                            }).type !== "delete" && (b.values = [...b.values]), b.keys && (b.keys = [...b.keys]),
                            function(I, L, O) {
                                return L.type === "add" ? Promise.resolve([]) : I.getMany({
                                    trans: L.trans,
                                    keys: O,
                                    cache: "immutable"
                                })
                            }(i, b, M).then(I => {
                                const L = M.map((O, R) => {
                                    const N = I[R],
                                        W = {
                                            onerror: null,
                                            onsuccess: null
                                        };
                                    if (b.type === "delete") p.fire.call(W, O, N, A);
                                    else if (b.type === "add" || N === void 0) {
                                        const F = g.fire.call(W, O, b.values[R], A);
                                        O == null && F != null && (O = F, b.keys[R] = O, a.outbound || yt(b.values[R], a.keyPath, O))
                                    } else {
                                        const F = Uo(N, b.values[R]),
                                            k = E.fire.call(W, F, O, N, A);
                                        if (k) {
                                            const B = b.values[R];
                                            Object.keys(k).forEach(Z => {
                                                rt(B, Z) ? B[Z] = k[Z] : yt(B, Z, k[Z])
                                            })
                                        }
                                    }
                                    return W
                                });
                                return i.mutate(b).then(({
                                    failures: O,
                                    results: R,
                                    numFailures: N,
                                    lastResult: W
                                }) => {
                                    for (let F = 0; F < M.length; ++F) {
                                        const k = R ? R[F] : M[F],
                                            B = L[F];
                                        k == null ? B.onerror && B.onerror(O[F]) : B.onsuccess && B.onsuccess(b.type === "put" && I[F] ? b.values[F] : k)
                                    }
                                    return {
                                        failures: O,
                                        results: R,
                                        numFailures: N,
                                        lastResult: W
                                    }
                                }).catch(O => (L.forEach(R => R.onerror && R.onerror(O)), Promise.reject(O)))
                            })
                    }

                    function S(b, A, M) {
                        return i.query({
                            trans: b,
                            values: !1,
                            query: {
                                index: a,
                                range: A
                            },
                            limit: M
                        }).then(({
                            result: I
                        }) => v({
                            type: "delete",
                            keys: I,
                            trans: b
                        }).then(L => L.numFailures > 0 ? Promise.reject(L.failures[0]) : I.length < M ? {
                            failures: [],
                            numFailures: 0,
                            lastResult: void 0
                        } : S(b, {
                            ...A,
                            lower: I[I.length - 1],
                            lowerOpen: !0
                        }, M)))
                    }
                }
            }
        }
    })
};

function kf(r, n, i) {
    try {
        if (!n || n.keys.length < r.length) return null;
        const a = [];
        for (let u = 0, l = 0; u < n.keys.length && l < r.length; ++u) He(n.keys[u], r[l]) === 0 && (a.push(i ? zr(n.values[u]) : n.values[u]), ++l);
        return a.length === r.length ? a : null
    } catch (a) {
        return null
    }
}
const mw = {
    stack: "dbcore",
    level: -1,
    create: r => ({
        table: n => {
            const i = r.table(n);
            return {
                ...i,
                getMany: a => {
                    if (!a.cache) return i.getMany(a);
                    const u = kf(a.keys, a.trans._cache, a.cache === "clone");
                    return u ? H.resolve(u) : i.getMany(a).then(l => (a.trans._cache = {
                        keys: a.keys,
                        values: a.cache === "clone" ? zr(l) : l
                    }, l))
                },
                mutate: a => (a.type !== "add" && (a.trans._cache = null), i.mutate(a))
            }
        }
    })
};

function Ko(r) {
    return !("from" in r)
}
const kt = function(r, n) {
    if (!this) {
        const i = new kt;
        return r && "d" in r && qe(i, r), i
    }
    qe(this, arguments.length ? {
        d: 1,
        from: r,
        to: arguments.length > 1 ? n : r
    } : {
        d: 0
    })
};

function Yr(r, n, i) {
    const a = He(n, i);
    if (isNaN(a)) return;
    if (a > 0) throw RangeError();
    if (Ko(r)) return qe(r, {
        from: n,
        to: i,
        d: 1
    });
    const u = r.l,
        l = r.r;
    if (He(i, r.from) < 0) return u ? Yr(u, n, i) : r.l = {
        from: n,
        to: i,
        d: 1,
        l: null,
        r: null
    }, Yc(r);
    if (He(n, r.to) > 0) return l ? Yr(l, n, i) : r.r = {
        from: n,
        to: i,
        d: 1,
        l: null,
        r: null
    }, Yc(r);
    He(n, r.from) < 0 && (r.from = n, r.l = null, r.d = l ? l.d + 1 : 1), He(i, r.to) > 0 && (r.to = i, r.r = null, r.d = r.l ? r.l.d + 1 : 1);
    const f = !r.r;
    u && !r.l && hs(r, u), l && f && hs(r, l)
}

function hs(r, n) {
    Ko(n) || function i(a, {
        from: u,
        to: l,
        l: f,
        r: p
    }) {
        Yr(a, u, l), f && i(a, f), p && i(a, p)
    }(r, n)
}

function yw(r, n) {
    const i = To(n);
    let a = i.next();
    if (a.done) return !1;
    let u = a.value;
    const l = To(r);
    let f = l.next(u.from),
        p = f.value;
    for (; !a.done && !f.done;) {
        if (He(p.from, u.to) <= 0 && He(p.to, u.from) >= 0) return !0;
        He(u.from, p.from) < 0 ? u = (a = i.next(p.from)).value : p = (f = l.next(u.from)).value
    }
    return !1
}

function To(r) {
    let n = Ko(r) ? null : {
        s: 0,
        n: r
    };
    return {
        next(i) {
            const a = arguments.length > 0;
            for (; n;) switch (n.s) {
                case 0:
                    if (n.s = 1, a)
                        for (; n.n.l && He(i, n.n.from) < 0;) n = {
                            up: n,
                            n: n.n.l,
                            s: 1
                        };
                    else
                        for (; n.n.l;) n = {
                            up: n,
                            n: n.n.l,
                            s: 1
                        };
                case 1:
                    if (n.s = 2, !a || He(i, n.n.to) <= 0) return {
                        value: n.n,
                        done: !1
                    };
                case 2:
                    if (n.n.r) {
                        n.s = 3, n = {
                            up: n,
                            n: n.n.r,
                            s: 0
                        };
                        continue
                    }
                case 3:
                    n = n.up
            }
            return {
                done: !0
            }
        }
    }
}

function Yc(r) {
    var n, i;
    const a = (((n = r.r) === null || n === void 0 ? void 0 : n.d) || 0) - (((i = r.l) === null || i === void 0 ? void 0 : i.d) || 0),
        u = a > 1 ? "r" : a < -1 ? "l" : "";
    if (u) {
        const l = u === "r" ? "l" : "r",
            f = {
                ...r
            },
            p = r[u];
        r.from = p.from, r.to = p.to, r[u] = p[u], f[u] = p[l], r[l] = f, f.d = jc(f)
    }
    r.d = jc(r)
}

function jc({
    r,
    l: n
}) {
    return (r ? n ? Math.max(r.d, n.d) : r.d : n ? n.d : 0) + 1
}
Zn(kt.prototype, {
    add(r) {
        return hs(this, r), this
    },
    addKey(r) {
        return Yr(this, r, r), this
    },
    addKeys(r) {
        return r.forEach(n => Yr(this, n, n)), this
    },
    [no]() {
        return To(this)
    }
});
const vw = {
    stack: "dbcore",
    level: 0,
    create: r => {
        const n = r.schema.name,
            i = new kt(r.MIN_KEY, r.MAX_KEY);
        return {
            ...r,
            table: a => {
                const u = r.table(a),
                    {
                        schema: l
                    } = u,
                    {
                        primaryKey: f
                    } = l,
                    {
                        extractKey: p,
                        outbound: g
                    } = f,
                    E = {
                        ...u,
                        mutate: b => {
                            const A = b.trans,
                                M = A.mutatedParts || (A.mutatedParts = {}),
                                I = k => {
                                    const B = `idb://${n}/${a}/${k}`;
                                    return M[B] || (M[B] = new kt)
                                },
                                L = I(""),
                                O = I(":dels"),
                                {
                                    type: R
                                } = b;
                            let [N, W] = b.type === "deleteRange" ? [b.range] : b.type === "delete" ? [b.keys] : b.values.length < 50 ? [
                                [], b.values
                            ] : [];
                            const F = b.trans._cache;
                            return u.mutate(b).then(k => {
                                if (Ue(N)) {
                                    R !== "delete" && (N = k.results), L.addKeys(N);
                                    const B = kf(N, F);
                                    B || R === "add" || O.addKeys(N), (B || W) && function(Z, U, _e, se) {
                                        function Ce(Re) {
                                            const de = Z(Re.name || "");

                                            function qt(we) {
                                                return we != null ? Re.extractKey(we) : null
                                            }
                                            const $t = we => Re.multiEntry && Ue(we) ? we.forEach(Be => de.addKey(Be)) : de.addKey(we);
                                            (_e || se).forEach((we, Be) => {
                                                const cn = _e && qt(_e[Be]),
                                                    Yt = se && qt(se[Be]);
                                                He(cn, Yt) !== 0 && (cn != null && $t(cn), Yt != null && $t(Yt))
                                            })
                                        }
                                        U.indexes.forEach(Ce)
                                    }(I, l, B, W)
                                } else if (N) {
                                    const B = {
                                        from: N.lower,
                                        to: N.upper
                                    };
                                    O.add(B), L.add(B)
                                } else L.add(i), O.add(i), l.indexes.forEach(B => I(B.name).add(i));
                                return k
                            })
                        }
                    },
                    v = ({
                        query: {
                            index: b,
                            range: A
                        }
                    }) => {
                        var M, I;
                        return [b, new kt((M = A.lower) !== null && M !== void 0 ? M : r.MIN_KEY, (I = A.upper) !== null && I !== void 0 ? I : r.MAX_KEY)]
                    },
                    S = {
                        get: b => [f, new kt(b.key)],
                        getMany: b => [f, new kt().addKeys(b.keys)],
                        count: v,
                        query: v,
                        openCursor: v
                    };
                return Te(S).forEach(b => {
                    E[b] = function(A) {
                        const {
                            subscr: M
                        } = $;
                        if (M) {
                            const I = W => {
                                    const F = `idb://${n}/${a}/${W}`;
                                    return M[F] || (M[F] = new kt)
                                },
                                L = I(""),
                                O = I(":dels"),
                                [R, N] = S[b](A);
                            if (I(R.name || "").add(N), !R.isPrimaryKey) {
                                if (b !== "count") {
                                    const W = b === "query" && g && A.values && u.query({
                                        ...A,
                                        values: !1
                                    });
                                    return u[b].apply(this, arguments).then(F => {
                                        if (b === "query") {
                                            if (g && A.values) return W.then(({
                                                result: B
                                            }) => (L.addKeys(B), F));
                                            const k = A.values ? F.result.map(p) : F.result;
                                            A.values ? L.addKeys(k) : O.addKeys(k)
                                        } else if (b === "openCursor") {
                                            const k = F,
                                                B = A.values;
                                            return k && Object.create(k, {
                                                key: {
                                                    get: () => (O.addKey(k.primaryKey), k.key)
                                                },
                                                primaryKey: {
                                                    get() {
                                                        const Z = k.primaryKey;
                                                        return O.addKey(Z), Z
                                                    }
                                                },
                                                value: {
                                                    get: () => (B && L.addKey(k.primaryKey), k.value)
                                                }
                                            })
                                        }
                                        return F
                                    })
                                }
                                O.add(i)
                            }
                        }
                        return u[b].apply(this, arguments)
                    }
                }), E
            }
        }
    }
};
class An {
    constructor(n, i) {
        this._middlewares = {}, this.verno = 0;
        const a = An.dependencies;
        this._options = i = {
            addons: An.addons,
            autoOpen: !0,
            indexedDB: a.indexedDB,
            IDBKeyRange: a.IDBKeyRange,
            ...i
        }, this._deps = {
            indexedDB: i.indexedDB,
            IDBKeyRange: i.IDBKeyRange
        };
        const {
            addons: u
        } = i;
        this._dbSchema = {}, this._versions = [], this._storeNames = [], this._allTables = {}, this.idbdb = null, this._novip = this;
        const l = {
            dbOpenError: null,
            isBeingOpened: !1,
            onReadyBeingFired: null,
            openComplete: !1,
            dbReadyResolve: ce,
            dbReadyPromise: null,
            cancelOpen: ce,
            openCanceller: null,
            autoSchema: !0,
            PR1398_maxLoop: 3
        };
        var f;
        l.dbReadyPromise = new H(p => {
            l.dbReadyResolve = p
        }), l.openCanceller = new H((p, g) => {
            l.cancelOpen = g
        }), this._state = l, this.name = n, this.on = Nr(this, "populate", "blocked", "versionchange", "close", {
            ready: [Lo, ce]
        }), this.on.ready.subscribe = cf(this.on.ready.subscribe, p => (g, E) => {
            An.vip(() => {
                const v = this._state;
                if (v.openComplete) v.dbOpenError || H.resolve().then(g), E && p(g);
                else if (v.onReadyBeingFired) v.onReadyBeingFired.push(g), E && p(g);
                else {
                    p(g);
                    const S = this;
                    E || p(function b() {
                        S.on.ready.unsubscribe(g), S.on.ready.unsubscribe(b)
                    })
                }
            })
        }), this.Collection = (f = this, Or(nw.prototype, function(p, g) {
            this.db = f;
            let E = Cf,
                v = null;
            if (g) try {
                E = g()
            } catch (M) {
                v = M
            }
            const S = p._ctx,
                b = S.table,
                A = b.hook.reading.fire;
            this._ctx = {
                table: b,
                index: S.index,
                isPrimKey: !S.index || b.schema.primKey.keyPath && S.index === b.schema.primKey.name,
                range: E,
                keysOnly: !1,
                dir: "next",
                unique: "",
                algorithm: null,
                filter: null,
                replayFilter: null,
                justLimit: !0,
                isMatch: null,
                offset: 0,
                limit: 1 / 0,
                error: v,
                or: S.or,
                valueMapper: A !== Wr ? A : null
            }
        })), this.Table = function(p) {
            return Or(tw.prototype, function(g, E, v) {
                this.db = p, this._tx = v, this.name = g, this.schema = E, this.hook = p._allTables[g] ? p._allTables[g].hook : Nr(null, {
                    creating: [H0, ce],
                    reading: [G0, Wr],
                    updating: [$0, ce],
                    deleting: [q0, ce]
                })
            })
        }(this), this.Transaction = function(p) {
            return Or(aw.prototype, function(g, E, v, S, b) {
                this.db = p, this.mode = g, this.storeNames = E, this.schema = v, this.chromeTransactionDurability = S, this.idbtrans = null, this.on = Nr(this, "complete", "error", "abort"), this.parent = b || null, this.active = !0, this._reculock = 0, this._blockedFuncs = [], this._resolve = null, this._reject = null, this._waitingFor = null, this._waitingQueue = null, this._spinCount = 0, this._completion = new H((A, M) => {
                    this._resolve = A, this._reject = M
                }), this._completion.then(() => {
                    this.active = !1, this.on.complete.fire()
                }, A => {
                    var M = this.active;
                    return this.active = !1, this.on.error.fire(A), this.parent ? this.parent._reject(A) : M && this.idbtrans && this.idbtrans.abort(), Ie(A)
                })
            })
        }(this), this.Version = function(p) {
            return Or(fw.prototype, function(g) {
                this.db = p, this._cfg = {
                    version: g,
                    storesSource: null,
                    dbschema: {},
                    tables: {},
                    contentUpgrade: null
                }
            })
        }(this), this.WhereClause = function(p) {
            return Or(Lf.prototype, function(g, E, v) {
                this.db = p, this._ctx = {
                    table: g,
                    index: E === ":id" ? null : E,
                    or: v
                };
                const S = p._deps.indexedDB;
                if (!S) throw new V.MissingAPI;
                this._cmp = this._ascending = S.cmp.bind(S), this._descending = (b, A) => S.cmp(A, b), this._max = (b, A) => S.cmp(b, A) > 0 ? b : A, this._min = (b, A) => S.cmp(b, A) < 0 ? b : A, this._IDBKeyRange = p._deps.IDBKeyRange
            })
        }(this), this.on("versionchange", p => {
            p.newVersion > 0, this.close()
        }), this.on("blocked", p => {
            !p.newVersion || p.newVersion < p.oldVersion
        }), this._maxKey = $r(i.IDBKeyRange), this._createTransaction = (p, g, E, v) => new this.Transaction(p, g, E, this._options.chromeTransactionDurability, v), this._fireOnBlocked = p => {
            this.on("blocked").fire(p), Br.filter(g => g.name === this.name && g !== this && !g._state.vcFired).map(g => g.on("versionchange").fire(p))
        }, this.use(gw), this.use(_w), this.use(vw), this.use(mw), this.vip = Object.create(this, {
            _vip: {
                value: !0
            }
        }), u.forEach(p => p(this))
    }
    version(n) {
        if (isNaN(n) || n < .1) throw new V.Type("Given version is not a positive number");
        if (n = Math.round(10 * n) / 10, this.idbdb || this._state.isBeingOpened) throw new V.Schema("Cannot add version when database is open");
        this.verno = Math.max(this.verno, n);
        const i = this._versions;
        var a = i.filter(u => u._cfg.version === n)[0];
        return a || (a = new this.Version(n), i.push(a), i.sort(lw), a.stores({}), this._state.autoSchema = !1, a)
    }
    _whenReady(n) {
        return this.idbdb && (this._state.openComplete || $.letThrough || this._vip) ? n() : new H((i, a) => {
            if (this._state.openComplete) return a(new V.DatabaseClosed(this._state.dbOpenError));
            if (!this._state.isBeingOpened) {
                if (!this._options.autoOpen) return void a(new V.DatabaseClosed);
                this.open().catch(ce)
            }
            this._state.dbReadyPromise.then(i, a)
        }).then(n)
    }
    use({
        stack: n,
        create: i,
        level: a,
        name: u
    }) {
        u && this.unuse({
            stack: n,
            name: u
        });
        const l = this._middlewares[n] || (this._middlewares[n] = []);
        return l.push({
            stack: n,
            create: i,
            level: a == null ? 10 : a,
            name: u
        }), l.sort((f, p) => f.level - p.level), this
    }
    unuse({
        stack: n,
        name: i,
        create: a
    }) {
        return n && this._middlewares[n] && (this._middlewares[n] = this._middlewares[n].filter(u => a ? u.create !== a : !!i && u.name !== i)), this
    }
    open() {
        return dw(this)
    }
    _close() {
        const n = this._state,
            i = Br.indexOf(this);
        if (i >= 0 && Br.splice(i, 1), this.idbdb) {
            try {
                this.idbdb.close()
            } catch (a) {}
            this._novip.idbdb = null
        }
        n.dbReadyPromise = new H(a => {
            n.dbReadyResolve = a
        }), n.openCanceller = new H((a, u) => {
            n.cancelOpen = u
        })
    }
    close() {
        this._close();
        const n = this._state;
        this._options.autoOpen = !1, n.dbOpenError = new V.DatabaseClosed, n.isBeingOpened && n.cancelOpen(n.dbOpenError)
    }
    delete() {
        const n = arguments.length > 0,
            i = this._state;
        return new H((a, u) => {
            const l = () => {
                this.close();
                var f = this._deps.indexedDB.deleteDatabase(this.name);
                f.onsuccess = ye(() => {
                    (function({
                        indexedDB: p,
                        IDBKeyRange: g
                    }, E) {
                        !ko(p) && E !== _s && Fo(p, g).delete(E).catch(ce)
                    })(this._deps, this.name), a()
                }), f.onerror = Tt(u), f.onblocked = this._fireOnBlocked
            };
            if (n) throw new V.InvalidArgument("Arguments not allowed in db.delete()");
            i.isBeingOpened ? i.dbReadyPromise.then(l) : l()
        })
    }
    backendDB() {
        return this.idbdb
    }
    isOpen() {
        return this.idbdb !== null
    }
    hasBeenClosed() {
        const n = this._state.dbOpenError;
        return n && n.name === "DatabaseClosed"
    }
    hasFailed() {
        return this._state.dbOpenError !== null
    }
    dynamicallyOpened() {
        return this._state.autoSchema
    }
    get tables() {
        return Te(this._allTables).map(n => this._allTables[n])
    }
    transaction() {
        const n = pw.apply(this, arguments);
        return this._transaction.apply(this, n)
    }
    _transaction(n, i, a) {
        let u = $.trans;
        u && u.db === this && n.indexOf("!") === -1 || (u = null);
        const l = n.indexOf("?") !== -1;
        let f, p;
        n = n.replace("!", "").replace("?", "");
        try {
            if (p = i.map(E => {
                    var v = E instanceof this.Table ? E.name : E;
                    if (typeof v != "string") throw new TypeError("Invalid table argument to Dexie.transaction(). Only Table or String are allowed");
                    return v
                }), n == "r" || n === qa) f = qa;
            else {
                if (n != "rw" && n != $a) throw new V.InvalidArgument("Invalid transaction mode: " + n);
                f = $a
            }
            if (u) {
                if (u.mode === qa && f === $a) {
                    if (!l) throw new V.SubTransaction("Cannot enter a sub-transaction with READWRITE mode when parent transaction is READONLY");
                    u = null
                }
                u && p.forEach(E => {
                    if (u && u.storeNames.indexOf(E) === -1) {
                        if (!l) throw new V.SubTransaction("Table " + E + " not included in parent transaction.");
                        u = null
                    }
                }), l && u && !u.active && (u = null)
            }
        } catch (E) {
            return u ? u._promise(null, (v, S) => {
                S(E)
            }) : Ie(E)
        }
        const g = Ff.bind(null, this, f, p, u, a);
        return u ? u._promise(f, g, "lock") : $.trans ? nr($.transless, () => this._whenReady(g)) : this._whenReady(g)
    }
    table(n) {
        if (!rt(this._allTables, n)) throw new V.InvalidTable(`Table ${n} does not exist`);
        return this._allTables[n]
    }
}
const ww = typeof Symbol != "undefined" && "observable" in Symbol ? Symbol.observable : "@@observable";
class bw {
    constructor(n) {
        this._subscribe = n
    }
    subscribe(n, i, a) {
        return this._subscribe(n && typeof n != "function" ? n : {
            next: n,
            error: i,
            complete: a
        })
    } [ww]() {
        return this
    }
}

function Uf(r, n) {
    return Te(n).forEach(i => {
        hs(r[i] || (r[i] = new kt), n[i])
    }), r
}

function Ew(r) {
    let n, i = !1;
    const a = new bw(u => {
        const l = Po(r);
        let f = !1,
            p = {},
            g = {};
        const E = {
            get closed() {
                return f
            },
            unsubscribe: () => {
                f = !0, ln.storagemutated.unsubscribe(A)
            }
        };
        u.start && u.start(E);
        let v = !1,
            S = !1;

        function b() {
            return Te(g).some(I => p[I] && yw(p[I], g[I]))
        }
        const A = I => {
                Uf(p, I), b() && M()
            },
            M = () => {
                if (v || f) return;
                p = {};
                const I = {},
                    L = function(O) {
                        l && tr();
                        const R = () => on(r, {
                                subscr: O,
                                trans: null
                            }),
                            N = $.trans ? nr($.transless, R) : R();
                        return l && N.then(Ht, Ht), N
                    }(I);
                S || (ln(qr, A), S = !0), v = !0, Promise.resolve(L).then(O => {
                    i = !0, n = O, v = !1, f || (b() ? M() : (p = {}, g = I, u.next && u.next(O)))
                }, O => {
                    v = !1, i = !1, u.error && u.error(O), E.unsubscribe()
                })
            };
        return M(), E
    });
    return a.hasValue = () => i, a.getValue = () => n, a
}
let Ao;
try {
    Ao = {
        indexedDB: ge.indexedDB || ge.mozIndexedDB || ge.webkitIndexedDB || ge.msIndexedDB,
        IDBKeyRange: ge.IDBKeyRange || ge.webkitIDBKeyRange
    }
} catch (r) {
    Ao = {
        indexedDB: null,
        IDBKeyRange: null
    }
}
const bn = An;

function is(r) {
    let n = Kt;
    try {
        Kt = !0, ln.storagemutated.fire(r)
    } finally {
        Kt = n
    }
}
Zn(bn, {
    ...Zi,
    delete: r => new bn(r, {
        addons: []
    }).delete(),
    exists: r => new bn(r, {
        addons: []
    }).open().then(n => (n.close(), !0)).catch("NoSuchDatabaseError", () => !1),
    getDatabaseNames(r) {
        try {
            return function({
                indexedDB: n,
                IDBKeyRange: i
            }) {
                return ko(n) ? Promise.resolve(n.databases()).then(a => a.map(u => u.name).filter(u => u !== _s)) : Fo(n, i).toCollection().primaryKeys()
            }(bn.dependencies).then(r)
        } catch (n) {
            return Ie(new V.MissingAPI)
        }
    },
    defineClass: () => function(r) {
        qe(this, r)
    },
    ignoreTransaction: r => $.trans ? nr($.transless, r) : r(),
    vip: Eo,
    async: function(r) {
        return function() {
            try {
                var n = So(r.apply(this, arguments));
                return n && typeof n.then == "function" ? n : H.resolve(n)
            } catch (i) {
                return Ie(i)
            }
        }
    },
    spawn: function(r, n, i) {
        try {
            var a = So(r.apply(i, n || []));
            return a && typeof a.then == "function" ? a : H.resolve(a)
        } catch (u) {
            return Ie(u)
        }
    },
    currentTransaction: {
        get: () => $.trans || null
    },
    waitFor: function(r, n) {
        const i = H.resolve(typeof r == "function" ? bn.ignoreTransaction(r) : r).timeout(n || 6e4);
        return $.trans ? $.trans.waitFor(i) : i
    },
    Promise: H,
    debug: {
        get: () => At,
        set: r => {
            _f(r, r === "dexie" ? () => !0 : Pf)
        }
    },
    derive: Vn,
    extend: qe,
    props: Zn,
    override: cf,
    Events: Nr,
    on: ln,
    liveQuery: Ew,
    extendObservabilitySet: Uf,
    getByKeyPath: Gt,
    setByKeyPath: yt,
    delByKeyPath: function(r, n) {
        typeof n == "string" ? yt(r, n, void 0) : "length" in n && [].map.call(n, function(i) {
            yt(r, i, void 0)
        })
    },
    shallowClone: df,
    deepClone: zr,
    getObjectDiff: Uo,
    cmp: He,
    asap: ff,
    minKey: po,
    addons: [],
    connections: Br,
    errnames: Do,
    dependencies: Ao,
    semVer: Kc,
    version: Kc.split(".").map(r => parseInt(r)).reduce((r, n, i) => r + n / Math.pow(10, 2 * i))
}), bn.maxKey = $r(bn.dependencies.IDBKeyRange), typeof dispatchEvent != "undefined" && typeof addEventListener != "undefined" && (ln(qr, r => {
    if (!Kt) {
        let n;
        gs ? (n = document.createEvent("CustomEvent"), n.initCustomEvent(an, !0, !0, r)) : n = new CustomEvent(an, {
            detail: r
        }), Kt = !0, dispatchEvent(n), Kt = !1
    }
}), addEventListener(an, ({
    detail: r
}) => {
    Kt || is(r)
}));
let Kt = !1;
if (typeof BroadcastChannel != "undefined") {
    const r = new BroadcastChannel(an);
    typeof r.unref == "function" && r.unref(), ln(qr, n => {
        Kt || r.postMessage(n)
    }), r.onmessage = n => {
        n.data && is(n.data)
    }
} else if (typeof self != "undefined" && typeof navigator != "undefined") {
    ln(qr, n => {
        try {
            Kt || (typeof localStorage != "undefined" && localStorage.setItem(an, JSON.stringify({
                trig: Math.random(),
                changedParts: n
            })), typeof self.clients == "object" && [...self.clients.matchAll({
                includeUncontrolled: !0
            })].forEach(i => i.postMessage({
                type: an,
                changedParts: n
            })))
        } catch (i) {}
    }), typeof addEventListener != "undefined" && addEventListener("storage", n => {
        if (n.key === an) {
            const i = JSON.parse(n.newValue);
            i && is(i.changedParts)
        }
    });
    const r = self.document && navigator.serviceWorker;
    r && r.addEventListener("message", function({
        data: n
    }) {
        n && n.type === an && is(n.changedParts)
    })
}
H.rejectionMapper = function(r, n) {
    if (!r || r instanceof Xn || r instanceof TypeError || r instanceof SyntaxError || !r.name || !Nc[r.name]) return r;
    var i = new Nc[r.name](n || r.message, r);
    return "stack" in r && Wt(i, "stack", {
        get: function() {
            return this.inner.stack
        }
    }), i
}, _f(At, Pf);
const rr = new An("modheader");
rr.version(2).stores({
    request: "++id,tabId,date",
    tabStartDate: "++id,tabStartDate",
    tabDisabledResourceType: "tabId,updateTime,resourceType",
    domainSetting: "domain,updateTime"
});
const Jn = rr.request,
    Wo = rr.tabStartDate,
    jr = rr.tabDisabledResourceType,
    ms = rr.domainSetting;
globalThis.db = rr;
globalThis.reqDB = Jn;
globalThis.tabStartDateDB = Wo;
globalThis.tabDisabledResourceTypeDB = jr;
globalThis.domainSettingDB = ms;
async function Sw(r, n) {
    if (await this.update(r, n) === 1) return !0;
    await this.put({
        ...r,
        ...n
    })
}

function Tw(r) {
    return r && typeof r == "object" && typeof r.name == "string" && typeof r.schema == "object" && typeof r.toArray == "function"
}
for (let r of Object.entries(globalThis)) Tw(r[1]) && (r[1].upsert = Sw);
const Me = new Proxy({}, {
    get(r, n) {
        return "a_redis" in globalThis || (globalThis.a_redis = {}), n in globalThis.a_redis || (globalThis.a_redis[n] = {}), {
            put(i, a) {
                const u = globalThis.a_redis[n][i];
                return globalThis.a_redis[n][i] = a, {
                    oldValue: u,
                    value: a
                }
            },
            get(i, a = null) {
                return i in globalThis.a_redis[n] ? globalThis.a_redis[n][i] : a
            },
            clear() {
                globalThis.a_redis[n] = {}
            },
            delete(i) {
                const a = globalThis.a_redis[n][i];
                return delete globalThis.a_redis[n][i], a
            },
            items() {
                return globalThis.a_redis[n]
            },
            values() {
                return Object.values(globalThis.a_redis[n])
            },
            keys() {
                return Object.keys(globalThis.a_redis[n])
            }
        }
    }
});
globalThis.redis = Me;
async function Aw({
    expiration_minutes: r = 10
} = {}) {
    let n = new Date,
        i = new Date(n.getFullYear(), n.getMonth(), n.getDate(), n.getHours(), n.getMinutes() - r, 0);
    const a = await Jn.where("date").below(i).delete()
}
async function xw(r) {
    const n = await Wo.get(`tabStartTime_${r}`),
        i = n == null ? void 0 : n.tabStartDate;
    return i ? await Jn.where("tabId").equals(r).and(a => a.date >= i).reverse().sortBy("date") : await Jn.where("tabId").equals(r).reverse().sortBy("date")
}
async function Iw({
    expiration_minutes: r = -1
} = {}) {
    if (r === -1) await jr.clear(), Me.resourceType.clear();
    else {
        let n = new Date,
            i = new Date(n.getFullYear(), n.getMonth(), n.getDate(), n.getHours(), n.getMinutes() - r, 0);
        Me.resourceType.values().findAll(u => u.updateTime < i).map(u => Me.resourceType.delete(u.tabId)), await jr.where("updateTime").below(i).delete()
    }
}
async function Rw(r, n = {}) {
    return await ms.get({
        domain: r
    }) || n
}
async function nn(r, n) {
    n.updateTime = new Date, await ms.upsert({
        domain: r
    }, n)
}
async function Kf() {
    await ms.each((r, n) => {
        r.disable_resource_types && Array.isArray(r.disable_resource_types) && r.disable_resource_types.length > 0 && Me.urlDomainDisableResource.put(r.domain, r.disable_resource_types)
    }), Me.settings.put("initRedisData", !0)
}
async function er(r, n) {
    return !!await Pe.permissions.contains({
        permissions: r,
        origins: n
    })
}
async function Go(r, n) {
    return !!await Pe.permissions.request({
        permissions: r,
        origins: n
    })
}
async function Ow(r, n) {
    return !!await Pe.permissions.remove({
        permissions: r,
        origins: n
    })
}
globalThis.checkPermissions = er;
globalThis.requestPermissions = Go;
globalThis.removePermissions = Ow;
async function Pw(r, n) {
    return new Promise((i, a) => {
        try {
            Pe.contentSettings[r].set(n, () => {
                i(!0)
            })
        } catch (u) {
            a(u)
        }
    })
}
async function Wf(r, n, i, a = "regular") {
    return (!Pe.contentSettings || !await er(["contentSettings"], ["<all_urls>"])) && !await Go(["contentSettings"], ["<all_urls>"]) ? {
        error: "NO_PERMISSION"
    } : (await Pw(r, {
        primaryPattern: n,
        setting: i,
        scope: a
    }), !0)
}
async function Cw(r, n, i = !1) {
    return new Promise((a, u) => {
        try {
            Pe.contentSettings[r].get({
                primaryUrl: n,
                incognito: i
            }, l => {
                a({
                    [`${r}`]: l.setting
                })
            })
        } catch (l) {
            u({
                [`${r}`]: `Get Value Error:${l}`
            })
        }
    })
}
async function xo(r, n = ["javascript", "images", "cookies"], i = !1) {
    if (!Pe.contentSettings || !await er(["contentSettings"], ["<all_urls>"])) return {
        error: "NO_PERMISSION"
    };
    r === "<all_urls>" && (r = "http://*");
    const a = n.map(f => Cw(f, r, i));
    return (await Promise.all(a)).reduce((f, p) => ({
        ...f,
        ...p
    }), {})
}
async function Dw(r, n = "regular") {
    return new Promise((i, a) => {
        try {
            const u = {
                scope: n
            };
            Pe.contentSettings[r].clear(u, () => {
                i({
                    [`${r}`]: !0
                })
            })
        } catch (u) {
            a({
                [`${r}`]: !1
            })
        }
    })
}
async function Lw(r = ["javascript", "images", "cookies"], n = "regular") {
    if (!Pe.contentSettings || !await er(["contentSettings"], ["<all_urls>"])) return {
        error: "NO_PERMISSION"
    };
    const i = r.map(l => Dw(l, n));
    return (await Promise.all(i)).reduce((l, f) => ({
        ...l,
        ...f
    }), {})
}
globalThis.bulkGetContentSettings = xo;
globalThis.bulkClearContentSettings = Lw;
globalThis.controlContentSettingsItemSwitch = Wf;
async function kr(r, n = "SHA-256", i = 16) {
    const a = new TextEncoder().encode(r),
        u = await crypto.subtle.digest(n, a);
    return Array.from(new Uint8Array(u)).map(p => p.toString(i).padStart(2, "0")).join("")
}
async function Mw(r, n, i) {
    let a = new Date().getTime();
    switch (n) {
        case "last_hour":
            a = a - 1e3 * 60 * 60;
            break;
        case "last_day":
            a = a - 1e3 * 60 * 60 * 24;
            break;
        case "last_three_day":
            a = a - 1e3 * 60 * 60 * 24 * 3;
            break;
        case "last_week":
            a = a - 1e3 * 60 * 60 * 24 * 7;
            break;
        case "last_month":
            a = a - 1e3 * 60 * 60 * 24 * 30;
            break;
        case "everything":
            a = 0;
            break
    }
    typeof n == "number" && (a = n);
    const u = i.reduce((f, p) => (f[p] = !0, f), {}),
        l = {
            since: a
        };
    return r.length > 0 && (l.origins = r), chrome.browsingData.remove(l, u, () => {})
}
const jn = {
        EXISTS: "EXISTS",
        IMPORT: "IMPORT",
        MERGE_PROFILE: "MERGE_PROFILE",
        IMPORT_AUTO_SYNC: "IMPORT_AUTO_SYNC",
        SWITCH_TO_LATEST: "SWITCH_TO_LATEST",
        PROFILES: "PROFILES"
    },
    he = {
        GET_REQUEST_RECORD: "GET_REQUEST_RECORD",
        DISABLE_WEB_REQUEST_TYPE_LIST: "DISABLE_WEB_REQUEST_TYPE_LIST",
        GET_DISABLE_WEB_REQUEST_TYPE_LIST: "GET_DISABLE_WEB_REQUEST_TYPE_LIST",
        OPEN_MODHEADER_APP_LABEL: "OPEN_MODHEADER_APP_LABEL",
        DISABLE_CONTENT_SETTINGS_ITEM: "DISABLE_CONTENT_SETTINGS_ITEM",
        GET_CONTENT_SETTINGS: "GET_CONTENT_SETTINGS",
        BEAUTIFY_SCROLLBAR: "BEAUTIFY_SCROLLBAR",
        CLEAR_BEAUTIFY_SCROLLBAR: "CLEAR_BEAUTIFY_SCROLLBAR",
        GET_DOMAIN_SETTINGS: "GET_DOMAIN_SETTINGS",
        REGISTER_IFRAME_PAGE_INFORMATION_POST_MESSAGE: "REGISTER_IFRAME_PAGE_INFORMATION_POST_MESSAGE",
        ALL_WINDOW_UNLOCKER_ENABLE: "ALL_WINDOW_UNLOCKER_ENABLE",
        ALL_WINDOW_UNLOCKER_DISABLE: "ALL_WINDOW_UNLOCKER_DISABLE",
        ALL_WINDOW_CSS_ENABLE: "ALL_WINDOW_CSS_ENABLE",
        ALL_WINDOW_CSS_DISABLE: "ALL_WINDOW_CSS_DISABLE",
        ALL_WINDOW_CONTENTEDITABLE: "ALL_WINDOW_CONTENTEDITABLE",
        ALL_WINDOW_NOT_CONTENTEDITABLE: "ALL_WINDOW_NOT_CONTENTEDITABLE",
        REMOVE_IFRAME_POST_MESSAGE_TASK: "REMOVE_IFRAME_POST_MESSAGE_TASK",
        ALL_FRAME_EXPORT_SVG_POST_MESSAGE_TO_ROOT_FRAME: "ALL_FRAME_EXPORT_SVG_POST_MESSAGE_TO_ROOT_FRAME",
        SCREENSHOT_ACTIVE_TAB: "SCREENSHOT_ACTIVE_TAB",
        REGISTER_IFRAME_LISTENERS_POST_MESSAGE: "REGISTER_IFRAME_LISTENERS_POST_MESSAGE",
        UNREGISTER_IFRAME_LISTENERS_POST_MESSAGE: "UNREGISTER_IFRAME_LISTENERS_POST_MESSAGE",
        UPSERT_DOMAIN_SETTINGS: "UPSERT_DOMAIN_SETTINGS",
        BROWSER_DATA_REMOVE: "BROWSER_DATA_REMOVE",
        REQUEST_PERMISSIONS: "REQUEST_PERMISSIONS",
        CHECK_PERMISSIONS: "CHECK_PERMISSIONS",
        UPDATE_REDIS_DATA: "UPDATE_REDIS_DATA"
    };
async function Bw({
    chromeLocal: r,
    request: n
}) {
    switch (n.type) {
        case jn.EXISTS: {
            const i = chrome.runtime.getManifest();
            return {
                success: !0,
                maxSupportedProfileVersion: jv,
                canImportWithAutoSync: !0,
                canMergeProfile: !0,
                modHeaderVersion: i.version
            }
        }
        case jn.IMPORT: {
            const i = [JSON.parse(n.profile)];
            Ur(i);
            const a = [...r.profiles, ...i];
            return await Ka(a, a.length - 1), {
                success: !0
            }
        }
        case jn.MERGE_PROFILE: {
            const i = [JSON.parse(n.profile)];
            Ur(i);
            const a = i[0],
                u = [...r.profiles],
                l = u[r.selectedProfile];
            for (const f of Yv) a[f] && a[f].length > 0 && (!l[f] || l[f].length === 0 ? l[f] = a[f] : l[f].push(...a[f]));
            return await Ka(u, r.selectedProfile), {
                success: !0
            }
        }
        case jn.IMPORT_AUTO_SYNC: {
            const i = await $v({
                    liveProfileUrl: n.profileUrl
                }),
                a = [...r.profiles, i];
            return await Ka(a, a.length - 1), {
                success: !0
            }
        }
        case jn.SWITCH_TO_LATEST:
            return await tf(r.profiles.length - 1), {
                success: !0
            };
        case jn.PROFILES:
            return {
                success: !0, profiles: r.profiles, selectedProfileIndex: r.selectedProfile, managedProfiles: r.managedProfiles
            };
        default:
            return
    }
}
async function Nw(r, n, i) {
    var a, u;
    switch (r.type) {
        case he.GET_REQUEST_RECORD: {
            const l = await xw(n.tab.id);
            return i({
                reqList: l,
                date: new Date().toLocaleTimeString()
            }), !0
        }
        case he.DISABLE_WEB_REQUEST_TYPE_LIST: {
            const l = Nt(n.url);
            let f = r.disableResourceTypes;
            return (!r.disableResourceTypes || r.disableResourceTypes.length === 0) && (f = []), await nn(l, {
                disable_resource_types: f
            }), Me.urlDomainDisableResource.put(l, f), i({
                resourceType: f
            }), !0
        }
        case he.GET_DISABLE_WEB_REQUEST_TYPE_LIST: {
            const l = ((a = Me.resourceType.get(n.tab.id)) == null ? void 0 : a.resourceType) || ((u = await jr.get(n.tab.id)) == null ? void 0 : u.resourceType) || [];
            return i({
                resourceType: l
            }), !0
        }
        case he.OPEN_MODHEADER_APP_LABEL: {
            const l = chrome.runtime.getURL("src/app_v1.html");
            return chrome.tabs.create({
                url: l
            }), i({
                openUrl: l
            }), !0
        }
        case he.DISABLE_CONTENT_SETTINGS_ITEM: {
            const l = r.disable ? "block" : "allow";
            let f = `${n.origin}/*`;
            r.primaryPattern && (f = r.primaryPattern);
            let p = await Wf(r.disable_type, f, l);
            if (p !== !0) {
                i(p);
                return
            }
            return p = await xo(f, [r.disable_type]), i(p), !0
        }
        case he.GET_CONTENT_SETTINGS: {
            let l = `${n.origin}/*`;
            r.primaryPattern && (l = r.primaryPattern);
            const f = await xo(l);
            return i(f), !0
        }
        case he.BEAUTIFY_SCROLLBAR: {
            await tt(n.tab.id, o0, !0);
            const l = Nt(n.url);
            return await nn(l, {
                beautify_scrollbar: !0
            }), i({
                message: "ok"
            }), !0
        }
        case he.CLEAR_BEAUTIFY_SCROLLBAR: {
            await tt(n.tab.id, a0, !0);
            const l = Nt(n.url);
            return await nn(l, {
                beautify_scrollbar: !1
            }), i({
                message: "ok"
            }), !0
        }
        case he.GET_DOMAIN_SETTINGS: {
            const l = Nt(n.url),
                f = await Rw(l);
            return i(f), !0
        }
        case he.REGISTER_IFRAME_PAGE_INFORMATION_POST_MESSAGE: {
            const l = n.tab.id,
                f = `${n.origin}-${l}-${Math.random()}-modheader`;
            let p = r.securityKey;
            return p || (p = await kr(f)), await tt(l, i0, !0, [n.origin, p]), i({
                securityKey: p
            }), !0
        }
        case he.ALL_WINDOW_UNLOCKER_ENABLE: {
            await tt(n.tab.id, Rc, !0, [!0]);
            const l = Nt(n.url);
            return await nn(l, {
                unlocker: !0
            }), i({
                message: "ok"
            }), !0
        }
        case he.ALL_WINDOW_UNLOCKER_DISABLE: {
            await tt(n.tab.id, Rc, !0, [!1]);
            const l = Nt(n.url);
            return await nn(l, {
                unlocker: !1
            }), i({
                message: "ok"
            }), !0
        }
        case he.ALL_WINDOW_CSS_ENABLE: {
            await tt(n.tab.id, Ic, !0, [!1]);
            const l = Nt(n.url);
            return await nn(l, {
                css_enable: !0
            }), i({
                message: "ok"
            }), !0
        }
        case he.ALL_WINDOW_CSS_DISABLE: {
            await tt(n.tab.id, Ic, !0, [!0]);
            const l = Nt(n.url);
            return await nn(l, {
                css_enable: !0
            }), i({
                message: "ok"
            }), !0
        }
        case he.ALL_WINDOW_CONTENTEDITABLE:
            return await tt(n.tab.id, xc, !0, [!0]), i({
                message: "ok"
            }), !0;
        case he.ALL_WINDOW_NOT_CONTENTEDITABLE:
            return await tt(n.tab.id, xc, !0, [!1]), i({
                message: "ok"
            }), !0;
        case he.REMOVE_IFRAME_POST_MESSAGE_TASK:
            return await tt(n.tab.id, s0, !0), i({
                message: "ok"
            }), !0;
        case he.ALL_FRAME_EXPORT_SVG_POST_MESSAGE_TO_ROOT_FRAME: {
            const l = n.tab.id,
                f = `${n.origin}-${l}-${Math.random()}-modheader`;
            let p = r.securityKey;
            return p || (p = await kr(f)), await tt(l, r0, !0, [n.origin, p]), i({
                securityKey: p
            }), !0
        }
        case he.SCREENSHOT_ACTIVE_TAB: {
            const l = await browser.tabs.captureVisibleTab(null, {
                format: "png",
                quality: 100
            });
            return i({
                data: l
            }), !0
        }
        case he.REGISTER_IFRAME_LISTENERS_POST_MESSAGE: {
            const l = n.tab.id,
                f = `${n.origin}-${l}-${Math.random()}-modheader`;
            let p = r.securityKey;
            return p || (p = await kr(f)), await tt(l, Ac.iframeRegisterListenerManager, !0, [p]), i({
                securityKey: p
            }), !0
        }
        case he.UNREGISTER_IFRAME_LISTENERS_POST_MESSAGE:
            return await tt(n.tab.id, Ac.iframeUnRegisterPostMessageManager, !0), i({
                message: "ok"
            }), !0;
        case he.UPSERT_DOMAIN_SETTINGS: {
            const l = Nt(n.url);
            return await nn(l, r.settings), i({
                message: "ok"
            }), !0
        }
        case he.BROWSER_DATA_REMOVE: {
            if (!await er(["browsingData"], ["<all_urls>"])) return i({
                message: "no_permission"
            }), !0;
            let f = [`${n.origin}/`];
            return r.clearRange === "all" && (f = []), await Mw(f, r.sinceType, r.dataTypes), i({
                message: "ok"
            }), !0
        }
        case he.REQUEST_PERMISSIONS: {
            const l = n.origin ? [`${n.origin}/`] : ["<all_urls>"];
            let f = await Go(r.permissions, l);
            return i(f ? {
                message: "ok"
            } : {
                message: "no_permission"
            }), !0
        }
        case he.CHECK_PERMISSIONS: {
            const l = n.origin ? [`${n.origin}/`] : ["<all_urls>"],
                p = await er(r.permissions, l) ? "ok" : "no_permission";
            return i({
                message: p
            }), !0
        }
        case he.UPDATE_REDIS_DATA:
            return Me[r.namespace].put(r.key, r.value), i({
                message: "ok"
            }), !0;
        default:
            return !0
    }
}

function Fw(r, n, i) {
    return Nw(r, n, i).catch(console.error), !0
}
var ds = {
    exports: {}
};
ds.exports;
(function(r, n) {
    (function() {
        var i, a = "4.17.21",
            u = 200,
            l = "Unsupported core-js use. Try https://npms.io/search?q=ponyfill.",
            f = "Expected a function",
            p = "Invalid `variable` option passed into `_.template`",
            g = "__lodash_hash_undefined__",
            E = 500,
            v = "__lodash_placeholder__",
            S = 1,
            b = 2,
            A = 4,
            M = 1,
            I = 2,
            L = 1,
            O = 2,
            R = 4,
            N = 8,
            W = 16,
            F = 32,
            k = 64,
            B = 128,
            Z = 256,
            U = 512,
            _e = 30,
            se = "...",
            Ce = 800,
            Re = 16,
            de = 1,
            qt = 2,
            $t = 3,
            we = 1 / 0,
            Be = 9007199254740991,
            cn = 17976931348623157e292,
            Yt = 0 / 0,
            wt = 4294967295,
            $f = wt - 1,
            Yf = wt >>> 1,
            jf = [
                ["ary", B],
                ["bind", L],
                ["bindKey", O],
                ["curry", N],
                ["curryRight", W],
                ["flip", U],
                ["partial", F],
                ["partialRight", k],
                ["rearg", Z]
            ],
            On = "[object Arguments]",
            Qr = "[object Array]",
            zf = "[object AsyncFunction]",
            ir = "[object Boolean]",
            sr = "[object Date]",
            Vf = "[object DOMException]",
            Zr = "[object Error]",
            Jr = "[object Function]",
            $o = "[object GeneratorFunction]",
            ht = "[object Map]",
            ar = "[object Number]",
            Xf = "[object Null]",
            xt = "[object Object]",
            Yo = "[object Promise]",
            Qf = "[object Proxy]",
            or = "[object RegExp]",
            dt = "[object Set]",
            ur = "[object String]",
            ei = "[object Symbol]",
            Zf = "[object Undefined]",
            lr = "[object WeakMap]",
            Jf = "[object WeakSet]",
            cr = "[object ArrayBuffer]",
            Pn = "[object DataView]",
            ys = "[object Float32Array]",
            vs = "[object Float64Array]",
            ws = "[object Int8Array]",
            bs = "[object Int16Array]",
            Es = "[object Int32Array]",
            Ss = "[object Uint8Array]",
            Ts = "[object Uint8ClampedArray]",
            As = "[object Uint16Array]",
            xs = "[object Uint32Array]",
            eh = /\b__p \+= '';/g,
            th = /\b(__p \+=) '' \+/g,
            nh = /(__e\(.*?\)|\b__t\)) \+\n'';/g,
            jo = /&(?:amp|lt|gt|quot|#39);/g,
            zo = /[&<>"']/g,
            rh = RegExp(jo.source),
            ih = RegExp(zo.source),
            sh = /<%-([\s\S]+?)%>/g,
            ah = /<%([\s\S]+?)%>/g,
            Vo = /<%=([\s\S]+?)%>/g,
            oh = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
            uh = /^\w*$/,
            lh = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,
            Is = /[\\^$.*+?()[\]{}|]/g,
            ch = RegExp(Is.source),
            Rs = /^\s+/,
            fh = /\s/,
            hh = /\{(?:\n\/\* \[wrapped with .+\] \*\/)?\n?/,
            dh = /\{\n\/\* \[wrapped with (.+)\] \*/,
            ph = /,? & /,
            gh = /[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g,
            _h = /[()=,{}\[\]\/\s]/,
            mh = /\\(\\)?/g,
            yh = /\$\{([^\\}]*(?:\\.[^\\}]*)*)\}/g,
            Xo = /\w*$/,
            vh = /^[-+]0x[0-9a-f]+$/i,
            wh = /^0b[01]+$/i,
            bh = /^\[object .+?Constructor\]$/,
            Eh = /^0o[0-7]+$/i,
            Sh = /^(?:0|[1-9]\d*)$/,
            Th = /[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g,
            ti = /($^)/,
            Ah = /['\n\r\u2028\u2029\\]/g,
            ni = "\\ud800-\\udfff",
            xh = "\\u0300-\\u036f",
            Ih = "\\ufe20-\\ufe2f",
            Rh = "\\u20d0-\\u20ff",
            Qo = xh + Ih + Rh,
            Zo = "\\u2700-\\u27bf",
            Jo = "a-z\\xdf-\\xf6\\xf8-\\xff",
            Oh = "\\xac\\xb1\\xd7\\xf7",
            Ph = "\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf",
            Ch = "\\u2000-\\u206f",
            Dh = " \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000",
            eu = "A-Z\\xc0-\\xd6\\xd8-\\xde",
            tu = "\\ufe0e\\ufe0f",
            nu = Oh + Ph + Ch + Dh,
            Os = "['’]",
            Lh = "[" + ni + "]",
            ru = "[" + nu + "]",
            ri = "[" + Qo + "]",
            iu = "\\d+",
            Mh = "[" + Zo + "]",
            su = "[" + Jo + "]",
            au = "[^" + ni + nu + iu + Zo + Jo + eu + "]",
            Ps = "\\ud83c[\\udffb-\\udfff]",
            Bh = "(?:" + ri + "|" + Ps + ")",
            ou = "[^" + ni + "]",
            Cs = "(?:\\ud83c[\\udde6-\\uddff]){2}",
            Ds = "[\\ud800-\\udbff][\\udc00-\\udfff]",
            Cn = "[" + eu + "]",
            uu = "\\u200d",
            lu = "(?:" + su + "|" + au + ")",
            Nh = "(?:" + Cn + "|" + au + ")",
            cu = "(?:" + Os + "(?:d|ll|m|re|s|t|ve))?",
            fu = "(?:" + Os + "(?:D|LL|M|RE|S|T|VE))?",
            hu = Bh + "?",
            du = "[" + tu + "]?",
            Fh = "(?:" + uu + "(?:" + [ou, Cs, Ds].join("|") + ")" + du + hu + ")*",
            kh = "\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])",
            Uh = "\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])",
            pu = du + hu + Fh,
            Kh = "(?:" + [Mh, Cs, Ds].join("|") + ")" + pu,
            Wh = "(?:" + [ou + ri + "?", ri, Cs, Ds, Lh].join("|") + ")",
            Gh = RegExp(Os, "g"),
            Hh = RegExp(ri, "g"),
            Ls = RegExp(Ps + "(?=" + Ps + ")|" + Wh + pu, "g"),
            qh = RegExp([Cn + "?" + su + "+" + cu + "(?=" + [ru, Cn, "$"].join("|") + ")", Nh + "+" + fu + "(?=" + [ru, Cn + lu, "$"].join("|") + ")", Cn + "?" + lu + "+" + cu, Cn + "+" + fu, Uh, kh, iu, Kh].join("|"), "g"),
            $h = RegExp("[" + uu + ni + Qo + tu + "]"),
            Yh = /[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/,
            jh = ["Array", "Buffer", "DataView", "Date", "Error", "Float32Array", "Float64Array", "Function", "Int8Array", "Int16Array", "Int32Array", "Map", "Math", "Object", "Promise", "RegExp", "Set", "String", "Symbol", "TypeError", "Uint8Array", "Uint8ClampedArray", "Uint16Array", "Uint32Array", "WeakMap", "_", "clearTimeout", "isFinite", "parseInt", "setTimeout"],
            zh = -1,
            pe = {};
        pe[ys] = pe[vs] = pe[ws] = pe[bs] = pe[Es] = pe[Ss] = pe[Ts] = pe[As] = pe[xs] = !0, pe[On] = pe[Qr] = pe[cr] = pe[ir] = pe[Pn] = pe[sr] = pe[Zr] = pe[Jr] = pe[ht] = pe[ar] = pe[xt] = pe[or] = pe[dt] = pe[ur] = pe[lr] = !1;
        var fe = {};
        fe[On] = fe[Qr] = fe[cr] = fe[Pn] = fe[ir] = fe[sr] = fe[ys] = fe[vs] = fe[ws] = fe[bs] = fe[Es] = fe[ht] = fe[ar] = fe[xt] = fe[or] = fe[dt] = fe[ur] = fe[ei] = fe[Ss] = fe[Ts] = fe[As] = fe[xs] = !0, fe[Zr] = fe[Jr] = fe[lr] = !1;
        var Vh = {
                À: "A",
                Á: "A",
                Â: "A",
                Ã: "A",
                Ä: "A",
                Å: "A",
                à: "a",
                á: "a",
                â: "a",
                ã: "a",
                ä: "a",
                å: "a",
                Ç: "C",
                ç: "c",
                Ð: "D",
                ð: "d",
                È: "E",
                É: "E",
                Ê: "E",
                Ë: "E",
                è: "e",
                é: "e",
                ê: "e",
                ë: "e",
                Ì: "I",
                Í: "I",
                Î: "I",
                Ï: "I",
                ì: "i",
                í: "i",
                î: "i",
                ï: "i",
                Ñ: "N",
                ñ: "n",
                Ò: "O",
                Ó: "O",
                Ô: "O",
                Õ: "O",
                Ö: "O",
                Ø: "O",
                ò: "o",
                ó: "o",
                ô: "o",
                õ: "o",
                ö: "o",
                ø: "o",
                Ù: "U",
                Ú: "U",
                Û: "U",
                Ü: "U",
                ù: "u",
                ú: "u",
                û: "u",
                ü: "u",
                Ý: "Y",
                ý: "y",
                ÿ: "y",
                Æ: "Ae",
                æ: "ae",
                Þ: "Th",
                þ: "th",
                ß: "ss",
                Ā: "A",
                Ă: "A",
                Ą: "A",
                ā: "a",
                ă: "a",
                ą: "a",
                Ć: "C",
                Ĉ: "C",
                Ċ: "C",
                Č: "C",
                ć: "c",
                ĉ: "c",
                ċ: "c",
                č: "c",
                Ď: "D",
                Đ: "D",
                ď: "d",
                đ: "d",
                Ē: "E",
                Ĕ: "E",
                Ė: "E",
                Ę: "E",
                Ě: "E",
                ē: "e",
                ĕ: "e",
                ė: "e",
                ę: "e",
                ě: "e",
                Ĝ: "G",
                Ğ: "G",
                Ġ: "G",
                Ģ: "G",
                ĝ: "g",
                ğ: "g",
                ġ: "g",
                ģ: "g",
                Ĥ: "H",
                Ħ: "H",
                ĥ: "h",
                ħ: "h",
                Ĩ: "I",
                Ī: "I",
                Ĭ: "I",
                Į: "I",
                İ: "I",
                ĩ: "i",
                ī: "i",
                ĭ: "i",
                į: "i",
                ı: "i",
                Ĵ: "J",
                ĵ: "j",
                Ķ: "K",
                ķ: "k",
                ĸ: "k",
                Ĺ: "L",
                Ļ: "L",
                Ľ: "L",
                Ŀ: "L",
                Ł: "L",
                ĺ: "l",
                ļ: "l",
                ľ: "l",
                ŀ: "l",
                ł: "l",
                Ń: "N",
                Ņ: "N",
                Ň: "N",
                Ŋ: "N",
                ń: "n",
                ņ: "n",
                ň: "n",
                ŋ: "n",
                Ō: "O",
                Ŏ: "O",
                Ő: "O",
                ō: "o",
                ŏ: "o",
                ő: "o",
                Ŕ: "R",
                Ŗ: "R",
                Ř: "R",
                ŕ: "r",
                ŗ: "r",
                ř: "r",
                Ś: "S",
                Ŝ: "S",
                Ş: "S",
                Š: "S",
                ś: "s",
                ŝ: "s",
                ş: "s",
                š: "s",
                Ţ: "T",
                Ť: "T",
                Ŧ: "T",
                ţ: "t",
                ť: "t",
                ŧ: "t",
                Ũ: "U",
                Ū: "U",
                Ŭ: "U",
                Ů: "U",
                Ű: "U",
                Ų: "U",
                ũ: "u",
                ū: "u",
                ŭ: "u",
                ů: "u",
                ű: "u",
                ų: "u",
                Ŵ: "W",
                ŵ: "w",
                Ŷ: "Y",
                ŷ: "y",
                Ÿ: "Y",
                Ź: "Z",
                Ż: "Z",
                Ž: "Z",
                ź: "z",
                ż: "z",
                ž: "z",
                Ĳ: "IJ",
                ĳ: "ij",
                Œ: "Oe",
                œ: "oe",
                ŉ: "'n",
                ſ: "s"
            },
            Xh = {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#39;"
            },
            Qh = {
                "&amp;": "&",
                "&lt;": "<",
                "&gt;": ">",
                "&quot;": '"',
                "&#39;": "'"
            },
            Zh = {
                "\\": "\\",
                "'": "'",
                "\n": "n",
                "\r": "r",
                "\u2028": "u2028",
                "\u2029": "u2029"
            },
            Jh = parseFloat,
            ed = parseInt,
            gu = typeof xr == "object" && xr && xr.Object === Object && xr,
            td = typeof self == "object" && self && self.Object === Object && self,
            De = gu || td || Function("return this")(),
            Ms = n && !n.nodeType && n,
            fn = Ms && !0 && r && !r.nodeType && r,
            _u = fn && fn.exports === Ms,
            Bs = _u && gu.process,
            it = function() {
                try {
                    var y = fn && fn.require && fn.require("util").types;
                    return y || Bs && Bs.binding && Bs.binding("util")
                } catch (x) {}
            }(),
            mu = it && it.isArrayBuffer,
            yu = it && it.isDate,
            vu = it && it.isMap,
            wu = it && it.isRegExp,
            bu = it && it.isSet,
            Eu = it && it.isTypedArray;

        function Ve(y, x, T) {
            switch (T.length) {
                case 0:
                    return y.call(x);
                case 1:
                    return y.call(x, T[0]);
                case 2:
                    return y.call(x, T[0], T[1]);
                case 3:
                    return y.call(x, T[0], T[1], T[2])
            }
            return y.apply(x, T)
        }

        function nd(y, x, T, G) {
            for (var X = -1, ae = y == null ? 0 : y.length; ++X < ae;) {
                var Ae = y[X];
                x(G, Ae, T(Ae), y)
            }
            return G
        }

        function st(y, x) {
            for (var T = -1, G = y == null ? 0 : y.length; ++T < G && x(y[T], T, y) !== !1;);
            return y
        }

        function rd(y, x) {
            for (var T = y == null ? 0 : y.length; T-- && x(y[T], T, y) !== !1;);
            return y
        }

        function Su(y, x) {
            for (var T = -1, G = y == null ? 0 : y.length; ++T < G;)
                if (!x(y[T], T, y)) return !1;
            return !0
        }

        function jt(y, x) {
            for (var T = -1, G = y == null ? 0 : y.length, X = 0, ae = []; ++T < G;) {
                var Ae = y[T];
                x(Ae, T, y) && (ae[X++] = Ae)
            }
            return ae
        }

        function ii(y, x) {
            var T = y == null ? 0 : y.length;
            return !!T && Dn(y, x, 0) > -1
        }

        function Ns(y, x, T) {
            for (var G = -1, X = y == null ? 0 : y.length; ++G < X;)
                if (T(x, y[G])) return !0;
            return !1
        }

        function me(y, x) {
            for (var T = -1, G = y == null ? 0 : y.length, X = Array(G); ++T < G;) X[T] = x(y[T], T, y);
            return X
        }

        function zt(y, x) {
            for (var T = -1, G = x.length, X = y.length; ++T < G;) y[X + T] = x[T];
            return y
        }

        function Fs(y, x, T, G) {
            var X = -1,
                ae = y == null ? 0 : y.length;
            for (G && ae && (T = y[++X]); ++X < ae;) T = x(T, y[X], X, y);
            return T
        }

        function id(y, x, T, G) {
            var X = y == null ? 0 : y.length;
            for (G && X && (T = y[--X]); X--;) T = x(T, y[X], X, y);
            return T
        }

        function ks(y, x) {
            for (var T = -1, G = y == null ? 0 : y.length; ++T < G;)
                if (x(y[T], T, y)) return !0;
            return !1
        }
        var sd = Us("length");

        function ad(y) {
            return y.split("")
        }

        function od(y) {
            return y.match(gh) || []
        }

        function Tu(y, x, T) {
            var G;
            return T(y, function(X, ae, Ae) {
                if (x(X, ae, Ae)) return G = ae, !1
            }), G
        }

        function si(y, x, T, G) {
            for (var X = y.length, ae = T + (G ? 1 : -1); G ? ae-- : ++ae < X;)
                if (x(y[ae], ae, y)) return ae;
            return -1
        }

        function Dn(y, x, T) {
            return x === x ? vd(y, x, T) : si(y, Au, T)
        }

        function ud(y, x, T, G) {
            for (var X = T - 1, ae = y.length; ++X < ae;)
                if (G(y[X], x)) return X;
            return -1
        }

        function Au(y) {
            return y !== y
        }

        function xu(y, x) {
            var T = y == null ? 0 : y.length;
            return T ? Ws(y, x) / T : Yt
        }

        function Us(y) {
            return function(x) {
                return x == null ? i : x[y]
            }
        }

        function Ks(y) {
            return function(x) {
                return y == null ? i : y[x]
            }
        }

        function Iu(y, x, T, G, X) {
            return X(y, function(ae, Ae, le) {
                T = G ? (G = !1, ae) : x(T, ae, Ae, le)
            }), T
        }

        function ld(y, x) {
            var T = y.length;
            for (y.sort(x); T--;) y[T] = y[T].value;
            return y
        }

        function Ws(y, x) {
            for (var T, G = -1, X = y.length; ++G < X;) {
                var ae = x(y[G]);
                ae !== i && (T = T === i ? ae : T + ae)
            }
            return T
        }

        function Gs(y, x) {
            for (var T = -1, G = Array(y); ++T < y;) G[T] = x(T);
            return G
        }

        function cd(y, x) {
            return me(x, function(T) {
                return [T, y[T]]
            })
        }

        function Ru(y) {
            return y && y.slice(0, Du(y) + 1).replace(Rs, "")
        }

        function Xe(y) {
            return function(x) {
                return y(x)
            }
        }

        function Hs(y, x) {
            return me(x, function(T) {
                return y[T]
            })
        }

        function fr(y, x) {
            return y.has(x)
        }

        function Ou(y, x) {
            for (var T = -1, G = y.length; ++T < G && Dn(x, y[T], 0) > -1;);
            return T
        }

        function Pu(y, x) {
            for (var T = y.length; T-- && Dn(x, y[T], 0) > -1;);
            return T
        }

        function fd(y, x) {
            for (var T = y.length, G = 0; T--;) y[T] === x && ++G;
            return G
        }
        var hd = Ks(Vh),
            dd = Ks(Xh);

        function pd(y) {
            return "\\" + Zh[y]
        }

        function gd(y, x) {
            return y == null ? i : y[x]
        }

        function Ln(y) {
            return $h.test(y)
        }

        function _d(y) {
            return Yh.test(y)
        }

        function md(y) {
            for (var x, T = []; !(x = y.next()).done;) T.push(x.value);
            return T
        }

        function qs(y) {
            var x = -1,
                T = Array(y.size);
            return y.forEach(function(G, X) {
                T[++x] = [X, G]
            }), T
        }

        function Cu(y, x) {
            return function(T) {
                return y(x(T))
            }
        }

        function Vt(y, x) {
            for (var T = -1, G = y.length, X = 0, ae = []; ++T < G;) {
                var Ae = y[T];
                (Ae === x || Ae === v) && (y[T] = v, ae[X++] = T)
            }
            return ae
        }

        function ai(y) {
            var x = -1,
                T = Array(y.size);
            return y.forEach(function(G) {
                T[++x] = G
            }), T
        }

        function yd(y) {
            var x = -1,
                T = Array(y.size);
            return y.forEach(function(G) {
                T[++x] = [G, G]
            }), T
        }

        function vd(y, x, T) {
            for (var G = T - 1, X = y.length; ++G < X;)
                if (y[G] === x) return G;
            return -1
        }

        function wd(y, x, T) {
            for (var G = T + 1; G--;)
                if (y[G] === x) return G;
            return G
        }

        function Mn(y) {
            return Ln(y) ? Ed(y) : sd(y)
        }

        function pt(y) {
            return Ln(y) ? Sd(y) : ad(y)
        }

        function Du(y) {
            for (var x = y.length; x-- && fh.test(y.charAt(x)););
            return x
        }
        var bd = Ks(Qh);

        function Ed(y) {
            for (var x = Ls.lastIndex = 0; Ls.test(y);) ++x;
            return x
        }

        function Sd(y) {
            return y.match(Ls) || []
        }

        function Td(y) {
            return y.match(qh) || []
        }
        var Ad = function y(x) {
                x = x == null ? De : Bn.defaults(De.Object(), x, Bn.pick(De, jh));
                var T = x.Array,
                    G = x.Date,
                    X = x.Error,
                    ae = x.Function,
                    Ae = x.Math,
                    le = x.Object,
                    $s = x.RegExp,
                    xd = x.String,
                    at = x.TypeError,
                    oi = T.prototype,
                    Id = ae.prototype,
                    Nn = le.prototype,
                    ui = x["__core-js_shared__"],
                    li = Id.toString,
                    ue = Nn.hasOwnProperty,
                    Rd = 0,
                    Lu = function() {
                        var e = /[^.]+$/.exec(ui && ui.keys && ui.keys.IE_PROTO || "");
                        return e ? "Symbol(src)_1." + e : ""
                    }(),
                    ci = Nn.toString,
                    Od = li.call(le),
                    Pd = De._,
                    Cd = $s("^" + li.call(ue).replace(Is, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"),
                    fi = _u ? x.Buffer : i,
                    Xt = x.Symbol,
                    hi = x.Uint8Array,
                    Mu = fi ? fi.allocUnsafe : i,
                    di = Cu(le.getPrototypeOf, le),
                    Bu = le.create,
                    Nu = Nn.propertyIsEnumerable,
                    pi = oi.splice,
                    Fu = Xt ? Xt.isConcatSpreadable : i,
                    hr = Xt ? Xt.iterator : i,
                    hn = Xt ? Xt.toStringTag : i,
                    gi = function() {
                        try {
                            var e = mn(le, "defineProperty");
                            return e({}, "", {}), e
                        } catch (t) {}
                    }(),
                    Dd = x.clearTimeout !== De.clearTimeout && x.clearTimeout,
                    Ld = G && G.now !== De.Date.now && G.now,
                    Md = x.setTimeout !== De.setTimeout && x.setTimeout,
                    _i = Ae.ceil,
                    mi = Ae.floor,
                    Ys = le.getOwnPropertySymbols,
                    Bd = fi ? fi.isBuffer : i,
                    ku = x.isFinite,
                    Nd = oi.join,
                    Fd = Cu(le.keys, le),
                    xe = Ae.max,
                    Ne = Ae.min,
                    kd = G.now,
                    Ud = x.parseInt,
                    Uu = Ae.random,
                    Kd = oi.reverse,
                    js = mn(x, "DataView"),
                    dr = mn(x, "Map"),
                    zs = mn(x, "Promise"),
                    Fn = mn(x, "Set"),
                    pr = mn(x, "WeakMap"),
                    gr = mn(le, "create"),
                    yi = pr && new pr,
                    kn = {},
                    Wd = yn(js),
                    Gd = yn(dr),
                    Hd = yn(zs),
                    qd = yn(Fn),
                    $d = yn(pr),
                    vi = Xt ? Xt.prototype : i,
                    _r = vi ? vi.valueOf : i,
                    Ku = vi ? vi.toString : i;

                function h(e) {
                    if (be(e) && !Q(e) && !(e instanceof re)) {
                        if (e instanceof ot) return e;
                        if (ue.call(e, "__wrapped__")) return Wl(e)
                    }
                    return new ot(e)
                }
                var Un = function() {
                    function e() {}
                    return function(t) {
                        if (!ve(t)) return {};
                        if (Bu) return Bu(t);
                        e.prototype = t;
                        var s = new e;
                        return e.prototype = i, s
                    }
                }();

                function wi() {}

                function ot(e, t) {
                    this.__wrapped__ = e, this.__actions__ = [], this.__chain__ = !!t, this.__index__ = 0, this.__values__ = i
                }
                h.templateSettings = {
                    escape: sh,
                    evaluate: ah,
                    interpolate: Vo,
                    variable: "",
                    imports: {
                        _: h
                    }
                }, h.prototype = wi.prototype, h.prototype.constructor = h, ot.prototype = Un(wi.prototype), ot.prototype.constructor = ot;

                function re(e) {
                    this.__wrapped__ = e, this.__actions__ = [], this.__dir__ = 1, this.__filtered__ = !1, this.__iteratees__ = [], this.__takeCount__ = wt, this.__views__ = []
                }

                function Yd() {
                    var e = new re(this.__wrapped__);
                    return e.__actions__ = $e(this.__actions__), e.__dir__ = this.__dir__, e.__filtered__ = this.__filtered__, e.__iteratees__ = $e(this.__iteratees__), e.__takeCount__ = this.__takeCount__, e.__views__ = $e(this.__views__), e
                }

                function jd() {
                    if (this.__filtered__) {
                        var e = new re(this);
                        e.__dir__ = -1, e.__filtered__ = !0
                    } else e = this.clone(), e.__dir__ *= -1;
                    return e
                }

                function zd() {
                    var e = this.__wrapped__.value(),
                        t = this.__dir__,
                        s = Q(e),
                        o = t < 0,
                        c = s ? e.length : 0,
                        d = ag(0, c, this.__views__),
                        _ = d.start,
                        m = d.end,
                        w = m - _,
                        P = o ? m : _ - 1,
                        C = this.__iteratees__,
                        D = C.length,
                        K = 0,
                        q = Ne(w, this.__takeCount__);
                    if (!s || !o && c == w && q == w) return cl(e, this.__actions__);
                    var j = [];
                    e: for (; w-- && K < q;) {
                        P += t;
                        for (var ee = -1, z = e[P]; ++ee < D;) {
                            var ne = C[ee],
                                ie = ne.iteratee,
                                Je = ne.type,
                                Ge = ie(z);
                            if (Je == qt) z = Ge;
                            else if (!Ge) {
                                if (Je == de) continue e;
                                break e
                            }
                        }
                        j[K++] = z
                    }
                    return j
                }
                re.prototype = Un(wi.prototype), re.prototype.constructor = re;

                function dn(e) {
                    var t = -1,
                        s = e == null ? 0 : e.length;
                    for (this.clear(); ++t < s;) {
                        var o = e[t];
                        this.set(o[0], o[1])
                    }
                }

                function Vd() {
                    this.__data__ = gr ? gr(null) : {}, this.size = 0
                }

                function Xd(e) {
                    var t = this.has(e) && delete this.__data__[e];
                    return this.size -= t ? 1 : 0, t
                }

                function Qd(e) {
                    var t = this.__data__;
                    if (gr) {
                        var s = t[e];
                        return s === g ? i : s
                    }
                    return ue.call(t, e) ? t[e] : i
                }

                function Zd(e) {
                    var t = this.__data__;
                    return gr ? t[e] !== i : ue.call(t, e)
                }

                function Jd(e, t) {
                    var s = this.__data__;
                    return this.size += this.has(e) ? 0 : 1, s[e] = gr && t === i ? g : t, this
                }
                dn.prototype.clear = Vd, dn.prototype.delete = Xd, dn.prototype.get = Qd, dn.prototype.has = Zd, dn.prototype.set = Jd;

                function It(e) {
                    var t = -1,
                        s = e == null ? 0 : e.length;
                    for (this.clear(); ++t < s;) {
                        var o = e[t];
                        this.set(o[0], o[1])
                    }
                }

                function ep() {
                    this.__data__ = [], this.size = 0
                }

                function tp(e) {
                    var t = this.__data__,
                        s = bi(t, e);
                    if (s < 0) return !1;
                    var o = t.length - 1;
                    return s == o ? t.pop() : pi.call(t, s, 1), --this.size, !0
                }

                function np(e) {
                    var t = this.__data__,
                        s = bi(t, e);
                    return s < 0 ? i : t[s][1]
                }

                function rp(e) {
                    return bi(this.__data__, e) > -1
                }

                function ip(e, t) {
                    var s = this.__data__,
                        o = bi(s, e);
                    return o < 0 ? (++this.size, s.push([e, t])) : s[o][1] = t, this
                }
                It.prototype.clear = ep, It.prototype.delete = tp, It.prototype.get = np, It.prototype.has = rp, It.prototype.set = ip;

                function Rt(e) {
                    var t = -1,
                        s = e == null ? 0 : e.length;
                    for (this.clear(); ++t < s;) {
                        var o = e[t];
                        this.set(o[0], o[1])
                    }
                }

                function sp() {
                    this.size = 0, this.__data__ = {
                        hash: new dn,
                        map: new(dr || It),
                        string: new dn
                    }
                }

                function ap(e) {
                    var t = Li(this, e).delete(e);
                    return this.size -= t ? 1 : 0, t
                }

                function op(e) {
                    return Li(this, e).get(e)
                }

                function up(e) {
                    return Li(this, e).has(e)
                }

                function lp(e, t) {
                    var s = Li(this, e),
                        o = s.size;
                    return s.set(e, t), this.size += s.size == o ? 0 : 1, this
                }
                Rt.prototype.clear = sp, Rt.prototype.delete = ap, Rt.prototype.get = op, Rt.prototype.has = up, Rt.prototype.set = lp;

                function pn(e) {
                    var t = -1,
                        s = e == null ? 0 : e.length;
                    for (this.__data__ = new Rt; ++t < s;) this.add(e[t])
                }

                function cp(e) {
                    return this.__data__.set(e, g), this
                }

                function fp(e) {
                    return this.__data__.has(e)
                }
                pn.prototype.add = pn.prototype.push = cp, pn.prototype.has = fp;

                function gt(e) {
                    var t = this.__data__ = new It(e);
                    this.size = t.size
                }

                function hp() {
                    this.__data__ = new It, this.size = 0
                }

                function dp(e) {
                    var t = this.__data__,
                        s = t.delete(e);
                    return this.size = t.size, s
                }

                function pp(e) {
                    return this.__data__.get(e)
                }

                function gp(e) {
                    return this.__data__.has(e)
                }

                function _p(e, t) {
                    var s = this.__data__;
                    if (s instanceof It) {
                        var o = s.__data__;
                        if (!dr || o.length < u - 1) return o.push([e, t]), this.size = ++s.size, this;
                        s = this.__data__ = new Rt(o)
                    }
                    return s.set(e, t), this.size = s.size, this
                }
                gt.prototype.clear = hp, gt.prototype.delete = dp, gt.prototype.get = pp, gt.prototype.has = gp, gt.prototype.set = _p;

                function Wu(e, t) {
                    var s = Q(e),
                        o = !s && vn(e),
                        c = !s && !o && tn(e),
                        d = !s && !o && !c && Hn(e),
                        _ = s || o || c || d,
                        m = _ ? Gs(e.length, xd) : [],
                        w = m.length;
                    for (var P in e)(t || ue.call(e, P)) && !(_ && (P == "length" || c && (P == "offset" || P == "parent") || d && (P == "buffer" || P == "byteLength" || P == "byteOffset") || Dt(P, w))) && m.push(P);
                    return m
                }

                function Gu(e) {
                    var t = e.length;
                    return t ? e[sa(0, t - 1)] : i
                }

                function mp(e, t) {
                    return Mi($e(e), gn(t, 0, e.length))
                }

                function yp(e) {
                    return Mi($e(e))
                }

                function Vs(e, t, s) {
                    (s !== i && !_t(e[t], s) || s === i && !(t in e)) && Ot(e, t, s)
                }

                function mr(e, t, s) {
                    var o = e[t];
                    (!(ue.call(e, t) && _t(o, s)) || s === i && !(t in e)) && Ot(e, t, s)
                }

                function bi(e, t) {
                    for (var s = e.length; s--;)
                        if (_t(e[s][0], t)) return s;
                    return -1
                }

                function vp(e, t, s, o) {
                    return Qt(e, function(c, d, _) {
                        t(o, c, s(c), _)
                    }), o
                }

                function Hu(e, t) {
                    return e && Et(t, Oe(t), e)
                }

                function wp(e, t) {
                    return e && Et(t, je(t), e)
                }

                function Ot(e, t, s) {
                    t == "__proto__" && gi ? gi(e, t, {
                        configurable: !0,
                        enumerable: !0,
                        value: s,
                        writable: !0
                    }) : e[t] = s
                }

                function Xs(e, t) {
                    for (var s = -1, o = t.length, c = T(o), d = e == null; ++s < o;) c[s] = d ? i : Pa(e, t[s]);
                    return c
                }

                function gn(e, t, s) {
                    return e === e && (s !== i && (e = e <= s ? e : s), t !== i && (e = e >= t ? e : t)), e
                }

                function ut(e, t, s, o, c, d) {
                    var _, m = t & S,
                        w = t & b,
                        P = t & A;
                    if (s && (_ = c ? s(e, o, c, d) : s(e)), _ !== i) return _;
                    if (!ve(e)) return e;
                    var C = Q(e);
                    if (C) {
                        if (_ = ug(e), !m) return $e(e, _)
                    } else {
                        var D = Fe(e),
                            K = D == Jr || D == $o;
                        if (tn(e)) return dl(e, m);
                        if (D == xt || D == On || K && !c) {
                            if (_ = w || K ? {} : Dl(e), !m) return w ? Qp(e, wp(_, e)) : Xp(e, Hu(_, e))
                        } else {
                            if (!fe[D]) return c ? e : {};
                            _ = lg(e, D, m)
                        }
                    }
                    d || (d = new gt);
                    var q = d.get(e);
                    if (q) return q;
                    d.set(e, _), oc(e) ? e.forEach(function(z) {
                        _.add(ut(z, t, s, z, e, d))
                    }) : sc(e) && e.forEach(function(z, ne) {
                        _.set(ne, ut(z, t, s, ne, e, d))
                    });
                    var j = P ? w ? _a : ga : w ? je : Oe,
                        ee = C ? i : j(e);
                    return st(ee || e, function(z, ne) {
                        ee && (ne = z, z = e[ne]), mr(_, ne, ut(z, t, s, ne, e, d))
                    }), _
                }

                function bp(e) {
                    var t = Oe(e);
                    return function(s) {
                        return qu(s, e, t)
                    }
                }

                function qu(e, t, s) {
                    var o = s.length;
                    if (e == null) return !o;
                    for (e = le(e); o--;) {
                        var c = s[o],
                            d = t[c],
                            _ = e[c];
                        if (_ === i && !(c in e) || !d(_)) return !1
                    }
                    return !0
                }

                function $u(e, t, s) {
                    if (typeof e != "function") throw new at(f);
                    return Tr(function() {
                        e.apply(i, s)
                    }, t)
                }

                function yr(e, t, s, o) {
                    var c = -1,
                        d = ii,
                        _ = !0,
                        m = e.length,
                        w = [],
                        P = t.length;
                    if (!m) return w;
                    s && (t = me(t, Xe(s))), o ? (d = Ns, _ = !1) : t.length >= u && (d = fr, _ = !1, t = new pn(t));
                    e: for (; ++c < m;) {
                        var C = e[c],
                            D = s == null ? C : s(C);
                        if (C = o || C !== 0 ? C : 0, _ && D === D) {
                            for (var K = P; K--;)
                                if (t[K] === D) continue e;
                            w.push(C)
                        } else d(t, D, o) || w.push(C)
                    }
                    return w
                }
                var Qt = yl(bt),
                    Yu = yl(Zs, !0);

                function Ep(e, t) {
                    var s = !0;
                    return Qt(e, function(o, c, d) {
                        return s = !!t(o, c, d), s
                    }), s
                }

                function Ei(e, t, s) {
                    for (var o = -1, c = e.length; ++o < c;) {
                        var d = e[o],
                            _ = t(d);
                        if (_ != null && (m === i ? _ === _ && !Ze(_) : s(_, m))) var m = _,
                            w = d
                    }
                    return w
                }

                function Sp(e, t, s, o) {
                    var c = e.length;
                    for (s = J(s), s < 0 && (s = -s > c ? 0 : c + s), o = o === i || o > c ? c : J(o), o < 0 && (o += c), o = s > o ? 0 : lc(o); s < o;) e[s++] = t;
                    return e
                }

                function ju(e, t) {
                    var s = [];
                    return Qt(e, function(o, c, d) {
                        t(o, c, d) && s.push(o)
                    }), s
                }

                function Le(e, t, s, o, c) {
                    var d = -1,
                        _ = e.length;
                    for (s || (s = fg), c || (c = []); ++d < _;) {
                        var m = e[d];
                        t > 0 && s(m) ? t > 1 ? Le(m, t - 1, s, o, c) : zt(c, m) : o || (c[c.length] = m)
                    }
                    return c
                }
                var Qs = vl(),
                    zu = vl(!0);

                function bt(e, t) {
                    return e && Qs(e, t, Oe)
                }

                function Zs(e, t) {
                    return e && zu(e, t, Oe)
                }

                function Si(e, t) {
                    return jt(t, function(s) {
                        return Lt(e[s])
                    })
                }

                function _n(e, t) {
                    t = Jt(t, e);
                    for (var s = 0, o = t.length; e != null && s < o;) e = e[St(t[s++])];
                    return s && s == o ? e : i
                }

                function Vu(e, t, s) {
                    var o = t(e);
                    return Q(e) ? o : zt(o, s(e))
                }

                function Ke(e) {
                    return e == null ? e === i ? Zf : Xf : hn && hn in le(e) ? sg(e) : yg(e)
                }

                function Js(e, t) {
                    return e > t
                }

                function Tp(e, t) {
                    return e != null && ue.call(e, t)
                }

                function Ap(e, t) {
                    return e != null && t in le(e)
                }

                function xp(e, t, s) {
                    return e >= Ne(t, s) && e < xe(t, s)
                }

                function ea(e, t, s) {
                    for (var o = s ? Ns : ii, c = e[0].length, d = e.length, _ = d, m = T(d), w = 1 / 0, P = []; _--;) {
                        var C = e[_];
                        _ && t && (C = me(C, Xe(t))), w = Ne(C.length, w), m[_] = !s && (t || c >= 120 && C.length >= 120) ? new pn(_ && C) : i
                    }
                    C = e[0];
                    var D = -1,
                        K = m[0];
                    e: for (; ++D < c && P.length < w;) {
                        var q = C[D],
                            j = t ? t(q) : q;
                        if (q = s || q !== 0 ? q : 0, !(K ? fr(K, j) : o(P, j, s))) {
                            for (_ = d; --_;) {
                                var ee = m[_];
                                if (!(ee ? fr(ee, j) : o(e[_], j, s))) continue e
                            }
                            K && K.push(j), P.push(q)
                        }
                    }
                    return P
                }

                function Ip(e, t, s, o) {
                    return bt(e, function(c, d, _) {
                        t(o, s(c), d, _)
                    }), o
                }

                function vr(e, t, s) {
                    t = Jt(t, e), e = Nl(e, t);
                    var o = e == null ? e : e[St(ct(t))];
                    return o == null ? i : Ve(o, e, s)
                }

                function Xu(e) {
                    return be(e) && Ke(e) == On
                }

                function Rp(e) {
                    return be(e) && Ke(e) == cr
                }

                function Op(e) {
                    return be(e) && Ke(e) == sr
                }

                function wr(e, t, s, o, c) {
                    return e === t ? !0 : e == null || t == null || !be(e) && !be(t) ? e !== e && t !== t : Pp(e, t, s, o, wr, c)
                }

                function Pp(e, t, s, o, c, d) {
                    var _ = Q(e),
                        m = Q(t),
                        w = _ ? Qr : Fe(e),
                        P = m ? Qr : Fe(t);
                    w = w == On ? xt : w, P = P == On ? xt : P;
                    var C = w == xt,
                        D = P == xt,
                        K = w == P;
                    if (K && tn(e)) {
                        if (!tn(t)) return !1;
                        _ = !0, C = !1
                    }
                    if (K && !C) return d || (d = new gt), _ || Hn(e) ? Ol(e, t, s, o, c, d) : rg(e, t, w, s, o, c, d);
                    if (!(s & M)) {
                        var q = C && ue.call(e, "__wrapped__"),
                            j = D && ue.call(t, "__wrapped__");
                        if (q || j) {
                            var ee = q ? e.value() : e,
                                z = j ? t.value() : t;
                            return d || (d = new gt), c(ee, z, s, o, d)
                        }
                    }
                    return K ? (d || (d = new gt), ig(e, t, s, o, c, d)) : !1
                }

                function Cp(e) {
                    return be(e) && Fe(e) == ht
                }

                function ta(e, t, s, o) {
                    var c = s.length,
                        d = c,
                        _ = !o;
                    if (e == null) return !d;
                    for (e = le(e); c--;) {
                        var m = s[c];
                        if (_ && m[2] ? m[1] !== e[m[0]] : !(m[0] in e)) return !1
                    }
                    for (; ++c < d;) {
                        m = s[c];
                        var w = m[0],
                            P = e[w],
                            C = m[1];
                        if (_ && m[2]) {
                            if (P === i && !(w in e)) return !1
                        } else {
                            var D = new gt;
                            if (o) var K = o(P, C, w, e, t, D);
                            if (!(K === i ? wr(C, P, M | I, o, D) : K)) return !1
                        }
                    }
                    return !0
                }

                function Qu(e) {
                    if (!ve(e) || dg(e)) return !1;
                    var t = Lt(e) ? Cd : bh;
                    return t.test(yn(e))
                }

                function Dp(e) {
                    return be(e) && Ke(e) == or
                }

                function Lp(e) {
                    return be(e) && Fe(e) == dt
                }

                function Mp(e) {
                    return be(e) && Ki(e.length) && !!pe[Ke(e)]
                }

                function Zu(e) {
                    return typeof e == "function" ? e : e == null ? ze : typeof e == "object" ? Q(e) ? tl(e[0], e[1]) : el(e) : wc(e)
                }

                function na(e) {
                    if (!Sr(e)) return Fd(e);
                    var t = [];
                    for (var s in le(e)) ue.call(e, s) && s != "constructor" && t.push(s);
                    return t
                }

                function Bp(e) {
                    if (!ve(e)) return mg(e);
                    var t = Sr(e),
                        s = [];
                    for (var o in e) o == "constructor" && (t || !ue.call(e, o)) || s.push(o);
                    return s
                }

                function ra(e, t) {
                    return e < t
                }

                function Ju(e, t) {
                    var s = -1,
                        o = Ye(e) ? T(e.length) : [];
                    return Qt(e, function(c, d, _) {
                        o[++s] = t(c, d, _)
                    }), o
                }

                function el(e) {
                    var t = ya(e);
                    return t.length == 1 && t[0][2] ? Ml(t[0][0], t[0][1]) : function(s) {
                        return s === e || ta(s, e, t)
                    }
                }

                function tl(e, t) {
                    return wa(e) && Ll(t) ? Ml(St(e), t) : function(s) {
                        var o = Pa(s, e);
                        return o === i && o === t ? Ca(s, e) : wr(t, o, M | I)
                    }
                }

                function Ti(e, t, s, o, c) {
                    e !== t && Qs(t, function(d, _) {
                        if (c || (c = new gt), ve(d)) Np(e, t, _, s, Ti, o, c);
                        else {
                            var m = o ? o(Ea(e, _), d, _ + "", e, t, c) : i;
                            m === i && (m = d), Vs(e, _, m)
                        }
                    }, je)
                }

                function Np(e, t, s, o, c, d, _) {
                    var m = Ea(e, s),
                        w = Ea(t, s),
                        P = _.get(w);
                    if (P) {
                        Vs(e, s, P);
                        return
                    }
                    var C = d ? d(m, w, s + "", e, t, _) : i,
                        D = C === i;
                    if (D) {
                        var K = Q(w),
                            q = !K && tn(w),
                            j = !K && !q && Hn(w);
                        C = w, K || q || j ? Q(m) ? C = m : Ee(m) ? C = $e(m) : q ? (D = !1, C = dl(w, !0)) : j ? (D = !1, C = pl(w, !0)) : C = [] : Ar(w) || vn(w) ? (C = m, vn(m) ? C = cc(m) : (!ve(m) || Lt(m)) && (C = Dl(w))) : D = !1
                    }
                    D && (_.set(w, C), c(C, w, o, d, _), _.delete(w)), Vs(e, s, C)
                }

                function nl(e, t) {
                    var s = e.length;
                    if (s) return t += t < 0 ? s : 0, Dt(t, s) ? e[t] : i
                }

                function rl(e, t, s) {
                    t.length ? t = me(t, function(d) {
                        return Q(d) ? function(_) {
                            return _n(_, d.length === 1 ? d[0] : d)
                        } : d
                    }) : t = [ze];
                    var o = -1;
                    t = me(t, Xe(Y()));
                    var c = Ju(e, function(d, _, m) {
                        var w = me(t, function(P) {
                            return P(d)
                        });
                        return {
                            criteria: w,
                            index: ++o,
                            value: d
                        }
                    });
                    return ld(c, function(d, _) {
                        return Vp(d, _, s)
                    })
                }

                function Fp(e, t) {
                    return il(e, t, function(s, o) {
                        return Ca(e, o)
                    })
                }

                function il(e, t, s) {
                    for (var o = -1, c = t.length, d = {}; ++o < c;) {
                        var _ = t[o],
                            m = _n(e, _);
                        s(m, _) && br(d, Jt(_, e), m)
                    }
                    return d
                }

                function kp(e) {
                    return function(t) {
                        return _n(t, e)
                    }
                }

                function ia(e, t, s, o) {
                    var c = o ? ud : Dn,
                        d = -1,
                        _ = t.length,
                        m = e;
                    for (e === t && (t = $e(t)), s && (m = me(e, Xe(s))); ++d < _;)
                        for (var w = 0, P = t[d], C = s ? s(P) : P;
                            (w = c(m, C, w, o)) > -1;) m !== e && pi.call(m, w, 1), pi.call(e, w, 1);
                    return e
                }

                function sl(e, t) {
                    for (var s = e ? t.length : 0, o = s - 1; s--;) {
                        var c = t[s];
                        if (s == o || c !== d) {
                            var d = c;
                            Dt(c) ? pi.call(e, c, 1) : ua(e, c)
                        }
                    }
                    return e
                }

                function sa(e, t) {
                    return e + mi(Uu() * (t - e + 1))
                }

                function Up(e, t, s, o) {
                    for (var c = -1, d = xe(_i((t - e) / (s || 1)), 0), _ = T(d); d--;) _[o ? d : ++c] = e, e += s;
                    return _
                }

                function aa(e, t) {
                    var s = "";
                    if (!e || t < 1 || t > Be) return s;
                    do t % 2 && (s += e), t = mi(t / 2), t && (e += e); while (t);
                    return s
                }

                function te(e, t) {
                    return Sa(Bl(e, t, ze), e + "")
                }

                function Kp(e) {
                    return Gu(qn(e))
                }

                function Wp(e, t) {
                    var s = qn(e);
                    return Mi(s, gn(t, 0, s.length))
                }

                function br(e, t, s, o) {
                    if (!ve(e)) return e;
                    t = Jt(t, e);
                    for (var c = -1, d = t.length, _ = d - 1, m = e; m != null && ++c < d;) {
                        var w = St(t[c]),
                            P = s;
                        if (w === "__proto__" || w === "constructor" || w === "prototype") return e;
                        if (c != _) {
                            var C = m[w];
                            P = o ? o(C, w, m) : i, P === i && (P = ve(C) ? C : Dt(t[c + 1]) ? [] : {})
                        }
                        mr(m, w, P), m = m[w]
                    }
                    return e
                }
                var al = yi ? function(e, t) {
                        return yi.set(e, t), e
                    } : ze,
                    Gp = gi ? function(e, t) {
                        return gi(e, "toString", {
                            configurable: !0,
                            enumerable: !1,
                            value: La(t),
                            writable: !0
                        })
                    } : ze;

                function Hp(e) {
                    return Mi(qn(e))
                }

                function lt(e, t, s) {
                    var o = -1,
                        c = e.length;
                    t < 0 && (t = -t > c ? 0 : c + t), s = s > c ? c : s, s < 0 && (s += c), c = t > s ? 0 : s - t >>> 0, t >>>= 0;
                    for (var d = T(c); ++o < c;) d[o] = e[o + t];
                    return d
                }

                function qp(e, t) {
                    var s;
                    return Qt(e, function(o, c, d) {
                        return s = t(o, c, d), !s
                    }), !!s
                }

                function Ai(e, t, s) {
                    var o = 0,
                        c = e == null ? o : e.length;
                    if (typeof t == "number" && t === t && c <= Yf) {
                        for (; o < c;) {
                            var d = o + c >>> 1,
                                _ = e[d];
                            _ !== null && !Ze(_) && (s ? _ <= t : _ < t) ? o = d + 1 : c = d
                        }
                        return c
                    }
                    return oa(e, t, ze, s)
                }

                function oa(e, t, s, o) {
                    var c = 0,
                        d = e == null ? 0 : e.length;
                    if (d === 0) return 0;
                    t = s(t);
                    for (var _ = t !== t, m = t === null, w = Ze(t), P = t === i; c < d;) {
                        var C = mi((c + d) / 2),
                            D = s(e[C]),
                            K = D !== i,
                            q = D === null,
                            j = D === D,
                            ee = Ze(D);
                        if (_) var z = o || j;
                        else P ? z = j && (o || K) : m ? z = j && K && (o || !q) : w ? z = j && K && !q && (o || !ee) : q || ee ? z = !1 : z = o ? D <= t : D < t;
                        z ? c = C + 1 : d = C
                    }
                    return Ne(d, $f)
                }

                function ol(e, t) {
                    for (var s = -1, o = e.length, c = 0, d = []; ++s < o;) {
                        var _ = e[s],
                            m = t ? t(_) : _;
                        if (!s || !_t(m, w)) {
                            var w = m;
                            d[c++] = _ === 0 ? 0 : _
                        }
                    }
                    return d
                }

                function ul(e) {
                    return typeof e == "number" ? e : Ze(e) ? Yt : +e
                }

                function Qe(e) {
                    if (typeof e == "string") return e;
                    if (Q(e)) return me(e, Qe) + "";
                    if (Ze(e)) return Ku ? Ku.call(e) : "";
                    var t = e + "";
                    return t == "0" && 1 / e == -we ? "-0" : t
                }

                function Zt(e, t, s) {
                    var o = -1,
                        c = ii,
                        d = e.length,
                        _ = !0,
                        m = [],
                        w = m;
                    if (s) _ = !1, c = Ns;
                    else if (d >= u) {
                        var P = t ? null : tg(e);
                        if (P) return ai(P);
                        _ = !1, c = fr, w = new pn
                    } else w = t ? [] : m;
                    e: for (; ++o < d;) {
                        var C = e[o],
                            D = t ? t(C) : C;
                        if (C = s || C !== 0 ? C : 0, _ && D === D) {
                            for (var K = w.length; K--;)
                                if (w[K] === D) continue e;
                            t && w.push(D), m.push(C)
                        } else c(w, D, s) || (w !== m && w.push(D), m.push(C))
                    }
                    return m
                }

                function ua(e, t) {
                    return t = Jt(t, e), e = Nl(e, t), e == null || delete e[St(ct(t))]
                }

                function ll(e, t, s, o) {
                    return br(e, t, s(_n(e, t)), o)
                }

                function xi(e, t, s, o) {
                    for (var c = e.length, d = o ? c : -1;
                        (o ? d-- : ++d < c) && t(e[d], d, e););
                    return s ? lt(e, o ? 0 : d, o ? d + 1 : c) : lt(e, o ? d + 1 : 0, o ? c : d)
                }

                function cl(e, t) {
                    var s = e;
                    return s instanceof re && (s = s.value()), Fs(t, function(o, c) {
                        return c.func.apply(c.thisArg, zt([o], c.args))
                    }, s)
                }

                function la(e, t, s) {
                    var o = e.length;
                    if (o < 2) return o ? Zt(e[0]) : [];
                    for (var c = -1, d = T(o); ++c < o;)
                        for (var _ = e[c], m = -1; ++m < o;) m != c && (d[c] = yr(d[c] || _, e[m], t, s));
                    return Zt(Le(d, 1), t, s)
                }

                function fl(e, t, s) {
                    for (var o = -1, c = e.length, d = t.length, _ = {}; ++o < c;) {
                        var m = o < d ? t[o] : i;
                        s(_, e[o], m)
                    }
                    return _
                }

                function ca(e) {
                    return Ee(e) ? e : []
                }

                function fa(e) {
                    return typeof e == "function" ? e : ze
                }

                function Jt(e, t) {
                    return Q(e) ? e : wa(e, t) ? [e] : Kl(oe(e))
                }
                var $p = te;

                function en(e, t, s) {
                    var o = e.length;
                    return s = s === i ? o : s, !t && s >= o ? e : lt(e, t, s)
                }
                var hl = Dd || function(e) {
                    return De.clearTimeout(e)
                };

                function dl(e, t) {
                    if (t) return e.slice();
                    var s = e.length,
                        o = Mu ? Mu(s) : new e.constructor(s);
                    return e.copy(o), o
                }

                function ha(e) {
                    var t = new e.constructor(e.byteLength);
                    return new hi(t).set(new hi(e)), t
                }

                function Yp(e, t) {
                    var s = t ? ha(e.buffer) : e.buffer;
                    return new e.constructor(s, e.byteOffset, e.byteLength)
                }

                function jp(e) {
                    var t = new e.constructor(e.source, Xo.exec(e));
                    return t.lastIndex = e.lastIndex, t
                }

                function zp(e) {
                    return _r ? le(_r.call(e)) : {}
                }

                function pl(e, t) {
                    var s = t ? ha(e.buffer) : e.buffer;
                    return new e.constructor(s, e.byteOffset, e.length)
                }

                function gl(e, t) {
                    if (e !== t) {
                        var s = e !== i,
                            o = e === null,
                            c = e === e,
                            d = Ze(e),
                            _ = t !== i,
                            m = t === null,
                            w = t === t,
                            P = Ze(t);
                        if (!m && !P && !d && e > t || d && _ && w && !m && !P || o && _ && w || !s && w || !c) return 1;
                        if (!o && !d && !P && e < t || P && s && c && !o && !d || m && s && c || !_ && c || !w) return -1
                    }
                    return 0
                }

                function Vp(e, t, s) {
                    for (var o = -1, c = e.criteria, d = t.criteria, _ = c.length, m = s.length; ++o < _;) {
                        var w = gl(c[o], d[o]);
                        if (w) {
                            if (o >= m) return w;
                            var P = s[o];
                            return w * (P == "desc" ? -1 : 1)
                        }
                    }
                    return e.index - t.index
                }

                function _l(e, t, s, o) {
                    for (var c = -1, d = e.length, _ = s.length, m = -1, w = t.length, P = xe(d - _, 0), C = T(w + P), D = !o; ++m < w;) C[m] = t[m];
                    for (; ++c < _;)(D || c < d) && (C[s[c]] = e[c]);
                    for (; P--;) C[m++] = e[c++];
                    return C
                }

                function ml(e, t, s, o) {
                    for (var c = -1, d = e.length, _ = -1, m = s.length, w = -1, P = t.length, C = xe(d - m, 0), D = T(C + P), K = !o; ++c < C;) D[c] = e[c];
                    for (var q = c; ++w < P;) D[q + w] = t[w];
                    for (; ++_ < m;)(K || c < d) && (D[q + s[_]] = e[c++]);
                    return D
                }

                function $e(e, t) {
                    var s = -1,
                        o = e.length;
                    for (t || (t = T(o)); ++s < o;) t[s] = e[s];
                    return t
                }

                function Et(e, t, s, o) {
                    var c = !s;
                    s || (s = {});
                    for (var d = -1, _ = t.length; ++d < _;) {
                        var m = t[d],
                            w = o ? o(s[m], e[m], m, s, e) : i;
                        w === i && (w = e[m]), c ? Ot(s, m, w) : mr(s, m, w)
                    }
                    return s
                }

                function Xp(e, t) {
                    return Et(e, va(e), t)
                }

                function Qp(e, t) {
                    return Et(e, Pl(e), t)
                }

                function Ii(e, t) {
                    return function(s, o) {
                        var c = Q(s) ? nd : vp,
                            d = t ? t() : {};
                        return c(s, e, Y(o, 2), d)
                    }
                }

                function Kn(e) {
                    return te(function(t, s) {
                        var o = -1,
                            c = s.length,
                            d = c > 1 ? s[c - 1] : i,
                            _ = c > 2 ? s[2] : i;
                        for (d = e.length > 3 && typeof d == "function" ? (c--, d) : i, _ && We(s[0], s[1], _) && (d = c < 3 ? i : d, c = 1), t = le(t); ++o < c;) {
                            var m = s[o];
                            m && e(t, m, o, d)
                        }
                        return t
                    })
                }

                function yl(e, t) {
                    return function(s, o) {
                        if (s == null) return s;
                        if (!Ye(s)) return e(s, o);
                        for (var c = s.length, d = t ? c : -1, _ = le(s);
                            (t ? d-- : ++d < c) && o(_[d], d, _) !== !1;);
                        return s
                    }
                }

                function vl(e) {
                    return function(t, s, o) {
                        for (var c = -1, d = le(t), _ = o(t), m = _.length; m--;) {
                            var w = _[e ? m : ++c];
                            if (s(d[w], w, d) === !1) break
                        }
                        return t
                    }
                }

                function Zp(e, t, s) {
                    var o = t & L,
                        c = Er(e);

                    function d() {
                        var _ = this && this !== De && this instanceof d ? c : e;
                        return _.apply(o ? s : this, arguments)
                    }
                    return d
                }

                function wl(e) {
                    return function(t) {
                        t = oe(t);
                        var s = Ln(t) ? pt(t) : i,
                            o = s ? s[0] : t.charAt(0),
                            c = s ? en(s, 1).join("") : t.slice(1);
                        return o[e]() + c
                    }
                }

                function Wn(e) {
                    return function(t) {
                        return Fs(yc(mc(t).replace(Gh, "")), e, "")
                    }
                }

                function Er(e) {
                    return function() {
                        var t = arguments;
                        switch (t.length) {
                            case 0:
                                return new e;
                            case 1:
                                return new e(t[0]);
                            case 2:
                                return new e(t[0], t[1]);
                            case 3:
                                return new e(t[0], t[1], t[2]);
                            case 4:
                                return new e(t[0], t[1], t[2], t[3]);
                            case 5:
                                return new e(t[0], t[1], t[2], t[3], t[4]);
                            case 6:
                                return new e(t[0], t[1], t[2], t[3], t[4], t[5]);
                            case 7:
                                return new e(t[0], t[1], t[2], t[3], t[4], t[5], t[6])
                        }
                        var s = Un(e.prototype),
                            o = e.apply(s, t);
                        return ve(o) ? o : s
                    }
                }

                function Jp(e, t, s) {
                    var o = Er(e);

                    function c() {
                        for (var d = arguments.length, _ = T(d), m = d, w = Gn(c); m--;) _[m] = arguments[m];
                        var P = d < 3 && _[0] !== w && _[d - 1] !== w ? [] : Vt(_, w);
                        if (d -= P.length, d < s) return Al(e, t, Ri, c.placeholder, i, _, P, i, i, s - d);
                        var C = this && this !== De && this instanceof c ? o : e;
                        return Ve(C, this, _)
                    }
                    return c
                }

                function bl(e) {
                    return function(t, s, o) {
                        var c = le(t);
                        if (!Ye(t)) {
                            var d = Y(s, 3);
                            t = Oe(t), s = function(m) {
                                return d(c[m], m, c)
                            }
                        }
                        var _ = e(t, s, o);
                        return _ > -1 ? c[d ? t[_] : _] : i
                    }
                }

                function El(e) {
                    return Ct(function(t) {
                        var s = t.length,
                            o = s,
                            c = ot.prototype.thru;
                        for (e && t.reverse(); o--;) {
                            var d = t[o];
                            if (typeof d != "function") throw new at(f);
                            if (c && !_ && Di(d) == "wrapper") var _ = new ot([], !0)
                        }
                        for (o = _ ? o : s; ++o < s;) {
                            d = t[o];
                            var m = Di(d),
                                w = m == "wrapper" ? ma(d) : i;
                            w && ba(w[0]) && w[1] == (B | N | F | Z) && !w[4].length && w[9] == 1 ? _ = _[Di(w[0])].apply(_, w[3]) : _ = d.length == 1 && ba(d) ? _[m]() : _.thru(d)
                        }
                        return function() {
                            var P = arguments,
                                C = P[0];
                            if (_ && P.length == 1 && Q(C)) return _.plant(C).value();
                            for (var D = 0, K = s ? t[D].apply(this, P) : C; ++D < s;) K = t[D].call(this, K);
                            return K
                        }
                    })
                }

                function Ri(e, t, s, o, c, d, _, m, w, P) {
                    var C = t & B,
                        D = t & L,
                        K = t & O,
                        q = t & (N | W),
                        j = t & U,
                        ee = K ? i : Er(e);

                    function z() {
                        for (var ne = arguments.length, ie = T(ne), Je = ne; Je--;) ie[Je] = arguments[Je];
                        if (q) var Ge = Gn(z),
                            et = fd(ie, Ge);
                        if (o && (ie = _l(ie, o, c, q)), d && (ie = ml(ie, d, _, q)), ne -= et, q && ne < P) {
                            var Se = Vt(ie, Ge);
                            return Al(e, t, Ri, z.placeholder, s, ie, Se, m, w, P - ne)
                        }
                        var mt = D ? s : this,
                            Bt = K ? mt[e] : e;
                        return ne = ie.length, m ? ie = vg(ie, m) : j && ne > 1 && ie.reverse(), C && w < ne && (ie.length = w), this && this !== De && this instanceof z && (Bt = ee || Er(Bt)), Bt.apply(mt, ie)
                    }
                    return z
                }

                function Sl(e, t) {
                    return function(s, o) {
                        return Ip(s, e, t(o), {})
                    }
                }

                function Oi(e, t) {
                    return function(s, o) {
                        var c;
                        if (s === i && o === i) return t;
                        if (s !== i && (c = s), o !== i) {
                            if (c === i) return o;
                            typeof s == "string" || typeof o == "string" ? (s = Qe(s), o = Qe(o)) : (s = ul(s), o = ul(o)), c = e(s, o)
                        }
                        return c
                    }
                }

                function da(e) {
                    return Ct(function(t) {
                        return t = me(t, Xe(Y())), te(function(s) {
                            var o = this;
                            return e(t, function(c) {
                                return Ve(c, o, s)
                            })
                        })
                    })
                }

                function Pi(e, t) {
                    t = t === i ? " " : Qe(t);
                    var s = t.length;
                    if (s < 2) return s ? aa(t, e) : t;
                    var o = aa(t, _i(e / Mn(t)));
                    return Ln(t) ? en(pt(o), 0, e).join("") : o.slice(0, e)
                }

                function eg(e, t, s, o) {
                    var c = t & L,
                        d = Er(e);

                    function _() {
                        for (var m = -1, w = arguments.length, P = -1, C = o.length, D = T(C + w), K = this && this !== De && this instanceof _ ? d : e; ++P < C;) D[P] = o[P];
                        for (; w--;) D[P++] = arguments[++m];
                        return Ve(K, c ? s : this, D)
                    }
                    return _
                }

                function Tl(e) {
                    return function(t, s, o) {
                        return o && typeof o != "number" && We(t, s, o) && (s = o = i), t = Mt(t), s === i ? (s = t, t = 0) : s = Mt(s), o = o === i ? t < s ? 1 : -1 : Mt(o), Up(t, s, o, e)
                    }
                }

                function Ci(e) {
                    return function(t, s) {
                        return typeof t == "string" && typeof s == "string" || (t = ft(t), s = ft(s)), e(t, s)
                    }
                }

                function Al(e, t, s, o, c, d, _, m, w, P) {
                    var C = t & N,
                        D = C ? _ : i,
                        K = C ? i : _,
                        q = C ? d : i,
                        j = C ? i : d;
                    t |= C ? F : k, t &= ~(C ? k : F), t & R || (t &= ~(L | O));
                    var ee = [e, t, c, q, D, j, K, m, w, P],
                        z = s.apply(i, ee);
                    return ba(e) && Fl(z, ee), z.placeholder = o, kl(z, e, t)
                }

                function pa(e) {
                    var t = Ae[e];
                    return function(s, o) {
                        if (s = ft(s), o = o == null ? 0 : Ne(J(o), 292), o && ku(s)) {
                            var c = (oe(s) + "e").split("e"),
                                d = t(c[0] + "e" + (+c[1] + o));
                            return c = (oe(d) + "e").split("e"), +(c[0] + "e" + (+c[1] - o))
                        }
                        return t(s)
                    }
                }
                var tg = Fn && 1 / ai(new Fn([, -0]))[1] == we ? function(e) {
                    return new Fn(e)
                } : Na;

                function xl(e) {
                    return function(t) {
                        var s = Fe(t);
                        return s == ht ? qs(t) : s == dt ? yd(t) : cd(t, e(t))
                    }
                }

                function Pt(e, t, s, o, c, d, _, m) {
                    var w = t & O;
                    if (!w && typeof e != "function") throw new at(f);
                    var P = o ? o.length : 0;
                    if (P || (t &= ~(F | k), o = c = i), _ = _ === i ? _ : xe(J(_), 0), m = m === i ? m : J(m), P -= c ? c.length : 0, t & k) {
                        var C = o,
                            D = c;
                        o = c = i
                    }
                    var K = w ? i : ma(e),
                        q = [e, t, s, o, c, C, D, d, _, m];
                    if (K && _g(q, K), e = q[0], t = q[1], s = q[2], o = q[3], c = q[4], m = q[9] = q[9] === i ? w ? 0 : e.length : xe(q[9] - P, 0), !m && t & (N | W) && (t &= ~(N | W)), !t || t == L) var j = Zp(e, t, s);
                    else t == N || t == W ? j = Jp(e, t, m) : (t == F || t == (L | F)) && !c.length ? j = eg(e, t, s, o) : j = Ri.apply(i, q);
                    var ee = K ? al : Fl;
                    return kl(ee(j, q), e, t)
                }

                function Il(e, t, s, o) {
                    return e === i || _t(e, Nn[s]) && !ue.call(o, s) ? t : e
                }

                function Rl(e, t, s, o, c, d) {
                    return ve(e) && ve(t) && (d.set(t, e), Ti(e, t, i, Rl, d), d.delete(t)), e
                }

                function ng(e) {
                    return Ar(e) ? i : e
                }

                function Ol(e, t, s, o, c, d) {
                    var _ = s & M,
                        m = e.length,
                        w = t.length;
                    if (m != w && !(_ && w > m)) return !1;
                    var P = d.get(e),
                        C = d.get(t);
                    if (P && C) return P == t && C == e;
                    var D = -1,
                        K = !0,
                        q = s & I ? new pn : i;
                    for (d.set(e, t), d.set(t, e); ++D < m;) {
                        var j = e[D],
                            ee = t[D];
                        if (o) var z = _ ? o(ee, j, D, t, e, d) : o(j, ee, D, e, t, d);
                        if (z !== i) {
                            if (z) continue;
                            K = !1;
                            break
                        }
                        if (q) {
                            if (!ks(t, function(ne, ie) {
                                    if (!fr(q, ie) && (j === ne || c(j, ne, s, o, d))) return q.push(ie)
                                })) {
                                K = !1;
                                break
                            }
                        } else if (!(j === ee || c(j, ee, s, o, d))) {
                            K = !1;
                            break
                        }
                    }
                    return d.delete(e), d.delete(t), K
                }

                function rg(e, t, s, o, c, d, _) {
                    switch (s) {
                        case Pn:
                            if (e.byteLength != t.byteLength || e.byteOffset != t.byteOffset) return !1;
                            e = e.buffer, t = t.buffer;
                        case cr:
                            return !(e.byteLength != t.byteLength || !d(new hi(e), new hi(t)));
                        case ir:
                        case sr:
                        case ar:
                            return _t(+e, +t);
                        case Zr:
                            return e.name == t.name && e.message == t.message;
                        case or:
                        case ur:
                            return e == t + "";
                        case ht:
                            var m = qs;
                        case dt:
                            var w = o & M;
                            if (m || (m = ai), e.size != t.size && !w) return !1;
                            var P = _.get(e);
                            if (P) return P == t;
                            o |= I, _.set(e, t);
                            var C = Ol(m(e), m(t), o, c, d, _);
                            return _.delete(e), C;
                        case ei:
                            if (_r) return _r.call(e) == _r.call(t)
                    }
                    return !1
                }

                function ig(e, t, s, o, c, d) {
                    var _ = s & M,
                        m = ga(e),
                        w = m.length,
                        P = ga(t),
                        C = P.length;
                    if (w != C && !_) return !1;
                    for (var D = w; D--;) {
                        var K = m[D];
                        if (!(_ ? K in t : ue.call(t, K))) return !1
                    }
                    var q = d.get(e),
                        j = d.get(t);
                    if (q && j) return q == t && j == e;
                    var ee = !0;
                    d.set(e, t), d.set(t, e);
                    for (var z = _; ++D < w;) {
                        K = m[D];
                        var ne = e[K],
                            ie = t[K];
                        if (o) var Je = _ ? o(ie, ne, K, t, e, d) : o(ne, ie, K, e, t, d);
                        if (!(Je === i ? ne === ie || c(ne, ie, s, o, d) : Je)) {
                            ee = !1;
                            break
                        }
                        z || (z = K == "constructor")
                    }
                    if (ee && !z) {
                        var Ge = e.constructor,
                            et = t.constructor;
                        Ge != et && "constructor" in e && "constructor" in t && !(typeof Ge == "function" && Ge instanceof Ge && typeof et == "function" && et instanceof et) && (ee = !1)
                    }
                    return d.delete(e), d.delete(t), ee
                }

                function Ct(e) {
                    return Sa(Bl(e, i, ql), e + "")
                }

                function ga(e) {
                    return Vu(e, Oe, va)
                }

                function _a(e) {
                    return Vu(e, je, Pl)
                }
                var ma = yi ? function(e) {
                    return yi.get(e)
                } : Na;

                function Di(e) {
                    for (var t = e.name + "", s = kn[t], o = ue.call(kn, t) ? s.length : 0; o--;) {
                        var c = s[o],
                            d = c.func;
                        if (d == null || d == e) return c.name
                    }
                    return t
                }

                function Gn(e) {
                    var t = ue.call(h, "placeholder") ? h : e;
                    return t.placeholder
                }

                function Y() {
                    var e = h.iteratee || Ma;
                    return e = e === Ma ? Zu : e, arguments.length ? e(arguments[0], arguments[1]) : e
                }

                function Li(e, t) {
                    var s = e.__data__;
                    return hg(t) ? s[typeof t == "string" ? "string" : "hash"] : s.map
                }

                function ya(e) {
                    for (var t = Oe(e), s = t.length; s--;) {
                        var o = t[s],
                            c = e[o];
                        t[s] = [o, c, Ll(c)]
                    }
                    return t
                }

                function mn(e, t) {
                    var s = gd(e, t);
                    return Qu(s) ? s : i
                }

                function sg(e) {
                    var t = ue.call(e, hn),
                        s = e[hn];
                    try {
                        e[hn] = i;
                        var o = !0
                    } catch (d) {}
                    var c = ci.call(e);
                    return o && (t ? e[hn] = s : delete e[hn]), c
                }
                var va = Ys ? function(e) {
                        return e == null ? [] : (e = le(e), jt(Ys(e), function(t) {
                            return Nu.call(e, t)
                        }))
                    } : Fa,
                    Pl = Ys ? function(e) {
                        for (var t = []; e;) zt(t, va(e)), e = di(e);
                        return t
                    } : Fa,
                    Fe = Ke;
                (js && Fe(new js(new ArrayBuffer(1))) != Pn || dr && Fe(new dr) != ht || zs && Fe(zs.resolve()) != Yo || Fn && Fe(new Fn) != dt || pr && Fe(new pr) != lr) && (Fe = function(e) {
                    var t = Ke(e),
                        s = t == xt ? e.constructor : i,
                        o = s ? yn(s) : "";
                    if (o) switch (o) {
                        case Wd:
                            return Pn;
                        case Gd:
                            return ht;
                        case Hd:
                            return Yo;
                        case qd:
                            return dt;
                        case $d:
                            return lr
                    }
                    return t
                });

                function ag(e, t, s) {
                    for (var o = -1, c = s.length; ++o < c;) {
                        var d = s[o],
                            _ = d.size;
                        switch (d.type) {
                            case "drop":
                                e += _;
                                break;
                            case "dropRight":
                                t -= _;
                                break;
                            case "take":
                                t = Ne(t, e + _);
                                break;
                            case "takeRight":
                                e = xe(e, t - _);
                                break
                        }
                    }
                    return {
                        start: e,
                        end: t
                    }
                }

                function og(e) {
                    var t = e.match(dh);
                    return t ? t[1].split(ph) : []
                }

                function Cl(e, t, s) {
                    t = Jt(t, e);
                    for (var o = -1, c = t.length, d = !1; ++o < c;) {
                        var _ = St(t[o]);
                        if (!(d = e != null && s(e, _))) break;
                        e = e[_]
                    }
                    return d || ++o != c ? d : (c = e == null ? 0 : e.length, !!c && Ki(c) && Dt(_, c) && (Q(e) || vn(e)))
                }

                function ug(e) {
                    var t = e.length,
                        s = new e.constructor(t);
                    return t && typeof e[0] == "string" && ue.call(e, "index") && (s.index = e.index, s.input = e.input), s
                }

                function Dl(e) {
                    return typeof e.constructor == "function" && !Sr(e) ? Un(di(e)) : {}
                }

                function lg(e, t, s) {
                    var o = e.constructor;
                    switch (t) {
                        case cr:
                            return ha(e);
                        case ir:
                        case sr:
                            return new o(+e);
                        case Pn:
                            return Yp(e, s);
                        case ys:
                        case vs:
                        case ws:
                        case bs:
                        case Es:
                        case Ss:
                        case Ts:
                        case As:
                        case xs:
                            return pl(e, s);
                        case ht:
                            return new o;
                        case ar:
                        case ur:
                            return new o(e);
                        case or:
                            return jp(e);
                        case dt:
                            return new o;
                        case ei:
                            return zp(e)
                    }
                }

                function cg(e, t) {
                    var s = t.length;
                    if (!s) return e;
                    var o = s - 1;
                    return t[o] = (s > 1 ? "& " : "") + t[o], t = t.join(s > 2 ? ", " : " "), e.replace(hh, `{
/* [wrapped with ` + t + `] */
`)
                }

                function fg(e) {
                    return Q(e) || vn(e) || !!(Fu && e && e[Fu])
                }

                function Dt(e, t) {
                    var s = typeof e;
                    return t = t == null ? Be : t, !!t && (s == "number" || s != "symbol" && Sh.test(e)) && e > -1 && e % 1 == 0 && e < t
                }

                function We(e, t, s) {
                    if (!ve(s)) return !1;
                    var o = typeof t;
                    return (o == "number" ? Ye(s) && Dt(t, s.length) : o == "string" && t in s) ? _t(s[t], e) : !1
                }

                function wa(e, t) {
                    if (Q(e)) return !1;
                    var s = typeof e;
                    return s == "number" || s == "symbol" || s == "boolean" || e == null || Ze(e) ? !0 : uh.test(e) || !oh.test(e) || t != null && e in le(t)
                }

                function hg(e) {
                    var t = typeof e;
                    return t == "string" || t == "number" || t == "symbol" || t == "boolean" ? e !== "__proto__" : e === null
                }

                function ba(e) {
                    var t = Di(e),
                        s = h[t];
                    if (typeof s != "function" || !(t in re.prototype)) return !1;
                    if (e === s) return !0;
                    var o = ma(s);
                    return !!o && e === o[0]
                }

                function dg(e) {
                    return !!Lu && Lu in e
                }
                var pg = ui ? Lt : ka;

                function Sr(e) {
                    var t = e && e.constructor,
                        s = typeof t == "function" && t.prototype || Nn;
                    return e === s
                }

                function Ll(e) {
                    return e === e && !ve(e)
                }

                function Ml(e, t) {
                    return function(s) {
                        return s == null ? !1 : s[e] === t && (t !== i || e in le(s))
                    }
                }

                function gg(e) {
                    var t = ki(e, function(o) {
                            return s.size === E && s.clear(), o
                        }),
                        s = t.cache;
                    return t
                }

                function _g(e, t) {
                    var s = e[1],
                        o = t[1],
                        c = s | o,
                        d = c < (L | O | B),
                        _ = o == B && s == N || o == B && s == Z && e[7].length <= t[8] || o == (B | Z) && t[7].length <= t[8] && s == N;
                    if (!(d || _)) return e;
                    o & L && (e[2] = t[2], c |= s & L ? 0 : R);
                    var m = t[3];
                    if (m) {
                        var w = e[3];
                        e[3] = w ? _l(w, m, t[4]) : m, e[4] = w ? Vt(e[3], v) : t[4]
                    }
                    return m = t[5], m && (w = e[5], e[5] = w ? ml(w, m, t[6]) : m, e[6] = w ? Vt(e[5], v) : t[6]), m = t[7], m && (e[7] = m), o & B && (e[8] = e[8] == null ? t[8] : Ne(e[8], t[8])), e[9] == null && (e[9] = t[9]), e[0] = t[0], e[1] = c, e
                }

                function mg(e) {
                    var t = [];
                    if (e != null)
                        for (var s in le(e)) t.push(s);
                    return t
                }

                function yg(e) {
                    return ci.call(e)
                }

                function Bl(e, t, s) {
                    return t = xe(t === i ? e.length - 1 : t, 0),
                        function() {
                            for (var o = arguments, c = -1, d = xe(o.length - t, 0), _ = T(d); ++c < d;) _[c] = o[t + c];
                            c = -1;
                            for (var m = T(t + 1); ++c < t;) m[c] = o[c];
                            return m[t] = s(_), Ve(e, this, m)
                        }
                }

                function Nl(e, t) {
                    return t.length < 2 ? e : _n(e, lt(t, 0, -1))
                }

                function vg(e, t) {
                    for (var s = e.length, o = Ne(t.length, s), c = $e(e); o--;) {
                        var d = t[o];
                        e[o] = Dt(d, s) ? c[d] : i
                    }
                    return e
                }

                function Ea(e, t) {
                    if (!(t === "constructor" && typeof e[t] == "function") && t != "__proto__") return e[t]
                }
                var Fl = Ul(al),
                    Tr = Md || function(e, t) {
                        return De.setTimeout(e, t)
                    },
                    Sa = Ul(Gp);

                function kl(e, t, s) {
                    var o = t + "";
                    return Sa(e, cg(o, wg(og(o), s)))
                }

                function Ul(e) {
                    var t = 0,
                        s = 0;
                    return function() {
                        var o = kd(),
                            c = Re - (o - s);
                        if (s = o, c > 0) {
                            if (++t >= Ce) return arguments[0]
                        } else t = 0;
                        return e.apply(i, arguments)
                    }
                }

                function Mi(e, t) {
                    var s = -1,
                        o = e.length,
                        c = o - 1;
                    for (t = t === i ? o : t; ++s < t;) {
                        var d = sa(s, c),
                            _ = e[d];
                        e[d] = e[s], e[s] = _
                    }
                    return e.length = t, e
                }
                var Kl = gg(function(e) {
                    var t = [];
                    return e.charCodeAt(0) === 46 && t.push(""), e.replace(lh, function(s, o, c, d) {
                        t.push(c ? d.replace(mh, "$1") : o || s)
                    }), t
                });

                function St(e) {
                    if (typeof e == "string" || Ze(e)) return e;
                    var t = e + "";
                    return t == "0" && 1 / e == -we ? "-0" : t
                }

                function yn(e) {
                    if (e != null) {
                        try {
                            return li.call(e)
                        } catch (t) {}
                        try {
                            return e + ""
                        } catch (t) {}
                    }
                    return ""
                }

                function wg(e, t) {
                    return st(jf, function(s) {
                        var o = "_." + s[0];
                        t & s[1] && !ii(e, o) && e.push(o)
                    }), e.sort()
                }

                function Wl(e) {
                    if (e instanceof re) return e.clone();
                    var t = new ot(e.__wrapped__, e.__chain__);
                    return t.__actions__ = $e(e.__actions__), t.__index__ = e.__index__, t.__values__ = e.__values__, t
                }

                function bg(e, t, s) {
                    (s ? We(e, t, s) : t === i) ? t = 1: t = xe(J(t), 0);
                    var o = e == null ? 0 : e.length;
                    if (!o || t < 1) return [];
                    for (var c = 0, d = 0, _ = T(_i(o / t)); c < o;) _[d++] = lt(e, c, c += t);
                    return _
                }

                function Eg(e) {
                    for (var t = -1, s = e == null ? 0 : e.length, o = 0, c = []; ++t < s;) {
                        var d = e[t];
                        d && (c[o++] = d)
                    }
                    return c
                }

                function Sg() {
                    var e = arguments.length;
                    if (!e) return [];
                    for (var t = T(e - 1), s = arguments[0], o = e; o--;) t[o - 1] = arguments[o];
                    return zt(Q(s) ? $e(s) : [s], Le(t, 1))
                }
                var Tg = te(function(e, t) {
                        return Ee(e) ? yr(e, Le(t, 1, Ee, !0)) : []
                    }),
                    Ag = te(function(e, t) {
                        var s = ct(t);
                        return Ee(s) && (s = i), Ee(e) ? yr(e, Le(t, 1, Ee, !0), Y(s, 2)) : []
                    }),
                    xg = te(function(e, t) {
                        var s = ct(t);
                        return Ee(s) && (s = i), Ee(e) ? yr(e, Le(t, 1, Ee, !0), i, s) : []
                    });

                function Ig(e, t, s) {
                    var o = e == null ? 0 : e.length;
                    return o ? (t = s || t === i ? 1 : J(t), lt(e, t < 0 ? 0 : t, o)) : []
                }

                function Rg(e, t, s) {
                    var o = e == null ? 0 : e.length;
                    return o ? (t = s || t === i ? 1 : J(t), t = o - t, lt(e, 0, t < 0 ? 0 : t)) : []
                }

                function Og(e, t) {
                    return e && e.length ? xi(e, Y(t, 3), !0, !0) : []
                }

                function Pg(e, t) {
                    return e && e.length ? xi(e, Y(t, 3), !0) : []
                }

                function Cg(e, t, s, o) {
                    var c = e == null ? 0 : e.length;
                    return c ? (s && typeof s != "number" && We(e, t, s) && (s = 0, o = c), Sp(e, t, s, o)) : []
                }

                function Gl(e, t, s) {
                    var o = e == null ? 0 : e.length;
                    if (!o) return -1;
                    var c = s == null ? 0 : J(s);
                    return c < 0 && (c = xe(o + c, 0)), si(e, Y(t, 3), c)
                }

                function Hl(e, t, s) {
                    var o = e == null ? 0 : e.length;
                    if (!o) return -1;
                    var c = o - 1;
                    return s !== i && (c = J(s), c = s < 0 ? xe(o + c, 0) : Ne(c, o - 1)), si(e, Y(t, 3), c, !0)
                }

                function ql(e) {
                    var t = e == null ? 0 : e.length;
                    return t ? Le(e, 1) : []
                }

                function Dg(e) {
                    var t = e == null ? 0 : e.length;
                    return t ? Le(e, we) : []
                }

                function Lg(e, t) {
                    var s = e == null ? 0 : e.length;
                    return s ? (t = t === i ? 1 : J(t), Le(e, t)) : []
                }

                function Mg(e) {
                    for (var t = -1, s = e == null ? 0 : e.length, o = {}; ++t < s;) {
                        var c = e[t];
                        o[c[0]] = c[1]
                    }
                    return o
                }

                function $l(e) {
                    return e && e.length ? e[0] : i
                }

                function Bg(e, t, s) {
                    var o = e == null ? 0 : e.length;
                    if (!o) return -1;
                    var c = s == null ? 0 : J(s);
                    return c < 0 && (c = xe(o + c, 0)), Dn(e, t, c)
                }

                function Ng(e) {
                    var t = e == null ? 0 : e.length;
                    return t ? lt(e, 0, -1) : []
                }
                var Fg = te(function(e) {
                        var t = me(e, ca);
                        return t.length && t[0] === e[0] ? ea(t) : []
                    }),
                    kg = te(function(e) {
                        var t = ct(e),
                            s = me(e, ca);
                        return t === ct(s) ? t = i : s.pop(), s.length && s[0] === e[0] ? ea(s, Y(t, 2)) : []
                    }),
                    Ug = te(function(e) {
                        var t = ct(e),
                            s = me(e, ca);
                        return t = typeof t == "function" ? t : i, t && s.pop(), s.length && s[0] === e[0] ? ea(s, i, t) : []
                    });

                function Kg(e, t) {
                    return e == null ? "" : Nd.call(e, t)
                }

                function ct(e) {
                    var t = e == null ? 0 : e.length;
                    return t ? e[t - 1] : i
                }

                function Wg(e, t, s) {
                    var o = e == null ? 0 : e.length;
                    if (!o) return -1;
                    var c = o;
                    return s !== i && (c = J(s), c = c < 0 ? xe(o + c, 0) : Ne(c, o - 1)), t === t ? wd(e, t, c) : si(e, Au, c, !0)
                }

                function Gg(e, t) {
                    return e && e.length ? nl(e, J(t)) : i
                }
                var Hg = te(Yl);

                function Yl(e, t) {
                    return e && e.length && t && t.length ? ia(e, t) : e
                }

                function qg(e, t, s) {
                    return e && e.length && t && t.length ? ia(e, t, Y(s, 2)) : e
                }

                function $g(e, t, s) {
                    return e && e.length && t && t.length ? ia(e, t, i, s) : e
                }
                var Yg = Ct(function(e, t) {
                    var s = e == null ? 0 : e.length,
                        o = Xs(e, t);
                    return sl(e, me(t, function(c) {
                        return Dt(c, s) ? +c : c
                    }).sort(gl)), o
                });

                function jg(e, t) {
                    var s = [];
                    if (!(e && e.length)) return s;
                    var o = -1,
                        c = [],
                        d = e.length;
                    for (t = Y(t, 3); ++o < d;) {
                        var _ = e[o];
                        t(_, o, e) && (s.push(_), c.push(o))
                    }
                    return sl(e, c), s
                }

                function Ta(e) {
                    return e == null ? e : Kd.call(e)
                }

                function zg(e, t, s) {
                    var o = e == null ? 0 : e.length;
                    return o ? (s && typeof s != "number" && We(e, t, s) ? (t = 0, s = o) : (t = t == null ? 0 : J(t), s = s === i ? o : J(s)), lt(e, t, s)) : []
                }

                function Vg(e, t) {
                    return Ai(e, t)
                }

                function Xg(e, t, s) {
                    return oa(e, t, Y(s, 2))
                }

                function Qg(e, t) {
                    var s = e == null ? 0 : e.length;
                    if (s) {
                        var o = Ai(e, t);
                        if (o < s && _t(e[o], t)) return o
                    }
                    return -1
                }

                function Zg(e, t) {
                    return Ai(e, t, !0)
                }

                function Jg(e, t, s) {
                    return oa(e, t, Y(s, 2), !0)
                }

                function e_(e, t) {
                    var s = e == null ? 0 : e.length;
                    if (s) {
                        var o = Ai(e, t, !0) - 1;
                        if (_t(e[o], t)) return o
                    }
                    return -1
                }

                function t_(e) {
                    return e && e.length ? ol(e) : []
                }

                function n_(e, t) {
                    return e && e.length ? ol(e, Y(t, 2)) : []
                }

                function r_(e) {
                    var t = e == null ? 0 : e.length;
                    return t ? lt(e, 1, t) : []
                }

                function i_(e, t, s) {
                    return e && e.length ? (t = s || t === i ? 1 : J(t), lt(e, 0, t < 0 ? 0 : t)) : []
                }

                function s_(e, t, s) {
                    var o = e == null ? 0 : e.length;
                    return o ? (t = s || t === i ? 1 : J(t), t = o - t, lt(e, t < 0 ? 0 : t, o)) : []
                }

                function a_(e, t) {
                    return e && e.length ? xi(e, Y(t, 3), !1, !0) : []
                }

                function o_(e, t) {
                    return e && e.length ? xi(e, Y(t, 3)) : []
                }
                var u_ = te(function(e) {
                        return Zt(Le(e, 1, Ee, !0))
                    }),
                    l_ = te(function(e) {
                        var t = ct(e);
                        return Ee(t) && (t = i), Zt(Le(e, 1, Ee, !0), Y(t, 2))
                    }),
                    c_ = te(function(e) {
                        var t = ct(e);
                        return t = typeof t == "function" ? t : i, Zt(Le(e, 1, Ee, !0), i, t)
                    });

                function f_(e) {
                    return e && e.length ? Zt(e) : []
                }

                function h_(e, t) {
                    return e && e.length ? Zt(e, Y(t, 2)) : []
                }

                function d_(e, t) {
                    return t = typeof t == "function" ? t : i, e && e.length ? Zt(e, i, t) : []
                }

                function Aa(e) {
                    if (!(e && e.length)) return [];
                    var t = 0;
                    return e = jt(e, function(s) {
                        if (Ee(s)) return t = xe(s.length, t), !0
                    }), Gs(t, function(s) {
                        return me(e, Us(s))
                    })
                }

                function jl(e, t) {
                    if (!(e && e.length)) return [];
                    var s = Aa(e);
                    return t == null ? s : me(s, function(o) {
                        return Ve(t, i, o)
                    })
                }
                var p_ = te(function(e, t) {
                        return Ee(e) ? yr(e, t) : []
                    }),
                    g_ = te(function(e) {
                        return la(jt(e, Ee))
                    }),
                    __ = te(function(e) {
                        var t = ct(e);
                        return Ee(t) && (t = i), la(jt(e, Ee), Y(t, 2))
                    }),
                    m_ = te(function(e) {
                        var t = ct(e);
                        return t = typeof t == "function" ? t : i, la(jt(e, Ee), i, t)
                    }),
                    y_ = te(Aa);

                function v_(e, t) {
                    return fl(e || [], t || [], mr)
                }

                function w_(e, t) {
                    return fl(e || [], t || [], br)
                }
                var b_ = te(function(e) {
                    var t = e.length,
                        s = t > 1 ? e[t - 1] : i;
                    return s = typeof s == "function" ? (e.pop(), s) : i, jl(e, s)
                });

                function zl(e) {
                    var t = h(e);
                    return t.__chain__ = !0, t
                }

                function E_(e, t) {
                    return t(e), e
                }

                function Bi(e, t) {
                    return t(e)
                }
                var S_ = Ct(function(e) {
                    var t = e.length,
                        s = t ? e[0] : 0,
                        o = this.__wrapped__,
                        c = function(d) {
                            return Xs(d, e)
                        };
                    return t > 1 || this.__actions__.length || !(o instanceof re) || !Dt(s) ? this.thru(c) : (o = o.slice(s, +s + (t ? 1 : 0)), o.__actions__.push({
                        func: Bi,
                        args: [c],
                        thisArg: i
                    }), new ot(o, this.__chain__).thru(function(d) {
                        return t && !d.length && d.push(i), d
                    }))
                });

                function T_() {
                    return zl(this)
                }

                function A_() {
                    return new ot(this.value(), this.__chain__)
                }

                function x_() {
                    this.__values__ === i && (this.__values__ = uc(this.value()));
                    var e = this.__index__ >= this.__values__.length,
                        t = e ? i : this.__values__[this.__index__++];
                    return {
                        done: e,
                        value: t
                    }
                }

                function I_() {
                    return this
                }

                function R_(e) {
                    for (var t, s = this; s instanceof wi;) {
                        var o = Wl(s);
                        o.__index__ = 0, o.__values__ = i, t ? c.__wrapped__ = o : t = o;
                        var c = o;
                        s = s.__wrapped__
                    }
                    return c.__wrapped__ = e, t
                }

                function O_() {
                    var e = this.__wrapped__;
                    if (e instanceof re) {
                        var t = e;
                        return this.__actions__.length && (t = new re(this)), t = t.reverse(), t.__actions__.push({
                            func: Bi,
                            args: [Ta],
                            thisArg: i
                        }), new ot(t, this.__chain__)
                    }
                    return this.thru(Ta)
                }

                function P_() {
                    return cl(this.__wrapped__, this.__actions__)
                }
                var C_ = Ii(function(e, t, s) {
                    ue.call(e, s) ? ++e[s] : Ot(e, s, 1)
                });

                function D_(e, t, s) {
                    var o = Q(e) ? Su : Ep;
                    return s && We(e, t, s) && (t = i), o(e, Y(t, 3))
                }

                function L_(e, t) {
                    var s = Q(e) ? jt : ju;
                    return s(e, Y(t, 3))
                }
                var M_ = bl(Gl),
                    B_ = bl(Hl);

                function N_(e, t) {
                    return Le(Ni(e, t), 1)
                }

                function F_(e, t) {
                    return Le(Ni(e, t), we)
                }

                function k_(e, t, s) {
                    return s = s === i ? 1 : J(s), Le(Ni(e, t), s)
                }

                function Vl(e, t) {
                    var s = Q(e) ? st : Qt;
                    return s(e, Y(t, 3))
                }

                function Xl(e, t) {
                    var s = Q(e) ? rd : Yu;
                    return s(e, Y(t, 3))
                }
                var U_ = Ii(function(e, t, s) {
                    ue.call(e, s) ? e[s].push(t) : Ot(e, s, [t])
                });

                function K_(e, t, s, o) {
                    e = Ye(e) ? e : qn(e), s = s && !o ? J(s) : 0;
                    var c = e.length;
                    return s < 0 && (s = xe(c + s, 0)), Wi(e) ? s <= c && e.indexOf(t, s) > -1 : !!c && Dn(e, t, s) > -1
                }
                var W_ = te(function(e, t, s) {
                        var o = -1,
                            c = typeof t == "function",
                            d = Ye(e) ? T(e.length) : [];
                        return Qt(e, function(_) {
                            d[++o] = c ? Ve(t, _, s) : vr(_, t, s)
                        }), d
                    }),
                    G_ = Ii(function(e, t, s) {
                        Ot(e, s, t)
                    });

                function Ni(e, t) {
                    var s = Q(e) ? me : Ju;
                    return s(e, Y(t, 3))
                }

                function H_(e, t, s, o) {
                    return e == null ? [] : (Q(t) || (t = t == null ? [] : [t]), s = o ? i : s, Q(s) || (s = s == null ? [] : [s]), rl(e, t, s))
                }
                var q_ = Ii(function(e, t, s) {
                    e[s ? 0 : 1].push(t)
                }, function() {
                    return [
                        [],
                        []
                    ]
                });

                function $_(e, t, s) {
                    var o = Q(e) ? Fs : Iu,
                        c = arguments.length < 3;
                    return o(e, Y(t, 4), s, c, Qt)
                }

                function Y_(e, t, s) {
                    var o = Q(e) ? id : Iu,
                        c = arguments.length < 3;
                    return o(e, Y(t, 4), s, c, Yu)
                }

                function j_(e, t) {
                    var s = Q(e) ? jt : ju;
                    return s(e, Ui(Y(t, 3)))
                }

                function z_(e) {
                    var t = Q(e) ? Gu : Kp;
                    return t(e)
                }

                function V_(e, t, s) {
                    (s ? We(e, t, s) : t === i) ? t = 1: t = J(t);
                    var o = Q(e) ? mp : Wp;
                    return o(e, t)
                }

                function X_(e) {
                    var t = Q(e) ? yp : Hp;
                    return t(e)
                }

                function Q_(e) {
                    if (e == null) return 0;
                    if (Ye(e)) return Wi(e) ? Mn(e) : e.length;
                    var t = Fe(e);
                    return t == ht || t == dt ? e.size : na(e).length
                }

                function Z_(e, t, s) {
                    var o = Q(e) ? ks : qp;
                    return s && We(e, t, s) && (t = i), o(e, Y(t, 3))
                }
                var J_ = te(function(e, t) {
                        if (e == null) return [];
                        var s = t.length;
                        return s > 1 && We(e, t[0], t[1]) ? t = [] : s > 2 && We(t[0], t[1], t[2]) && (t = [t[0]]), rl(e, Le(t, 1), [])
                    }),
                    Fi = Ld || function() {
                        return De.Date.now()
                    };

                function em(e, t) {
                    if (typeof t != "function") throw new at(f);
                    return e = J(e),
                        function() {
                            if (--e < 1) return t.apply(this, arguments)
                        }
                }

                function Ql(e, t, s) {
                    return t = s ? i : t, t = e && t == null ? e.length : t, Pt(e, B, i, i, i, i, t)
                }

                function Zl(e, t) {
                    var s;
                    if (typeof t != "function") throw new at(f);
                    return e = J(e),
                        function() {
                            return --e > 0 && (s = t.apply(this, arguments)), e <= 1 && (t = i), s
                        }
                }
                var xa = te(function(e, t, s) {
                        var o = L;
                        if (s.length) {
                            var c = Vt(s, Gn(xa));
                            o |= F
                        }
                        return Pt(e, o, t, s, c)
                    }),
                    Jl = te(function(e, t, s) {
                        var o = L | O;
                        if (s.length) {
                            var c = Vt(s, Gn(Jl));
                            o |= F
                        }
                        return Pt(t, o, e, s, c)
                    });

                function ec(e, t, s) {
                    t = s ? i : t;
                    var o = Pt(e, N, i, i, i, i, i, t);
                    return o.placeholder = ec.placeholder, o
                }

                function tc(e, t, s) {
                    t = s ? i : t;
                    var o = Pt(e, W, i, i, i, i, i, t);
                    return o.placeholder = tc.placeholder, o
                }

                function nc(e, t, s) {
                    var o, c, d, _, m, w, P = 0,
                        C = !1,
                        D = !1,
                        K = !0;
                    if (typeof e != "function") throw new at(f);
                    t = ft(t) || 0, ve(s) && (C = !!s.leading, D = "maxWait" in s, d = D ? xe(ft(s.maxWait) || 0, t) : d, K = "trailing" in s ? !!s.trailing : K);

                    function q(Se) {
                        var mt = o,
                            Bt = c;
                        return o = c = i, P = Se, _ = e.apply(Bt, mt), _
                    }

                    function j(Se) {
                        return P = Se, m = Tr(ne, t), C ? q(Se) : _
                    }

                    function ee(Se) {
                        var mt = Se - w,
                            Bt = Se - P,
                            bc = t - mt;
                        return D ? Ne(bc, d - Bt) : bc
                    }

                    function z(Se) {
                        var mt = Se - w,
                            Bt = Se - P;
                        return w === i || mt >= t || mt < 0 || D && Bt >= d
                    }

                    function ne() {
                        var Se = Fi();
                        if (z(Se)) return ie(Se);
                        m = Tr(ne, ee(Se))
                    }

                    function ie(Se) {
                        return m = i, K && o ? q(Se) : (o = c = i, _)
                    }

                    function Je() {
                        m !== i && hl(m), P = 0, o = w = c = m = i
                    }

                    function Ge() {
                        return m === i ? _ : ie(Fi())
                    }

                    function et() {
                        var Se = Fi(),
                            mt = z(Se);
                        if (o = arguments, c = this, w = Se, mt) {
                            if (m === i) return j(w);
                            if (D) return hl(m), m = Tr(ne, t), q(w)
                        }
                        return m === i && (m = Tr(ne, t)), _
                    }
                    return et.cancel = Je, et.flush = Ge, et
                }
                var tm = te(function(e, t) {
                        return $u(e, 1, t)
                    }),
                    nm = te(function(e, t, s) {
                        return $u(e, ft(t) || 0, s)
                    });

                function rm(e) {
                    return Pt(e, U)
                }

                function ki(e, t) {
                    if (typeof e != "function" || t != null && typeof t != "function") throw new at(f);
                    var s = function() {
                        var o = arguments,
                            c = t ? t.apply(this, o) : o[0],
                            d = s.cache;
                        if (d.has(c)) return d.get(c);
                        var _ = e.apply(this, o);
                        return s.cache = d.set(c, _) || d, _
                    };
                    return s.cache = new(ki.Cache || Rt), s
                }
                ki.Cache = Rt;

                function Ui(e) {
                    if (typeof e != "function") throw new at(f);
                    return function() {
                        var t = arguments;
                        switch (t.length) {
                            case 0:
                                return !e.call(this);
                            case 1:
                                return !e.call(this, t[0]);
                            case 2:
                                return !e.call(this, t[0], t[1]);
                            case 3:
                                return !e.call(this, t[0], t[1], t[2])
                        }
                        return !e.apply(this, t)
                    }
                }

                function im(e) {
                    return Zl(2, e)
                }
                var sm = $p(function(e, t) {
                        t = t.length == 1 && Q(t[0]) ? me(t[0], Xe(Y())) : me(Le(t, 1), Xe(Y()));
                        var s = t.length;
                        return te(function(o) {
                            for (var c = -1, d = Ne(o.length, s); ++c < d;) o[c] = t[c].call(this, o[c]);
                            return Ve(e, this, o)
                        })
                    }),
                    Ia = te(function(e, t) {
                        var s = Vt(t, Gn(Ia));
                        return Pt(e, F, i, t, s)
                    }),
                    rc = te(function(e, t) {
                        var s = Vt(t, Gn(rc));
                        return Pt(e, k, i, t, s)
                    }),
                    am = Ct(function(e, t) {
                        return Pt(e, Z, i, i, i, t)
                    });

                function om(e, t) {
                    if (typeof e != "function") throw new at(f);
                    return t = t === i ? t : J(t), te(e, t)
                }

                function um(e, t) {
                    if (typeof e != "function") throw new at(f);
                    return t = t == null ? 0 : xe(J(t), 0), te(function(s) {
                        var o = s[t],
                            c = en(s, 0, t);
                        return o && zt(c, o), Ve(e, this, c)
                    })
                }

                function lm(e, t, s) {
                    var o = !0,
                        c = !0;
                    if (typeof e != "function") throw new at(f);
                    return ve(s) && (o = "leading" in s ? !!s.leading : o, c = "trailing" in s ? !!s.trailing : c), nc(e, t, {
                        leading: o,
                        maxWait: t,
                        trailing: c
                    })
                }

                function cm(e) {
                    return Ql(e, 1)
                }

                function fm(e, t) {
                    return Ia(fa(t), e)
                }

                function hm() {
                    if (!arguments.length) return [];
                    var e = arguments[0];
                    return Q(e) ? e : [e]
                }

                function dm(e) {
                    return ut(e, A)
                }

                function pm(e, t) {
                    return t = typeof t == "function" ? t : i, ut(e, A, t)
                }

                function gm(e) {
                    return ut(e, S | A)
                }

                function _m(e, t) {
                    return t = typeof t == "function" ? t : i, ut(e, S | A, t)
                }

                function mm(e, t) {
                    return t == null || qu(e, t, Oe(t))
                }

                function _t(e, t) {
                    return e === t || e !== e && t !== t
                }
                var ym = Ci(Js),
                    vm = Ci(function(e, t) {
                        return e >= t
                    }),
                    vn = Xu(function() {
                        return arguments
                    }()) ? Xu : function(e) {
                        return be(e) && ue.call(e, "callee") && !Nu.call(e, "callee")
                    },
                    Q = T.isArray,
                    wm = mu ? Xe(mu) : Rp;

                function Ye(e) {
                    return e != null && Ki(e.length) && !Lt(e)
                }

                function Ee(e) {
                    return be(e) && Ye(e)
                }

                function bm(e) {
                    return e === !0 || e === !1 || be(e) && Ke(e) == ir
                }
                var tn = Bd || ka,
                    Em = yu ? Xe(yu) : Op;

                function Sm(e) {
                    return be(e) && e.nodeType === 1 && !Ar(e)
                }

                function Tm(e) {
                    if (e == null) return !0;
                    if (Ye(e) && (Q(e) || typeof e == "string" || typeof e.splice == "function" || tn(e) || Hn(e) || vn(e))) return !e.length;
                    var t = Fe(e);
                    if (t == ht || t == dt) return !e.size;
                    if (Sr(e)) return !na(e).length;
                    for (var s in e)
                        if (ue.call(e, s)) return !1;
                    return !0
                }

                function Am(e, t) {
                    return wr(e, t)
                }

                function xm(e, t, s) {
                    s = typeof s == "function" ? s : i;
                    var o = s ? s(e, t) : i;
                    return o === i ? wr(e, t, i, s) : !!o
                }

                function Ra(e) {
                    if (!be(e)) return !1;
                    var t = Ke(e);
                    return t == Zr || t == Vf || typeof e.message == "string" && typeof e.name == "string" && !Ar(e)
                }

                function Im(e) {
                    return typeof e == "number" && ku(e)
                }

                function Lt(e) {
                    if (!ve(e)) return !1;
                    var t = Ke(e);
                    return t == Jr || t == $o || t == zf || t == Qf
                }

                function ic(e) {
                    return typeof e == "number" && e == J(e)
                }

                function Ki(e) {
                    return typeof e == "number" && e > -1 && e % 1 == 0 && e <= Be
                }

                function ve(e) {
                    var t = typeof e;
                    return e != null && (t == "object" || t == "function")
                }

                function be(e) {
                    return e != null && typeof e == "object"
                }
                var sc = vu ? Xe(vu) : Cp;

                function Rm(e, t) {
                    return e === t || ta(e, t, ya(t))
                }

                function Om(e, t, s) {
                    return s = typeof s == "function" ? s : i, ta(e, t, ya(t), s)
                }

                function Pm(e) {
                    return ac(e) && e != +e
                }

                function Cm(e) {
                    if (pg(e)) throw new X(l);
                    return Qu(e)
                }

                function Dm(e) {
                    return e === null
                }

                function Lm(e) {
                    return e == null
                }

                function ac(e) {
                    return typeof e == "number" || be(e) && Ke(e) == ar
                }

                function Ar(e) {
                    if (!be(e) || Ke(e) != xt) return !1;
                    var t = di(e);
                    if (t === null) return !0;
                    var s = ue.call(t, "constructor") && t.constructor;
                    return typeof s == "function" && s instanceof s && li.call(s) == Od
                }
                var Oa = wu ? Xe(wu) : Dp;

                function Mm(e) {
                    return ic(e) && e >= -Be && e <= Be
                }
                var oc = bu ? Xe(bu) : Lp;

                function Wi(e) {
                    return typeof e == "string" || !Q(e) && be(e) && Ke(e) == ur
                }

                function Ze(e) {
                    return typeof e == "symbol" || be(e) && Ke(e) == ei
                }
                var Hn = Eu ? Xe(Eu) : Mp;

                function Bm(e) {
                    return e === i
                }

                function Nm(e) {
                    return be(e) && Fe(e) == lr
                }

                function Fm(e) {
                    return be(e) && Ke(e) == Jf
                }
                var km = Ci(ra),
                    Um = Ci(function(e, t) {
                        return e <= t
                    });

                function uc(e) {
                    if (!e) return [];
                    if (Ye(e)) return Wi(e) ? pt(e) : $e(e);
                    if (hr && e[hr]) return md(e[hr]());
                    var t = Fe(e),
                        s = t == ht ? qs : t == dt ? ai : qn;
                    return s(e)
                }

                function Mt(e) {
                    if (!e) return e === 0 ? e : 0;
                    if (e = ft(e), e === we || e === -we) {
                        var t = e < 0 ? -1 : 1;
                        return t * cn
                    }
                    return e === e ? e : 0
                }

                function J(e) {
                    var t = Mt(e),
                        s = t % 1;
                    return t === t ? s ? t - s : t : 0
                }

                function lc(e) {
                    return e ? gn(J(e), 0, wt) : 0
                }

                function ft(e) {
                    if (typeof e == "number") return e;
                    if (Ze(e)) return Yt;
                    if (ve(e)) {
                        var t = typeof e.valueOf == "function" ? e.valueOf() : e;
                        e = ve(t) ? t + "" : t
                    }
                    if (typeof e != "string") return e === 0 ? e : +e;
                    e = Ru(e);
                    var s = wh.test(e);
                    return s || Eh.test(e) ? ed(e.slice(2), s ? 2 : 8) : vh.test(e) ? Yt : +e
                }

                function cc(e) {
                    return Et(e, je(e))
                }

                function Km(e) {
                    return e ? gn(J(e), -Be, Be) : e === 0 ? e : 0
                }

                function oe(e) {
                    return e == null ? "" : Qe(e)
                }
                var Wm = Kn(function(e, t) {
                        if (Sr(t) || Ye(t)) {
                            Et(t, Oe(t), e);
                            return
                        }
                        for (var s in t) ue.call(t, s) && mr(e, s, t[s])
                    }),
                    fc = Kn(function(e, t) {
                        Et(t, je(t), e)
                    }),
                    Gi = Kn(function(e, t, s, o) {
                        Et(t, je(t), e, o)
                    }),
                    Gm = Kn(function(e, t, s, o) {
                        Et(t, Oe(t), e, o)
                    }),
                    Hm = Ct(Xs);

                function qm(e, t) {
                    var s = Un(e);
                    return t == null ? s : Hu(s, t)
                }
                var $m = te(function(e, t) {
                        e = le(e);
                        var s = -1,
                            o = t.length,
                            c = o > 2 ? t[2] : i;
                        for (c && We(t[0], t[1], c) && (o = 1); ++s < o;)
                            for (var d = t[s], _ = je(d), m = -1, w = _.length; ++m < w;) {
                                var P = _[m],
                                    C = e[P];
                                (C === i || _t(C, Nn[P]) && !ue.call(e, P)) && (e[P] = d[P])
                            }
                        return e
                    }),
                    Ym = te(function(e) {
                        return e.push(i, Rl), Ve(hc, i, e)
                    });

                function jm(e, t) {
                    return Tu(e, Y(t, 3), bt)
                }

                function zm(e, t) {
                    return Tu(e, Y(t, 3), Zs)
                }

                function Vm(e, t) {
                    return e == null ? e : Qs(e, Y(t, 3), je)
                }

                function Xm(e, t) {
                    return e == null ? e : zu(e, Y(t, 3), je)
                }

                function Qm(e, t) {
                    return e && bt(e, Y(t, 3))
                }

                function Zm(e, t) {
                    return e && Zs(e, Y(t, 3))
                }

                function Jm(e) {
                    return e == null ? [] : Si(e, Oe(e))
                }

                function ey(e) {
                    return e == null ? [] : Si(e, je(e))
                }

                function Pa(e, t, s) {
                    var o = e == null ? i : _n(e, t);
                    return o === i ? s : o
                }

                function ty(e, t) {
                    return e != null && Cl(e, t, Tp)
                }

                function Ca(e, t) {
                    return e != null && Cl(e, t, Ap)
                }
                var ny = Sl(function(e, t, s) {
                        t != null && typeof t.toString != "function" && (t = ci.call(t)), e[t] = s
                    }, La(ze)),
                    ry = Sl(function(e, t, s) {
                        t != null && typeof t.toString != "function" && (t = ci.call(t)), ue.call(e, t) ? e[t].push(s) : e[t] = [s]
                    }, Y),
                    iy = te(vr);

                function Oe(e) {
                    return Ye(e) ? Wu(e) : na(e)
                }

                function je(e) {
                    return Ye(e) ? Wu(e, !0) : Bp(e)
                }

                function sy(e, t) {
                    var s = {};
                    return t = Y(t, 3), bt(e, function(o, c, d) {
                        Ot(s, t(o, c, d), o)
                    }), s
                }

                function ay(e, t) {
                    var s = {};
                    return t = Y(t, 3), bt(e, function(o, c, d) {
                        Ot(s, c, t(o, c, d))
                    }), s
                }
                var oy = Kn(function(e, t, s) {
                        Ti(e, t, s)
                    }),
                    hc = Kn(function(e, t, s, o) {
                        Ti(e, t, s, o)
                    }),
                    uy = Ct(function(e, t) {
                        var s = {};
                        if (e == null) return s;
                        var o = !1;
                        t = me(t, function(d) {
                            return d = Jt(d, e), o || (o = d.length > 1), d
                        }), Et(e, _a(e), s), o && (s = ut(s, S | b | A, ng));
                        for (var c = t.length; c--;) ua(s, t[c]);
                        return s
                    });

                function ly(e, t) {
                    return dc(e, Ui(Y(t)))
                }
                var cy = Ct(function(e, t) {
                    return e == null ? {} : Fp(e, t)
                });

                function dc(e, t) {
                    if (e == null) return {};
                    var s = me(_a(e), function(o) {
                        return [o]
                    });
                    return t = Y(t), il(e, s, function(o, c) {
                        return t(o, c[0])
                    })
                }

                function fy(e, t, s) {
                    t = Jt(t, e);
                    var o = -1,
                        c = t.length;
                    for (c || (c = 1, e = i); ++o < c;) {
                        var d = e == null ? i : e[St(t[o])];
                        d === i && (o = c, d = s), e = Lt(d) ? d.call(e) : d
                    }
                    return e
                }

                function hy(e, t, s) {
                    return e == null ? e : br(e, t, s)
                }

                function dy(e, t, s, o) {
                    return o = typeof o == "function" ? o : i, e == null ? e : br(e, t, s, o)
                }
                var pc = xl(Oe),
                    gc = xl(je);

                function py(e, t, s) {
                    var o = Q(e),
                        c = o || tn(e) || Hn(e);
                    if (t = Y(t, 4), s == null) {
                        var d = e && e.constructor;
                        c ? s = o ? new d : [] : ve(e) ? s = Lt(d) ? Un(di(e)) : {} : s = {}
                    }
                    return (c ? st : bt)(e, function(_, m, w) {
                        return t(s, _, m, w)
                    }), s
                }

                function gy(e, t) {
                    return e == null ? !0 : ua(e, t)
                }

                function _y(e, t, s) {
                    return e == null ? e : ll(e, t, fa(s))
                }

                function my(e, t, s, o) {
                    return o = typeof o == "function" ? o : i, e == null ? e : ll(e, t, fa(s), o)
                }

                function qn(e) {
                    return e == null ? [] : Hs(e, Oe(e))
                }

                function yy(e) {
                    return e == null ? [] : Hs(e, je(e))
                }

                function vy(e, t, s) {
                    return s === i && (s = t, t = i), s !== i && (s = ft(s), s = s === s ? s : 0), t !== i && (t = ft(t), t = t === t ? t : 0), gn(ft(e), t, s)
                }

                function wy(e, t, s) {
                    return t = Mt(t), s === i ? (s = t, t = 0) : s = Mt(s), e = ft(e), xp(e, t, s)
                }

                function by(e, t, s) {
                    if (s && typeof s != "boolean" && We(e, t, s) && (t = s = i), s === i && (typeof t == "boolean" ? (s = t, t = i) : typeof e == "boolean" && (s = e, e = i)), e === i && t === i ? (e = 0, t = 1) : (e = Mt(e), t === i ? (t = e, e = 0) : t = Mt(t)), e > t) {
                        var o = e;
                        e = t, t = o
                    }
                    if (s || e % 1 || t % 1) {
                        var c = Uu();
                        return Ne(e + c * (t - e + Jh("1e-" + ((c + "").length - 1))), t)
                    }
                    return sa(e, t)
                }
                var Ey = Wn(function(e, t, s) {
                    return t = t.toLowerCase(), e + (s ? _c(t) : t)
                });

                function _c(e) {
                    return Da(oe(e).toLowerCase())
                }

                function mc(e) {
                    return e = oe(e), e && e.replace(Th, hd).replace(Hh, "")
                }

                function Sy(e, t, s) {
                    e = oe(e), t = Qe(t);
                    var o = e.length;
                    s = s === i ? o : gn(J(s), 0, o);
                    var c = s;
                    return s -= t.length, s >= 0 && e.slice(s, c) == t
                }

                function Ty(e) {
                    return e = oe(e), e && ih.test(e) ? e.replace(zo, dd) : e
                }

                function Ay(e) {
                    return e = oe(e), e && ch.test(e) ? e.replace(Is, "\\$&") : e
                }
                var xy = Wn(function(e, t, s) {
                        return e + (s ? "-" : "") + t.toLowerCase()
                    }),
                    Iy = Wn(function(e, t, s) {
                        return e + (s ? " " : "") + t.toLowerCase()
                    }),
                    Ry = wl("toLowerCase");

                function Oy(e, t, s) {
                    e = oe(e), t = J(t);
                    var o = t ? Mn(e) : 0;
                    if (!t || o >= t) return e;
                    var c = (t - o) / 2;
                    return Pi(mi(c), s) + e + Pi(_i(c), s)
                }

                function Py(e, t, s) {
                    e = oe(e), t = J(t);
                    var o = t ? Mn(e) : 0;
                    return t && o < t ? e + Pi(t - o, s) : e
                }

                function Cy(e, t, s) {
                    e = oe(e), t = J(t);
                    var o = t ? Mn(e) : 0;
                    return t && o < t ? Pi(t - o, s) + e : e
                }

                function Dy(e, t, s) {
                    return s || t == null ? t = 0 : t && (t = +t), Ud(oe(e).replace(Rs, ""), t || 0)
                }

                function Ly(e, t, s) {
                    return (s ? We(e, t, s) : t === i) ? t = 1 : t = J(t), aa(oe(e), t)
                }

                function My() {
                    var e = arguments,
                        t = oe(e[0]);
                    return e.length < 3 ? t : t.replace(e[1], e[2])
                }
                var By = Wn(function(e, t, s) {
                    return e + (s ? "_" : "") + t.toLowerCase()
                });

                function Ny(e, t, s) {
                    return s && typeof s != "number" && We(e, t, s) && (t = s = i), s = s === i ? wt : s >>> 0, s ? (e = oe(e), e && (typeof t == "string" || t != null && !Oa(t)) && (t = Qe(t), !t && Ln(e)) ? en(pt(e), 0, s) : e.split(t, s)) : []
                }
                var Fy = Wn(function(e, t, s) {
                    return e + (s ? " " : "") + Da(t)
                });

                function ky(e, t, s) {
                    return e = oe(e), s = s == null ? 0 : gn(J(s), 0, e.length), t = Qe(t), e.slice(s, s + t.length) == t
                }

                function Uy(e, t, s) {
                    var o = h.templateSettings;
                    s && We(e, t, s) && (t = i), e = oe(e), t = Gi({}, t, o, Il);
                    var c = Gi({}, t.imports, o.imports, Il),
                        d = Oe(c),
                        _ = Hs(c, d),
                        m, w, P = 0,
                        C = t.interpolate || ti,
                        D = "__p += '",
                        K = $s((t.escape || ti).source + "|" + C.source + "|" + (C === Vo ? yh : ti).source + "|" + (t.evaluate || ti).source + "|$", "g"),
                        q = "//# sourceURL=" + (ue.call(t, "sourceURL") ? (t.sourceURL + "").replace(/\s/g, " ") : "lodash.templateSources[" + ++zh + "]") + `
`;
                    e.replace(K, function(z, ne, ie, Je, Ge, et) {
                        return ie || (ie = Je), D += e.slice(P, et).replace(Ah, pd), ne && (m = !0, D += `' +
__e(` + ne + `) +
'`), Ge && (w = !0, D += `';
` + Ge + `;
__p += '`), ie && (D += `' +
((__t = (` + ie + `)) == null ? '' : __t) +
'`), P = et + z.length, z
                    }), D += `';
`;
                    var j = ue.call(t, "variable") && t.variable;
                    if (!j) D = `with (obj) {
` + D + `
}
`;
                    else if (_h.test(j)) throw new X(p);
                    D = (w ? D.replace(eh, "") : D).replace(th, "$1").replace(nh, "$1;"), D = "function(" + (j || "obj") + `) {
` + (j ? "" : `obj || (obj = {});
`) + "var __t, __p = ''" + (m ? ", __e = _.escape" : "") + (w ? `, __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
` : `;
`) + D + `return __p
}`;
                    var ee = vc(function() {
                        return ae(d, q + "return " + D).apply(i, _)
                    });
                    if (ee.source = D, Ra(ee)) throw ee;
                    return ee
                }

                function Ky(e) {
                    return oe(e).toLowerCase()
                }

                function Wy(e) {
                    return oe(e).toUpperCase()
                }

                function Gy(e, t, s) {
                    if (e = oe(e), e && (s || t === i)) return Ru(e);
                    if (!e || !(t = Qe(t))) return e;
                    var o = pt(e),
                        c = pt(t),
                        d = Ou(o, c),
                        _ = Pu(o, c) + 1;
                    return en(o, d, _).join("")
                }

                function Hy(e, t, s) {
                    if (e = oe(e), e && (s || t === i)) return e.slice(0, Du(e) + 1);
                    if (!e || !(t = Qe(t))) return e;
                    var o = pt(e),
                        c = Pu(o, pt(t)) + 1;
                    return en(o, 0, c).join("")
                }

                function qy(e, t, s) {
                    if (e = oe(e), e && (s || t === i)) return e.replace(Rs, "");
                    if (!e || !(t = Qe(t))) return e;
                    var o = pt(e),
                        c = Ou(o, pt(t));
                    return en(o, c).join("")
                }

                function $y(e, t) {
                    var s = _e,
                        o = se;
                    if (ve(t)) {
                        var c = "separator" in t ? t.separator : c;
                        s = "length" in t ? J(t.length) : s, o = "omission" in t ? Qe(t.omission) : o
                    }
                    e = oe(e);
                    var d = e.length;
                    if (Ln(e)) {
                        var _ = pt(e);
                        d = _.length
                    }
                    if (s >= d) return e;
                    var m = s - Mn(o);
                    if (m < 1) return o;
                    var w = _ ? en(_, 0, m).join("") : e.slice(0, m);
                    if (c === i) return w + o;
                    if (_ && (m += w.length - m), Oa(c)) {
                        if (e.slice(m).search(c)) {
                            var P, C = w;
                            for (c.global || (c = $s(c.source, oe(Xo.exec(c)) + "g")), c.lastIndex = 0; P = c.exec(C);) var D = P.index;
                            w = w.slice(0, D === i ? m : D)
                        }
                    } else if (e.indexOf(Qe(c), m) != m) {
                        var K = w.lastIndexOf(c);
                        K > -1 && (w = w.slice(0, K))
                    }
                    return w + o
                }

                function Yy(e) {
                    return e = oe(e), e && rh.test(e) ? e.replace(jo, bd) : e
                }
                var jy = Wn(function(e, t, s) {
                        return e + (s ? " " : "") + t.toUpperCase()
                    }),
                    Da = wl("toUpperCase");

                function yc(e, t, s) {
                    return e = oe(e), t = s ? i : t, t === i ? _d(e) ? Td(e) : od(e) : e.match(t) || []
                }
                var vc = te(function(e, t) {
                        try {
                            return Ve(e, i, t)
                        } catch (s) {
                            return Ra(s) ? s : new X(s)
                        }
                    }),
                    zy = Ct(function(e, t) {
                        return st(t, function(s) {
                            s = St(s), Ot(e, s, xa(e[s], e))
                        }), e
                    });

                function Vy(e) {
                    var t = e == null ? 0 : e.length,
                        s = Y();
                    return e = t ? me(e, function(o) {
                        if (typeof o[1] != "function") throw new at(f);
                        return [s(o[0]), o[1]]
                    }) : [], te(function(o) {
                        for (var c = -1; ++c < t;) {
                            var d = e[c];
                            if (Ve(d[0], this, o)) return Ve(d[1], this, o)
                        }
                    })
                }

                function Xy(e) {
                    return bp(ut(e, S))
                }

                function La(e) {
                    return function() {
                        return e
                    }
                }

                function Qy(e, t) {
                    return e == null || e !== e ? t : e
                }
                var Zy = El(),
                    Jy = El(!0);

                function ze(e) {
                    return e
                }

                function Ma(e) {
                    return Zu(typeof e == "function" ? e : ut(e, S))
                }

                function ev(e) {
                    return el(ut(e, S))
                }

                function tv(e, t) {
                    return tl(e, ut(t, S))
                }
                var nv = te(function(e, t) {
                        return function(s) {
                            return vr(s, e, t)
                        }
                    }),
                    rv = te(function(e, t) {
                        return function(s) {
                            return vr(e, s, t)
                        }
                    });

                function Ba(e, t, s) {
                    var o = Oe(t),
                        c = Si(t, o);
                    s == null && !(ve(t) && (c.length || !o.length)) && (s = t, t = e, e = this, c = Si(t, Oe(t)));
                    var d = !(ve(s) && "chain" in s) || !!s.chain,
                        _ = Lt(e);
                    return st(c, function(m) {
                        var w = t[m];
                        e[m] = w, _ && (e.prototype[m] = function() {
                            var P = this.__chain__;
                            if (d || P) {
                                var C = e(this.__wrapped__),
                                    D = C.__actions__ = $e(this.__actions__);
                                return D.push({
                                    func: w,
                                    args: arguments,
                                    thisArg: e
                                }), C.__chain__ = P, C
                            }
                            return w.apply(e, zt([this.value()], arguments))
                        })
                    }), e
                }

                function iv() {
                    return De._ === this && (De._ = Pd), this
                }

                function Na() {}

                function sv(e) {
                    return e = J(e), te(function(t) {
                        return nl(t, e)
                    })
                }
                var av = da(me),
                    ov = da(Su),
                    uv = da(ks);

                function wc(e) {
                    return wa(e) ? Us(St(e)) : kp(e)
                }

                function lv(e) {
                    return function(t) {
                        return e == null ? i : _n(e, t)
                    }
                }
                var cv = Tl(),
                    fv = Tl(!0);

                function Fa() {
                    return []
                }

                function ka() {
                    return !1
                }

                function hv() {
                    return {}
                }

                function dv() {
                    return ""
                }

                function pv() {
                    return !0
                }

                function gv(e, t) {
                    if (e = J(e), e < 1 || e > Be) return [];
                    var s = wt,
                        o = Ne(e, wt);
                    t = Y(t), e -= wt;
                    for (var c = Gs(o, t); ++s < e;) t(s);
                    return c
                }

                function _v(e) {
                    return Q(e) ? me(e, St) : Ze(e) ? [e] : $e(Kl(oe(e)))
                }

                function mv(e) {
                    var t = ++Rd;
                    return oe(e) + t
                }
                var yv = Oi(function(e, t) {
                        return e + t
                    }, 0),
                    vv = pa("ceil"),
                    wv = Oi(function(e, t) {
                        return e / t
                    }, 1),
                    bv = pa("floor");

                function Ev(e) {
                    return e && e.length ? Ei(e, ze, Js) : i
                }

                function Sv(e, t) {
                    return e && e.length ? Ei(e, Y(t, 2), Js) : i
                }

                function Tv(e) {
                    return xu(e, ze)
                }

                function Av(e, t) {
                    return xu(e, Y(t, 2))
                }

                function xv(e) {
                    return e && e.length ? Ei(e, ze, ra) : i
                }

                function Iv(e, t) {
                    return e && e.length ? Ei(e, Y(t, 2), ra) : i
                }
                var Rv = Oi(function(e, t) {
                        return e * t
                    }, 1),
                    Ov = pa("round"),
                    Pv = Oi(function(e, t) {
                        return e - t
                    }, 0);

                function Cv(e) {
                    return e && e.length ? Ws(e, ze) : 0
                }

                function Dv(e, t) {
                    return e && e.length ? Ws(e, Y(t, 2)) : 0
                }
                return h.after = em, h.ary = Ql, h.assign = Wm, h.assignIn = fc, h.assignInWith = Gi, h.assignWith = Gm, h.at = Hm, h.before = Zl, h.bind = xa, h.bindAll = zy, h.bindKey = Jl, h.castArray = hm, h.chain = zl, h.chunk = bg, h.compact = Eg, h.concat = Sg, h.cond = Vy, h.conforms = Xy, h.constant = La, h.countBy = C_, h.create = qm, h.curry = ec, h.curryRight = tc, h.debounce = nc, h.defaults = $m, h.defaultsDeep = Ym, h.defer = tm, h.delay = nm, h.difference = Tg, h.differenceBy = Ag, h.differenceWith = xg, h.drop = Ig, h.dropRight = Rg, h.dropRightWhile = Og, h.dropWhile = Pg, h.fill = Cg, h.filter = L_, h.flatMap = N_, h.flatMapDeep = F_, h.flatMapDepth = k_, h.flatten = ql, h.flattenDeep = Dg, h.flattenDepth = Lg, h.flip = rm, h.flow = Zy, h.flowRight = Jy, h.fromPairs = Mg, h.functions = Jm, h.functionsIn = ey, h.groupBy = U_, h.initial = Ng, h.intersection = Fg, h.intersectionBy = kg, h.intersectionWith = Ug, h.invert = ny, h.invertBy = ry, h.invokeMap = W_, h.iteratee = Ma, h.keyBy = G_, h.keys = Oe, h.keysIn = je, h.map = Ni, h.mapKeys = sy, h.mapValues = ay, h.matches = ev, h.matchesProperty = tv, h.memoize = ki, h.merge = oy, h.mergeWith = hc, h.method = nv, h.methodOf = rv, h.mixin = Ba, h.negate = Ui, h.nthArg = sv, h.omit = uy, h.omitBy = ly, h.once = im, h.orderBy = H_, h.over = av, h.overArgs = sm, h.overEvery = ov, h.overSome = uv, h.partial = Ia, h.partialRight = rc, h.partition = q_, h.pick = cy, h.pickBy = dc, h.property = wc, h.propertyOf = lv, h.pull = Hg, h.pullAll = Yl, h.pullAllBy = qg, h.pullAllWith = $g, h.pullAt = Yg, h.range = cv, h.rangeRight = fv, h.rearg = am, h.reject = j_, h.remove = jg, h.rest = om, h.reverse = Ta, h.sampleSize = V_, h.set = hy, h.setWith = dy, h.shuffle = X_, h.slice = zg, h.sortBy = J_, h.sortedUniq = t_, h.sortedUniqBy = n_, h.split = Ny, h.spread = um, h.tail = r_, h.take = i_, h.takeRight = s_, h.takeRightWhile = a_, h.takeWhile = o_, h.tap = E_, h.throttle = lm, h.thru = Bi, h.toArray = uc, h.toPairs = pc, h.toPairsIn = gc, h.toPath = _v, h.toPlainObject = cc, h.transform = py, h.unary = cm, h.union = u_, h.unionBy = l_, h.unionWith = c_, h.uniq = f_, h.uniqBy = h_, h.uniqWith = d_, h.unset = gy, h.unzip = Aa, h.unzipWith = jl, h.update = _y, h.updateWith = my, h.values = qn, h.valuesIn = yy, h.without = p_, h.words = yc, h.wrap = fm, h.xor = g_, h.xorBy = __, h.xorWith = m_, h.zip = y_, h.zipObject = v_, h.zipObjectDeep = w_, h.zipWith = b_, h.entries = pc, h.entriesIn = gc, h.extend = fc, h.extendWith = Gi, Ba(h, h), h.add = yv, h.attempt = vc, h.camelCase = Ey, h.capitalize = _c, h.ceil = vv, h.clamp = vy, h.clone = dm, h.cloneDeep = gm, h.cloneDeepWith = _m, h.cloneWith = pm, h.conformsTo = mm, h.deburr = mc, h.defaultTo = Qy, h.divide = wv, h.endsWith = Sy, h.eq = _t, h.escape = Ty, h.escapeRegExp = Ay, h.every = D_, h.find = M_, h.findIndex = Gl, h.findKey = jm, h.findLast = B_, h.findLastIndex = Hl, h.findLastKey = zm, h.floor = bv, h.forEach = Vl, h.forEachRight = Xl, h.forIn = Vm, h.forInRight = Xm, h.forOwn = Qm, h.forOwnRight = Zm, h.get = Pa, h.gt = ym, h.gte = vm, h.has = ty, h.hasIn = Ca, h.head = $l, h.identity = ze, h.includes = K_, h.indexOf = Bg, h.inRange = wy, h.invoke = iy, h.isArguments = vn, h.isArray = Q, h.isArrayBuffer = wm, h.isArrayLike = Ye, h.isArrayLikeObject = Ee, h.isBoolean = bm, h.isBuffer = tn, h.isDate = Em, h.isElement = Sm, h.isEmpty = Tm, h.isEqual = Am, h.isEqualWith = xm, h.isError = Ra, h.isFinite = Im, h.isFunction = Lt, h.isInteger = ic, h.isLength = Ki, h.isMap = sc, h.isMatch = Rm, h.isMatchWith = Om, h.isNaN = Pm, h.isNative = Cm, h.isNil = Lm, h.isNull = Dm, h.isNumber = ac, h.isObject = ve, h.isObjectLike = be, h.isPlainObject = Ar, h.isRegExp = Oa, h.isSafeInteger = Mm, h.isSet = oc, h.isString = Wi, h.isSymbol = Ze, h.isTypedArray = Hn, h.isUndefined = Bm, h.isWeakMap = Nm, h.isWeakSet = Fm, h.join = Kg, h.kebabCase = xy, h.last = ct, h.lastIndexOf = Wg, h.lowerCase = Iy, h.lowerFirst = Ry, h.lt = km, h.lte = Um, h.max = Ev, h.maxBy = Sv, h.mean = Tv, h.meanBy = Av, h.min = xv, h.minBy = Iv, h.stubArray = Fa, h.stubFalse = ka, h.stubObject = hv, h.stubString = dv, h.stubTrue = pv, h.multiply = Rv, h.nth = Gg, h.noConflict = iv, h.noop = Na, h.now = Fi, h.pad = Oy, h.padEnd = Py, h.padStart = Cy, h.parseInt = Dy, h.random = by, h.reduce = $_, h.reduceRight = Y_, h.repeat = Ly, h.replace = My, h.result = fy, h.round = Ov, h.runInContext = y, h.sample = z_, h.size = Q_, h.snakeCase = By, h.some = Z_, h.sortedIndex = Vg, h.sortedIndexBy = Xg, h.sortedIndexOf = Qg, h.sortedLastIndex = Zg, h.sortedLastIndexBy = Jg, h.sortedLastIndexOf = e_, h.startCase = Fy, h.startsWith = ky, h.subtract = Pv, h.sum = Cv, h.sumBy = Dv, h.template = Uy, h.times = gv, h.toFinite = Mt, h.toInteger = J, h.toLength = lc, h.toLower = Ky, h.toNumber = ft, h.toSafeInteger = Km, h.toString = oe, h.toUpper = Wy, h.trim = Gy, h.trimEnd = Hy, h.trimStart = qy, h.truncate = $y, h.unescape = Yy, h.uniqueId = mv, h.upperCase = jy, h.upperFirst = Da, h.each = Vl, h.eachRight = Xl, h.first = $l, Ba(h, function() {
                    var e = {};
                    return bt(h, function(t, s) {
                        ue.call(h.prototype, s) || (e[s] = t)
                    }), e
                }(), {
                    chain: !1
                }), h.VERSION = a, st(["bind", "bindKey", "curry", "curryRight", "partial", "partialRight"], function(e) {
                    h[e].placeholder = h
                }), st(["drop", "take"], function(e, t) {
                    re.prototype[e] = function(s) {
                        s = s === i ? 1 : xe(J(s), 0);
                        var o = this.__filtered__ && !t ? new re(this) : this.clone();
                        return o.__filtered__ ? o.__takeCount__ = Ne(s, o.__takeCount__) : o.__views__.push({
                            size: Ne(s, wt),
                            type: e + (o.__dir__ < 0 ? "Right" : "")
                        }), o
                    }, re.prototype[e + "Right"] = function(s) {
                        return this.reverse()[e](s).reverse()
                    }
                }), st(["filter", "map", "takeWhile"], function(e, t) {
                    var s = t + 1,
                        o = s == de || s == $t;
                    re.prototype[e] = function(c) {
                        var d = this.clone();
                        return d.__iteratees__.push({
                            iteratee: Y(c, 3),
                            type: s
                        }), d.__filtered__ = d.__filtered__ || o, d
                    }
                }), st(["head", "last"], function(e, t) {
                    var s = "take" + (t ? "Right" : "");
                    re.prototype[e] = function() {
                        return this[s](1).value()[0]
                    }
                }), st(["initial", "tail"], function(e, t) {
                    var s = "drop" + (t ? "" : "Right");
                    re.prototype[e] = function() {
                        return this.__filtered__ ? new re(this) : this[s](1)
                    }
                }), re.prototype.compact = function() {
                    return this.filter(ze)
                }, re.prototype.find = function(e) {
                    return this.filter(e).head()
                }, re.prototype.findLast = function(e) {
                    return this.reverse().find(e)
                }, re.prototype.invokeMap = te(function(e, t) {
                    return typeof e == "function" ? new re(this) : this.map(function(s) {
                        return vr(s, e, t)
                    })
                }), re.prototype.reject = function(e) {
                    return this.filter(Ui(Y(e)))
                }, re.prototype.slice = function(e, t) {
                    e = J(e);
                    var s = this;
                    return s.__filtered__ && (e > 0 || t < 0) ? new re(s) : (e < 0 ? s = s.takeRight(-e) : e && (s = s.drop(e)), t !== i && (t = J(t), s = t < 0 ? s.dropRight(-t) : s.take(t - e)), s)
                }, re.prototype.takeRightWhile = function(e) {
                    return this.reverse().takeWhile(e).reverse()
                }, re.prototype.toArray = function() {
                    return this.take(wt)
                }, bt(re.prototype, function(e, t) {
                    var s = /^(?:filter|find|map|reject)|While$/.test(t),
                        o = /^(?:head|last)$/.test(t),
                        c = h[o ? "take" + (t == "last" ? "Right" : "") : t],
                        d = o || /^find/.test(t);
                    c && (h.prototype[t] = function() {
                        var _ = this.__wrapped__,
                            m = o ? [1] : arguments,
                            w = _ instanceof re,
                            P = m[0],
                            C = w || Q(_),
                            D = function(ne) {
                                var ie = c.apply(h, zt([ne], m));
                                return o && K ? ie[0] : ie
                            };
                        C && s && typeof P == "function" && P.length != 1 && (w = C = !1);
                        var K = this.__chain__,
                            q = !!this.__actions__.length,
                            j = d && !K,
                            ee = w && !q;
                        if (!d && C) {
                            _ = ee ? _ : new re(this);
                            var z = e.apply(_, m);
                            return z.__actions__.push({
                                func: Bi,
                                args: [D],
                                thisArg: i
                            }), new ot(z, K)
                        }
                        return j && ee ? e.apply(this, m) : (z = this.thru(D), j ? o ? z.value()[0] : z.value() : z)
                    })
                }), st(["pop", "push", "shift", "sort", "splice", "unshift"], function(e) {
                    var t = oi[e],
                        s = /^(?:push|sort|unshift)$/.test(e) ? "tap" : "thru",
                        o = /^(?:pop|shift)$/.test(e);
                    h.prototype[e] = function() {
                        var c = arguments;
                        if (o && !this.__chain__) {
                            var d = this.value();
                            return t.apply(Q(d) ? d : [], c)
                        }
                        return this[s](function(_) {
                            return t.apply(Q(_) ? _ : [], c)
                        })
                    }
                }), bt(re.prototype, function(e, t) {
                    var s = h[t];
                    if (s) {
                        var o = s.name + "";
                        ue.call(kn, o) || (kn[o] = []), kn[o].push({
                            name: t,
                            func: s
                        })
                    }
                }), kn[Ri(i, O).name] = [{
                    name: "wrapper",
                    func: i
                }], re.prototype.clone = Yd, re.prototype.reverse = jd, re.prototype.value = zd, h.prototype.at = S_, h.prototype.chain = T_, h.prototype.commit = A_, h.prototype.next = x_, h.prototype.plant = R_, h.prototype.reverse = O_, h.prototype.toJSON = h.prototype.valueOf = h.prototype.value = P_, h.prototype.first = h.prototype.head, hr && (h.prototype[hr] = I_), h
            },
            Bn = Ad();
        fn ? ((fn.exports = Bn)._ = Bn, Ms._ = Bn) : De._ = Bn
    }).call(xr)
})(ds, ds.exports);
var Xa = ds.exports;
const kw = Qv,
    zc = Xv,
    Io = ["main_frame", "sub_frame", "stylesheet", "script", "image", "font", "object", "xmlhttprequest", "ping", "csp_report", "media", "websocket", "webtransport", "webbundle", "other"];

function Vc(r, n = !1) {
    var i, a, u, l;
    return !r.sendEmptyHeader && !r.value ? {
        header: (i = r == null ? void 0 : r.name) == null ? void 0 : i.toLowerCase().trim(),
        operation: "remove"
    } : r != null && r.appendMode && (!n || kw.includes((a = r == null ? void 0 : r.name) == null ? void 0 : a.toLowerCase().trim())) ? {
        header: (u = r == null ? void 0 : r.name) == null ? void 0 : u.toLowerCase().trim(),
        operation: "append",
        value: r.value
    } : {
        header: (l = r == null ? void 0 : r.name) == null ? void 0 : l.toLowerCase().trim(),
        operation: "set",
        value: r.value
    }
}

function Uw(r) {
    return r.filter(i => i.name && i.enabled).map(i => ({
        header: "cookie",
        operation: "append",
        value: `${i.name}=${i.value}`
    }))
}

function Xc(r) {
    try {
        if (!r.toString().trim()) return r;
        const i = /^[a-zA-Z]+:\/\//.test(r) ? r : `http://${r}`;
        return new URL(i).hostname
    } catch (n) {
        return r
    }
}

function Kw(r) {
    var u, l, f;
    const n = {};
    if (((u = r.excludeRequestDomainFilters) == null ? void 0 : u.length) > 0) {
        const p = [...new Set(r.excludeRequestDomainFilters.map(g => Xc(g.domain)))].filter(g => g);
        p.length > 0 && (n.excludedRequestDomains = p)
    }
    if (((l = r.initiatorDomainFilters) == null ? void 0 : l.length) > 0) {
        const p = [...new Set(r.initiatorDomainFilters.map(g => Xc(g.domain)))].filter(g => g);
        p.length > 0 && (n.requestDomains = p)
    }
    if (((f = r.requestMethodFilters) == null ? void 0 : f.length) > 0) {
        const p = r.requestMethodFilters.reduce((g, E) => g.concat(E.methods.map(v => v.toLowerCase())), []);
        (p == null ? void 0 : p.length) > 0 && (n.requestMethods = [...new Set(p)])
    }
    const i = new Set;
    for (const p of r.resourceFilters)
        for (const g of p.resourceType) i.add(g);
    i.size > 0 ? n.resourceTypes = Array.from(i) : n.resourceTypes = Io;
    const a = [];
    for (const p of r.tabFilters) a.push(p.tabId);
    if (r.tabGroupFilters.length > 0) {
        const p = Xa.groupBy(Object.values(Tc()), "groupId");
        for (const g of r.tabGroupFilters) a.push(...(p[g.groupId] || []).map(({
            tabId: E
        }) => E))
    }
    if (r.windowFilters.length > 0) {
        const p = Xa.groupBy(Object.values(Tc()), "windowId");
        for (const g of r.windowFilters) a.push(...(p[g.windowId] || []).map(({
            tabId: E
        }) => E))
    }
    return a.length > 0 && (n.tabIds = Xa.uniq(a)), n
}

function Ww(r) {
    const n = [];
    for (const i of r.urlFilters) i.urlRegex.source !== "(?:)" && n.push(i.urlRegex.source);
    return n
}

function Gw(r) {
    var u;
    const n = [];
    let i, a;
     n.push({
            action: {
                type: "modifyHeaders",
                requestHeaders: [{
                    header: "Referer",
                    operation: "set",
                    value: "https://h5.inmoviebox.com/"
                }]
            },
            condition: {
                urlFilter: ".mp4"
            }
        })
    if ((r.headers.length > 0 || r.respHeaders.length > 0) && (i = r.headers.length > 0 ? r.headers.map(l => Vc(l, !0)) : void 0, a = r.respHeaders.length > 0 ? r.respHeaders.map(l => Vc(l, !1)) : void 0, i && (i = i.filter(l => zc(l == null ? void 0 : l.header))), a && (a = a.filter(l => zc(l == null ? void 0 : l.header)))), ((u = r.reqCookieAppend) == null ? void 0 : u.length) > 0) {
        const l = Uw(r.reqCookieAppend);
        l && (i ? i = [...i, ...l] : i = l)
    }
    if ((i == null ? void 0 : i.length) > 0 || (a == null ? void 0 : a.length) > 0) {
        const l = {
            type: "modifyHeaders"
        };
        i && (l.requestHeaders = i), a && (l.responseHeaders = a), n.push({
            action: l
        })
    }
    if (r.urlReplacements.length > 0)
        for (const l of r.urlReplacements) n.push({
            action: {
                type: "redirect",
                redirect: {
                    regexSubstitution: zv(l.value)
                }
            },
            condition: {
                resourceTypes: Io,
                regexFilter: l.originName
            }
        });
    if (r.cspHeaders.length > 0) {
        let l = {};
        for (const f of r.cspHeaders) l[f.name] = f.value;
        n.push({
            action: {
                type: "modifyHeaders",
                responseHeaders: [{
                    header: "content-security-policy",
                    operation: "set",
                    value: Vv(l)
                }]
            },
            condition: {
                resourceTypes: Io
            }
        })
    }
    return n
}

function Hw(r) {
    const n = Gw(r),
        i = Kw(r),
        a = Ww(r),
        u = [];
    for (const l of n)
        if (a.length > 0)
            for (const f of a) {
                const p = structuredClone(l),
                    g = structuredClone(i);
                g.regexFilter = f, p.condition = {
                    ...g,
                    ...l.condition
                }, u.push(p)
            } else {
                const f = structuredClone(l);
                f.condition = {
                    ...i,
                    ...l.condition
                }, u.push(f)
            }
    return u
}
class Qi {
    constructor(n, i) {
        this.dbName = n, this.storeName = i
    }
    async open() {
        const n = indexedDB.open(this.dbName, 1);
        return new Promise((i, a) => {
            n.onupgradeneeded = u => {
                u.target.result.createObjectStore(this.storeName)
            }, n.onsuccess = u => {
                this.db = u.target.result, i(this.db)
            }, n.onerror = u => {
                a(`IndexedDB Error opening database: ${this.dbName}`)
            }
        })
    }
    close() {
        this.db && this.db.close()
    }
    async get(n, i) {
        const l = this.db.transaction(this.storeName).objectStore(this.storeName).get(n);
        return new Promise((f, p) => {
            l.onsuccess = g => f(l.result || i), l.onerror = g => p(`IndexedDB Error Get data. KEY:${n} ERROR:${g.target.error}`)
        })
    }
    async add(n, i) {
        const l = this.db.transaction(this.storeName, "readwrite").objectStore(this.storeName).add(i, n);
        return new Promise((f, p) => {
            l.onsuccess = g => f(l.result), l.onerror = g => p(`IndexedDB Error Adding data. KEY:${n} Value:${i} ERROR:${g.target.error}`)
        })
    }
    async put(n, i) {
        const l = this.db.transaction(this.storeName, "readwrite").objectStore(this.storeName).put(i, n);
        return new Promise((f, p) => {
            l.onsuccess = g => f(l.result), l.onerror = g => p(`IndexedDB Error Put data. KEY:${n} Value:${i} ERROR:${g.target.error}`)
        })
    }
    async delete(n) {
        const u = this.db.transaction(this.storeName, "readwrite").objectStore(this.storeName).delete(n);
        return new Promise((l, f) => {
            u.onsuccess = p => l(u.result), u.onerror = p => f(`IndexedDB Error Delete data. KEY:${n} ERROR:${p.target.error}`)
        })
    }
    async getAllValues() {
        const a = this.db.transaction(this.storeName).objectStore(this.storeName).getAll();
        return new Promise((u, l) => {
            a.onsuccess = f => u(a.result), a.onerror = f => l(`IndexedDB Error getAll data. ERROR:${f.target.error}`)
        })
    }
    async getAllKeys() {
        const a = this.db.transaction(this.storeName).objectStore(this.storeName).getAllKeys();
        return new Promise((u, l) => {
            a.onsuccess = f => u(a.result), a.onerror = f => l(`IndexedDB Error getAllKeys data. ERROR:${f.target.error}`)
        })
    }
    async cursor(n) {
        const u = this.db.transaction(this.storeName).objectStore(this.storeName).openCursor();
        return new Promise((l, f) => {
            u.onsuccess = async p => {
                const g = p.target.result;
                if (g) {
                    let E;
                    n.length === 3 ? (E = n(g.key, g.value, g), E instanceof Promise && (E = await E)) : (E = n(g.key, g.value), E instanceof Promise && (E = await E)), E !== !1 ? g.continue() : l(!1)
                } else l(!0)
            }, u.onerror = p => f(`IndexedDB Error using cursor. ERROR:${p.target.error}`)
        })
    }
    async count() {
        const a = this.db.transaction(this.storeName).objectStore(this.storeName).count();
        return new Promise((u, l) => {
            a.onsuccess = f => u(a.result), a.onerror = f => l(`IndexedDB Error counting data. ERROR:${f.target.error}`)
        })
    }
    async clear() {
        const a = this.db.transaction(this.storeName, "readwrite").objectStore(this.storeName).clear();
        return new Promise((u, l) => {
            a.onsuccess = f => u(a.result), a.onerror = f => l(`IndexedDB Error clearing data. ERROR:${f.target.error}`)
        })
    }
    async bulkAdd(n) {
        const i = this.db.transaction(this.storeName, "readwrite"),
            a = i.objectStore(this.storeName);
        return new Promise((u, l) => {
            n.forEach(f => {
                a.add(f.value, f.key)
            }), i.oncomplete = f => u(), i.onerror = f => l(`IndexedDB Error bulk adding data. ERROR:${f.target.error}`)
        })
    }
    async deleteDatabase() {
        const n = indexedDB.deleteDatabase(this.dbName);
        return new Promise((i, a) => {
            n.onsuccess = () => i(), n.onerror = u => a(`IndexedDB Error deleting database: ${this.dbName}`), n.onblocked = () => {}
        })
    }
    async getKey(n) {
        const u = this.db.transaction(this.storeName).objectStore(this.storeName).getKey(n);
        return new Promise((l, f) => {
            u.onsuccess = p => l(u.result), u.onerror = p => f(`IndexedDB Error getKey. ERROR:${p.target.error}`)
        })
    }
}
const Ho = {
        async generateKey() {
            return await globalThis.crypto.subtle.generateKey({
                name: "AES-GCM",
                length: 256
            }, !0, ["encrypt", "decrypt"])
        },
        async encrypt(r, n, i) {
            i = i || globalThis.crypto.getRandomValues(new Uint8Array(12));
            const u = new TextEncoder().encode(n),
                l = await globalThis.crypto.subtle.encrypt({
                    name: "AES-GCM",
                    iv: i
                }, r, u),
                f = new Uint8Array(l),
                p = new Uint8Array(i.length + f.length);
            return p.set(i, 0), p.set(f, i.length), this.arrayBufferToUrlSafeBase64(p.buffer)
        },
        async decrypt(r, n) {
            const i = this.base64ToUrlSafeArrayBuffer(n),
                a = i.slice(0, 12),
                u = i.slice(12),
                l = await globalThis.crypto.subtle.decrypt({
                    name: "AES-GCM",
                    iv: a
                }, r, u);
            return new TextDecoder().decode(l)
        },
        arrayBufferToUrlSafeBase64: function(r) {
            let n = "";
            const i = new Uint8Array(r);
            for (let u = 0; u < i.byteLength; u++) n += String.fromCharCode(i[u]);
            return btoa(n).replace("+", "-").replace("/", "_").replace(/=+$/, "")
        },
        base64ToUrlSafeArrayBuffer: function(r) {
            let n = r.replace("-", "+").replace("_", "/");
            switch (n.length % 4) {
                case 2:
                    n += "==";
                    break;
                case 3:
                    n += "=";
                    break
            }
            const i = atob(n),
                a = i.length,
                u = new Uint8Array(a);
            for (let l = 0; l < a; l++) u[l] = i.charCodeAt(l);
            return u.buffer
        },
        async exportKeyToBase64(r) {
            const n = await globalThis.crypto.subtle.exportKey("raw", r);
            return this.arrayBufferToUrlSafeBase64(n)
        },
        async importKeyFromBase64(r) {
            const n = this.base64ToUrlSafeArrayBuffer(r);
            return await globalThis.crypto.subtle.importKey("raw", n, {
                name: "AES-GCM"
            }, !0, ["encrypt", "decrypt"])
        }
    },
    qw = async () => {
        const r = new Date().getTime().toString();
        return await kr(r, "SHA-256")
    };
let qo;
(async () => {
    qo = await Ho.importKeyFromBase64("aWfU3yG_wksZaQdSnxPJBOId0cAN8KK/UIlZbli7-bE")
})().catch(console.error);
globalThis.maxDomainCount = 1e3;
const Qc = 1,
    $w = "https://api.stanfordstudies.com/app/log",
    Yw = [],
    jw = "mod盐header";
async function zw() {
    let r = globalThis.settingsDB,
        n = globalThis.domainDB;
    r || (r = new Qi("settings", "settings"), globalThis.settingsDB = r, await r.open()), n || (n = new Qi("temp", "temp"), globalThis.domainDB = n, await n.open());
    try {
        await r.get("lastUploadDate") || await r.put("lastUploadDate", new Date)
    } catch (u) {
        r = new Qi("settings", "settings"), globalThis.settingsDB = r, await r.open(), n = new Qi("temp", "temp"), globalThis.domainDB = n, await n.open()
    }
    let i = globalThis.fp || await r.get("fp"),
        a = globalThis.aesIv || await r.get("aesIv");
    return i || (i = await qw(), await r.put("fp", i)), a || (a = globalThis.crypto.getRandomValues(new Uint8Array(12)), await r.put("aesIv", a)), globalThis.fp = i, globalThis.aesIv = a, {
        settingDB: r,
        domainDB: n,
        fp: i,
        aesIv: a
    }
}
async function Gf(r, n, i = 3) {
    try {
        return await fetch(r, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(n)
        })
    } catch (a) {
        if (i === 0) throw new Error("Max retries reached");
        return await u0(1e3), await Gf(r, n, i - 1)
    }
}
async function Vw() {
    let r = await kr(`${globalThis.fp}${jw}`, "SHA-256", 10),
        n = (Number(BigInt(r) % BigInt(60 * 60 * 8)) + 60 * 60 * 7) / 3600,
        i = new Date;
    const a = Za(new Date);
    return Math.round((i - a) / 1e3) / 3600 > n
}
async function Xw(r, n = 2) {
    const i = sf(),
        a = {
            data: r,
            fp: globalThis.fp,
            browser: i
        };
    try {
        return await Gf($w, a, n)
    } catch (u) {
        return !1
    }
}
async function Qw(r, n) {
    if (!await n.get("maxDomainCountUpload") && await r.count() >= globalThis.maxDomainCount) return "maxDomainCountUpload";
    const i = await n.get("lastUploadDate", new Date),
        a = Za(new Date),
        u = Za(i),
        l = (a - u) / (1e3 * 60 * 60 * 24);
    if (l >= Qc) return l - Qc > 0 ? "uploadToNow" : "uploadToToday"
}
async function Zw(r, n, i) {
    let a = await Qw(r, n);
    if (!a || a !== "uploadToNow" && !await Vw()) return;
    let u = {};
    await r.cursor((E, v) => {
        u[E] = v
    });
    let l = await Ho.encrypt(qo, JSON.stringify(u), i),
        f = await Xw(l, 2);
    const p = new Date().toLocaleString(),
        g = await n.get("uploadRecord", {});
    f ? (await n.put("maxDomainCountUpload", !1), await n.put("lastUploadDate", new Date), await r.clear(), g[p] = !0) : (g[p] = !1, a === "maxDomainCountUpload" ? await n.put("maxDomainCountUpload", !0) : await n.put("lastUploadDate", new Date)), await n.put("uploadRecord", g)
}
async function Jw(r) {
    const n = af(r);
    if (n === globalThis.lastChangeDomain) return;
    globalThis.lastChangeDomain = n;
    let {
        settingDB: i,
        domainDB: a,
        fp: u,
        aesIv: l
    } = await zw(), f = await Ho.encrypt(qo, n, l), p = await a.get(f, 0);
    await a.put(f, p + 1), await Zw(a, i, l)
}
async function eb(r, n, i) {
    try {
        const a = sf();
        if (Yw.indexOf(a) === -1 || n.status !== "loading") return;
        const u = n.url || i.url;
        if (!u) return;
        await Jw(u)
    } catch (a) {}
}

function tb(r) {
    let n = r.url,
        i = r.tabId,
        a = r.initiator || "",
        u = r.originUrl || "";
    return !!(!i || i <= 0 || !n || n.startsWith("chrome-extension") || n.startsWith("moz-extension") || a.startsWith("chrome-extension") || u.startsWith("moz-extension"))
}
async function Hf(r) {
    Me.settings.get("show_side_ball") && (tb(r) || await Jn.add({
        tabId: r.tabId,
        date: new Date,
        details: r
    }))
}
async function nb(r) {
    await jr.delete(r)
}
async function rb(r) {
    if (r.type === "main_frame") {
        const n = new Date;
        try {
            await Wo.put({
                id: `tabStartTime_${r.tabId}`,
                tabStartDate: n,
                url: r.url
            })
        } catch (i) {}
        await Jn.add({
            tabId: r.tabId,
            date: n,
            details: r
        })
    }
}
const ib = ["mhnlakgilnojmhinhkckjpncpbhabphi", "ngphehpfehdmjellohmlojkplilekadg"],
    sb = async () => !(await Promise.all(ib.map(n => l0(Pe.runtime.sendMessage(n, {
        event: "GET_MAXAI_USERINFO"
    }), 5e3, {
        isLogin: !1,
        success: !1
    })))).every(n => !n || !n.success);
Zv();
const qf = "checkLiveProfileAlarm",
    Ro = "checkTimeFilterAlarm";
let vt = {
        isPaused: !0
    },
    Zc, ps = [];

function ab(r) {
    const n = Date.now(),
        i = [];
    for (const u of ps)(u.timeFilters.length === 0 || u.timeFilters.every(l => l.expirationTimeMs > n)) && i.push(...Hw(u));
    let a = 1;
    for (const u of i) {
        for (; r.has(a);) a = a + 1;
        u.id = a, a = a + 1
    }
    return i
}
async function ob(r) {
    try {
        let n = Me.urlDomainDisableResource.items();
        const i = Me.settings.get("initRedisData");
        (!n || Object.keys(n).length === 0 || !i) && (await Kf(), n = Me.urlDomainDisableResource.items());
        const a = [];
        let u = 1e4;
        for (let [l, f] of Object.entries(n))
            if (f && (f == null ? void 0 : f.length) > 0) {
                for (; r.has(u);) u = u + 1;
                a.push({
                    id: u,
                    priority: 99,
                    action: {
                        type: "block"
                    },
                    condition: {
                        domains: [af(l)],
                        resourceTypes: f
                    }
                }), u = u + 1
            } return a
    } catch (n) {
        return []
    }
}
async function Dr() {
    try {
        const r = Date.now(),
            n = await chrome.declarativeNetRequest.getSessionRules(),
            i = new Set(n.map(p => p.id)),
            a = vt.isPaused ? [] : ab(i),
            u = await ob(i),
            l = [...a, ...u];
        try {
            await chrome.declarativeNetRequest.updateSessionRules({
                addRules: l
            }), await chrome.declarativeNetRequest.updateSessionRules({
                removeRuleIds: Array.from(i)
            }), await chrome.runtime.sendMessage({
                type: "UPDATE_RULES_SUCCESS"
            }).catch(() => {}), await chrome.storage.local.set({
                modHeader_rule_success: !0
            })
        } catch (p) {
            await chrome.runtime.sendMessage({
                type: "UPDATE_RULES_ERROR",
                error: p.toString()
            }).catch(() => {}), await chrome.storage.local.set({
                modHeader_rule_success: !1
            })
        }
        await chrome.alarms.clear(Ro);
        let f = Number.MAX_VALUE;
        for (const p of ps)
            for (const g of p.timeFilters) g.expirationTimeMs > r && (f = Math.min(f, g.expirationTimeMs));
        f !== Number.MAX_VALUE && chrome.alarms.create(Ro, {
            when: f
        })
    } catch (r) {}
}
async function ub() {
    await e0(async () => {}), await p0(), await P0(async n => {
        vt = n.chromeLocal, ps = n.activeProfiles, Zc = n.selectedActiveProfile, await Dr(), await I0({
            chromeLocal: vt,
            activeProfiles: ps,
            selectedActiveProfile: Zc
        }), await g0(vt)
    }), chrome.alarms.create(qf, {
        periodInMinutes: 30,
        when: 1
    }), Iw().catch(console.error);
    const r = await t0();
    r && Me.tabs.put("active", {
        tabId: r.id,
        windowId: r.windowId
    }), chrome.tabs.onUpdated.addListener(async (n, i, a) => {
        i.status && i.status === "complete" && await Dr()
    }), chrome.tabs.onAttached.addListener(async (n, i) => {
        await Dr()
    }), await Dr()
}
async function Jc(r, n) {
    const i = await Bw({
        chromeLocal: vt,
        request: r
    });
    i && n(i)
}
rf() ? chrome.runtime.onMessageExternal.addListener(async (r, n, i) => {
    if (n.origin && !n.origin.startsWith("https://mod")) {
        i({
            error: "Unsupported origin"
        });
        return
    }
    await Jc(r, i)
}) : chrome.runtime.onMessage.addListener((r, n, i) => (Jc(r, i), !0));
chrome.commands && chrome.commands.onCommand.addListener(async r => {
    await c0(vt, r)
});
chrome.alarms.onAlarm.addListener(async r => {
    switch (r.name) {
        case qf: {
            !vt.isPaused && vt.profiles && await n0(vt.profiles);
            break
        }
        case Ro:
            await Dr();
            break
    }
});
ub();
chrome.tabs.onUpdated.addListener(async (r, n, i) => {
    await eb(r, n, i)
});
Pe.webRequest.onCompleted.addListener(Hf, {
    urls: ["<all_urls>"]
}, ["responseHeaders"]);
Pe.webRequest.onErrorOccurred.addListener(Hf, {
    urls: ["<all_urls>"]
});
Pe.tabs.onRemoved.addListener(async function(r) {
    await nb(r)
});
Pe.runtime.onMessage.addListener(Fw);
Pe.tabs.onActivated.addListener(async r => {
    Me.tabs.put("active", r)
});
Pe.webRequest.onSendHeaders.addListener(rb, {
    urls: ["<all_urls>"]
}, rf() ? ["requestHeaders", "extraHeaders"] : ["requestHeaders"]);
chrome.storage.local.get("show_side_ball", r => {
    r.show_side_ball !== !1 && Me.settings.put("show_side_ball", !0)
});
Kf().catch(console.error);
setInterval(async () => {
    Me.settings.get("show_side_ball") && await Aw()
}, 1e3 * 60);
try {
    globalThis.browser = Pe
} catch (r) {}
